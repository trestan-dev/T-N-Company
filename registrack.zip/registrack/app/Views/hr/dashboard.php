<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>HR Dashboard — T&N Company Careers</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600;700;800&family=DM+Serif+Display:ital@0;1&display=swap" rel="stylesheet" />
  <link href="<?= base_url('assets/css/style.css') ?>" rel="stylesheet" />
</head>
<body>

  <?php
  $userJson = json_encode([
      'id'    => $user['id'],
      'role'  => $user['role'],
      'first' => $user['first'],
      'last'  => $user['last'],
      'email' => $user['email'],
  ]);
  ?>

  <div id="topbarMount"></div>

  <div class="rt-page-wrap">
    <div class="container">

      <div class="rt-page-header">
        <div>
          <h1 class="rt-page-title">HR Dashboard</h1>
          <p class="rt-page-sub">Manage job postings and review applications for T&amp;N Company.</p>
        </div>
        <button class="rt-btn rt-btn-primary" data-bs-toggle="modal" data-bs-target="#postJobModal">
          <i class="fas fa-plus me-2"></i>Post a Job
        </button>
      </div>

      <?php if (session()->getFlashdata('success')): ?>
        <div class="rt-alert rt-alert-success show mb-3">
          <i class="fas fa-check-circle me-2"></i><?= esc(session()->getFlashdata('success')) ?>
        </div>
      <?php endif; ?>

      <div class="rt-tabs">
        <button class="rt-tab active" onclick="switchTab('applications',this)">
          <i class="fas fa-users me-2"></i>Applications
        </button>
        <button class="rt-tab" onclick="switchTab('jobs',this)">
          <i class="fas fa-briefcase me-2"></i>Job Postings
        </button>
      </div>

      <!-- Applications Tab -->
      <div id="tab-applications">
        <div class="row g-3 mb-4" id="statRow"></div>
        <div class="rt-card">
          <div class="rt-card-header">
            <div class="rt-card-header-left">
              <div class="rt-section-num"><i class="fas fa-users"></i></div>
              <h2 class="rt-card-title">All Applications</h2>
            </div>
            <span class="rt-muted" id="appResultCount"></span>
          </div>
          <div id="appFilterBarMount"></div>
          <div class="rt-table-wrap">
            <table class="rt-table">
              <thead>
                <tr>
                  <th>Code</th>
                  <th>Applicant</th>
                  <th>Position</th>
                  <th>Dept</th>
                  <th>Score</th>
                  <th>Status</th>
                  <th>Submitted</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody id="hrTbody">
                <tr><td colspan="8" class="text-center py-4" style="color:var(--mid);">Loading…</td></tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <!-- Jobs Tab -->
      <div id="tab-jobs" style="display:none;">
        <div class="rt-card">
          <div class="rt-card-header">
            <div class="rt-card-header-left">
              <div class="rt-section-num"><i class="fas fa-briefcase"></i></div>
              <h2 class="rt-card-title">Job Postings</h2>
            </div>
            <div class="d-flex gap-2 align-items-center">
              <span class="rt-muted" id="jobResultCount"></span>
              <div id="jobViewToggleMount"></div>
            </div>
          </div>
          <div id="jobFilterBarMount"></div>
          <input type="hidden" id="hrjobs_viewmode" value="cards" />
          <div id="hrJobsContainer" class="p-3"></div>
        </div>
      </div>

    </div>
  </div>

  <!-- Review Modal -->
  <div class="modal fade" id="reviewModal" tabindex="-1">
    <div class="modal-dialog modal-xl">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title"><i class="fas fa-clipboard-list me-2"></i>Review Application — <span id="reviewCode"></span></h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <div id="reviewAlert" class="rt-alert"></div>
          <div class="row g-4">
            <div class="col-md-7">
              <div class="rt-card mb-3">
                <div class="rt-card-header"><div class="rt-card-header-left"><i class="fas fa-user me-2" style="color:var(--accent);"></i><h6 class="rt-card-title mb-0">Applicant</h6></div></div>
                <div class="rt-card-body"><div class="rt-detail-grid" id="reviewApplicantInfo"></div></div>
              </div>
              <div class="rt-card mb-3">
                <div class="rt-card-header"><div class="rt-card-header-left"><i class="fas fa-briefcase me-2" style="color:var(--green);"></i><h6 class="rt-card-title mb-0">Application Details</h6></div></div>
                <div class="rt-card-body"><div class="rt-detail-grid" id="reviewAppDetails"></div></div>
              </div>
              <div class="rt-card mb-3" id="coverLetterCard" style="display:none;">
                <div class="rt-card-header"><div class="rt-card-header-left"><i class="fas fa-file-lines me-2" style="color:var(--purple);"></i><h6 class="rt-card-title mb-0">Cover Letter</h6></div></div>
                <div class="rt-card-body"><p id="coverLetterText" style="font-size:.88rem;line-height:1.7;white-space:pre-wrap;margin:0;"></p></div>
              </div>
              <div class="rt-card">
                <div class="rt-card-header"><div class="rt-card-header-left"><i class="fas fa-clock-rotate-left me-2" style="color:var(--mid);"></i><h6 class="rt-card-title mb-0">Status History</h6></div></div>
                <div class="rt-card-body" id="statusHistoryBody" style="max-height:200px;overflow-y:auto;padding:12px 16px;"></div>
              </div>
            </div>
            <div class="col-md-5">
              <div class="rt-card mb-3">
                <div class="rt-card-header"><div class="rt-card-header-left"><i class="fas fa-chart-bar me-2" style="color:var(--yellow);"></i><h6 class="rt-card-title mb-0">Resume Score</h6></div></div>
                <div class="rt-card-body text-center" id="scoreDisplay"></div>
              </div>
              <div class="rt-card">
                <div class="rt-card-header"><div class="rt-card-header-left"><i class="fas fa-pen-to-square me-2" style="color:var(--red);"></i><h6 class="rt-card-title mb-0">Update Stage</h6></div></div>
                <div class="rt-card-body">
                  <div class="rt-field-group">
                    <label class="rt-label" for="newStatus">Move to Stage <span class="rt-required">*</span></label>
                    <select id="newStatus" class="rt-input rt-select" onchange="onStatusChange()">
                      <option value="">Choose next stage…</option>
                      <option value="Under Review">🔍 Under Review</option>
                      <option value="Phone Screen">📞 Phone Screen</option>
                      <option value="Interview Scheduled">📅 Interview Scheduled</option>
                      <option value="Final Interview">👥 Final Interview</option>
                      <option value="Job Offer">📧 Job Offer</option>
                      <option value="Offer Accepted">🤝 Offer Accepted</option>
                      <option value="Hired">✅ Hired</option>
                      <option value="Rejected">❌ Rejected</option>
                      <option value="Withdrawn">🚫 Withdrawn</option>
                    </select>
                  </div>
                  <div class="rt-status-extra-fields" id="interviewDateWrap">
                    <div class="rt-field-group mb-2">
                      <label class="rt-label" for="interviewDate"><i class="fas fa-calendar me-1"></i>Interview Date</label>
                      <input type="date" id="interviewDate" class="rt-input" />
                    </div>
                  </div>
                  <div class="rt-status-extra-fields" id="offerDateWrap">
                    <div class="rt-field-group mb-2">
                      <label class="rt-label" for="offerDate"><i class="fas fa-calendar me-1"></i>Offer Date</label>
                      <input type="date" id="offerDate" class="rt-input" />
                    </div>
                  </div>
                  <div class="rt-field-group">
                    <label class="rt-label" for="hrNotes">Notes <span class="rt-optional">(optional)</span></label>
                    <textarea id="hrNotes" class="rt-input rt-textarea" placeholder="Observations, feedback, notes…"></textarea>
                  </div>
                  <button class="rt-btn rt-btn-primary w-100" onclick="submitDecision()">
                    <i class="fas fa-check me-2"></i>Save Decision
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer"><button class="rt-btn rt-btn-outline" data-bs-dismiss="modal">Close</button></div>
      </div>
    </div>
  </div>

  <!-- Post Job Modal — POSTs to /hr/jobs/create via fetch() -->
  <div class="modal fade" id="postJobModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="postJobModalTitle"><i class="fas fa-briefcase me-2"></i>Post a New Job Opening</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <div id="jobPostAlert" class="rt-alert"></div>
          <input type="hidden" id="editingJobId" value="" />
          <form id="postJobForm" enctype="multipart/form-data" novalidate>
            <?= csrf_field() ?>
            <div class="row g-3">
              <div class="col-12">
                <div class="rt-field-group">
                  <label class="rt-label" for="jobTitle">Job Title <span class="rt-required">*</span></label>
                  <input id="jobTitle" name="title" type="text" class="rt-input" placeholder="e.g. Senior Software Engineer"
                    data-required="true" data-label="Job title" data-min="3" /><span class="rt-field-error"></span>
                </div>
              </div>
              <div class="col-md-4">
                <div class="rt-field-group">
                  <label class="rt-label" for="jobDept">Department <span class="rt-required">*</span></label>
                  <select id="jobDept" name="department" class="rt-input rt-select" data-required="true" data-label="Department">
                    <option value="">Select…</option>
                    <option>IT Department</option><option>Human Resources</option><option>Finance</option>
                    <option>Operations</option><option>Marketing</option><option>Legal</option><option>Administration</option>
                  </select><span class="rt-field-error"></span>
                </div>
              </div>
              <div class="col-md-4">
                <div class="rt-field-group">
                  <label class="rt-label" for="jobType">Employment Type <span class="rt-required">*</span></label>
                  <select id="jobType" name="employment_type" class="rt-input rt-select" data-required="true" data-label="Employment type">
                    <option value="">Select…</option>
                    <option>Full-Time</option><option>Part-Time</option><option>Contract</option><option>Internship</option>
                  </select><span class="rt-field-error"></span>
                </div>
              </div>
              <div class="col-md-4">
                <div class="rt-field-group">
                  <label class="rt-label" for="jobArr">Arrangement <span class="rt-required">*</span></label>
                  <select id="jobArr" name="arrangement" class="rt-input rt-select" data-required="true" data-label="Arrangement">
                    <option value="">Select…</option>
                    <option>On-site</option><option>Remote</option><option>Hybrid</option>
                  </select><span class="rt-field-error"></span>
                </div>
              </div>
              <div class="col-md-6">
                <div class="rt-field-group">
                  <label class="rt-label" for="jobSalary">Salary Range <span class="rt-optional">(optional)</span></label>
                  <input id="jobSalary" name="salary_range" type="text" class="rt-input" placeholder="e.g. ₱25,000 – ₱35,000" />
                </div>
              </div>
              <div class="col-12">
                <div class="rt-field-group">
                  <label class="rt-label" for="jobDesc">Job Description <span class="rt-required">*</span></label>
                  <textarea id="jobDesc" name="description" class="rt-input rt-textarea" style="min-height:120px;"
                    placeholder="Describe the role, responsibilities, and qualifications…"
                    data-required="true" data-label="Description" data-min="20"></textarea>
                  <span class="rt-field-error"></span>
                </div>
              </div>
              <div class="col-12">
                <div class="rt-field-group">
                  <label class="rt-label" for="jobReqs">Requirements <span class="rt-optional">(optional)</span></label>
                  <textarea id="jobReqs" name="requirements" class="rt-input rt-textarea" style="min-height:80px;"
                    placeholder="List required skills, experience, education…"></textarea>
                </div>
              </div>
              <div class="col-12">
                <div class="rt-field-group mb-0">
                  <label class="rt-label">Cover Image <span class="rt-optional">(optional)</span></label>
                  <div class="rt-upload-zone" id="jobImgZone" onclick="document.getElementById('jobImgFile').click()" style="padding:16px;">
                    <div class="rt-upload-icon" style="font-size:1.5rem;"><i class="fas fa-image"></i></div>
                    <div class="rt-upload-label">Click to upload a job cover image</div>
                    <div class="rt-upload-hint">JPG, PNG, WebP — max 3 MB</div>
                  </div>
                  <!-- name="image" matches $this->request->getFile('image') in HRController -->
                  <input type="file" id="jobImgFile" name="image" accept="image/jpeg,image/png,image/webp" style="display:none;" />
                  <div id="jobImgPreview" class="mt-2"></div>
                </div>
              </div>
            </div>
          </form>
        </div>
        <div class="modal-footer">
          <button class="rt-btn rt-btn-outline" data-bs-dismiss="modal">Cancel</button>
          <button class="rt-btn rt-btn-primary" onclick="submitPostJob()" id="postJobSubmitBtn">
            <i class="fas fa-paper-plane me-1"></i>Publish Job
          </button>
        </div>
      </div>
    </div>
  </div>

  <!-- PDF Viewer Modal -->
  <div class="modal fade" id="pdfModal" tabindex="-1">
    <div class="modal-dialog modal-xl" style="max-width:900px;">
      <div class="modal-content" style="height:90vh;">
        <div class="modal-header">
          <h5 class="modal-title"><i class="fas fa-file-pdf me-2" style="color:var(--red);"></i><span id="pdfModalTitle">Resume Preview</span></h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body p-0" style="flex:1;overflow:hidden;">
          <div id="pdfViewerBody" style="width:100%;height:100%;"></div>
        </div>
      </div>
    </div>
  </div>

  <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script src="<?= base_url('assets/js/validation.js') ?>"></script>
  <script>
    const BASE_URL = "<?= base_url('/') ?>";
  </script>
  <script src="<?= base_url('assets/js/dashboard.js') ?>"></script>
  <script>
    // USER from PHP session — AuthFilter already verified this is a valid HR user
    const USER = <?= $userJson ?>;
    document.getElementById('topbarMount').innerHTML = initTopbar(USER);

    let currentAppId = null, currentApp = null;

    /* ── Tabs ── */
    const ALL_TABS = ['applications','jobs'];
    function switchTab(name, el) {
      document.querySelectorAll('.rt-tab').forEach(t => t.classList.remove('active'));
      el.classList.add('active');
      ALL_TABS.forEach(t => { document.getElementById('tab-' + t).style.display = t === name ? 'block' : 'none'; });
      if (name === 'applications') { initAppFilterBar(); loadApplications(); }
      if (name === 'jobs') { initJobFilterBar(); loadJobs(); }
    }

    /* ── Stats ── */
    async function renderStats() {
      const res   = await fetch('<?= base_url('api/applications/stats') ?>');
      const stats = await res.json();
      document.getElementById('statRow').innerHTML = `
        <div class="col-6 col-md-3"><div class="rt-stat-card rt-stat-card--blue">
          <div class="rt-stat-icon rt-stat-icon--blue"><i class="fas fa-file-lines"></i></div>
          <div class="rt-stat-num">${stats.total}</div><div class="rt-stat-label">Total Applications</div></div></div>
        <div class="col-6 col-md-3"><div class="rt-stat-card rt-stat-card--yellow">
          <div class="rt-stat-icon rt-stat-icon--yellow"><i class="fas fa-hourglass-half"></i></div>
          <div class="rt-stat-num">${stats.in_process}</div><div class="rt-stat-label">In Progress</div></div></div>
        <div class="col-6 col-md-3"><div class="rt-stat-card rt-stat-card--green">
          <div class="rt-stat-icon rt-stat-icon--green"><i class="fas fa-user-check"></i></div>
          <div class="rt-stat-num">${stats.hired}</div><div class="rt-stat-label">Hired</div></div></div>
        <div class="col-6 col-md-3"><div class="rt-stat-card rt-stat-card--red">
          <div class="rt-stat-icon rt-stat-icon--red"><i class="fas fa-times-circle"></i></div>
          <div class="rt-stat-num">${stats.rejected}</div><div class="rt-stat-label">Rejected</div></div></div>`;
    }

    /* ── Applications ── */
    function initAppFilterBar() {
      document.getElementById('appFilterBarMount').innerHTML = buildFilterBar('hrapp', {
        searchPlaceholder: 'Search applicant, code, position…',
        filters: [
          { id: 'hrapp_status', placeholder: 'All Statuses', width: '170px', options: APP_STATUSES.map(s => ({ value: s, label: s })) },
          { id: 'hrapp_dept',   placeholder: 'All Departments', width: '155px', options: ['IT Department','Human Resources','Finance','Operations','Marketing','Legal','Administration'] },
        ],
        sorts: [
          { value: 'submitted_at|desc', label: 'Newest first' },
          { value: 'submitted_at|asc',  label: 'Oldest first' },
          { value: 'resume_score|desc', label: 'Highest score' },
          { value: 'resume_score|asc',  label: 'Lowest score' },
          { value: 'status|asc',        label: 'A → Z (status)' },
        ],
        onChangeFn: 'loadApplications',
      });
    }

    async function loadApplications() {
      const { search, sortBy, sortDir, filters } = getFilterBarValues('hrapp');
      const params = new URLSearchParams({
        search: search || '', sort: sortBy || 'submitted_at', dir: sortDir || 'desc',
        status: filters['hrapp_status'] || '', dept: filters['hrapp_dept'] || '',
      });
      const res  = await fetch(`<?= base_url('api/applications') ?>?${params}`);
      const apps = await res.json();

      document.getElementById('appResultCount').textContent = apps.length + ' result(s)';
      const tbody = document.getElementById('hrTbody');
      if (!apps.length) { tbody.innerHTML = '<tr><td colspan="8" class="text-center py-4" style="color:var(--mid);">No applications match your filters.</td></tr>'; return; }
      tbody.innerHTML = apps.map(a => `
        <tr>
          <td><code style="font-size:.82rem;">${a.app_code}</code></td>
          <td><div class="d-flex align-items-center gap-2">
            <div class="rt-avatar rt-avatar--sm">${((a.first_name||'?')[0]+(a.last_name||'?')[0]).toUpperCase()}</div>
            <div><div style="font-weight:600;font-size:.85rem;">${a.first_name} ${a.last_name}</div>
            <div style="font-size:.74rem;color:var(--mid);">${a.email}</div></div>
          </div></td>
          <td style="max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${a.position}</td>
          <td style="max-width:130px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${a.department}</td>
          <td>${scoreBarHTML(a.resume_score)}</td>
          <td>${statusBadgeHTML(a.status)}</td>
          <td style="white-space:nowrap;">${a.submitted_at}</td>
          <td>
            <button class="rt-btn rt-btn-outline rt-btn-sm" onclick="openReview(${JSON.stringify(a).replace(/"/g,'&quot;')})">
              <i class="fas fa-clipboard-list me-1"></i>Review
            </button>
          </td>
        </tr>`).join('');
    }

    /* ── Review Modal ── */
    function openReview(app) {
      currentApp   = app;
      currentAppId = app.id;
      document.getElementById('reviewCode').textContent = app.app_code;

      document.getElementById('reviewApplicantInfo').innerHTML = `
        <div class="rt-detail-item"><label>Full Name</label><span>${app.first_name} ${app.last_name}</span></div>
        <div class="rt-detail-item"><label>Email</label><span>${app.email}</span></div>
        <div class="rt-detail-item"><label>Phone</label><span>${app.phone || '—'}</span></div>
        <div class="rt-detail-item"><label>Resume</label>
          <span class="rt-resume-file"><i class="fas fa-file-pdf" style="color:var(--red);flex-shrink:0;"></i>
          <span class="rt-resume-filename">${app.resume_name || '—'}</span></span>
          ${app.resume_name ? `<button class="rt-btn rt-btn-outline rt-btn-sm ms-2" onclick="openPdfViewer('${app.resume_name}','${app.app_code}')"><i class="fas fa-eye me-1"></i>View</button>` : ''}
        </div>
        <div class="rt-detail-item"><label>Submitted</label><span>${app.submitted_at}</span></div>`;

      document.getElementById('reviewAppDetails').innerHTML = `
        <div class="rt-detail-item"><label>Position</label><span>${app.position}</span></div>
        <div class="rt-detail-item"><label>Department</label><span>${app.department}</span></div>
        <div class="rt-detail-item"><label>Type</label><span>${app.employment_type}</span></div>
        <div class="rt-detail-item"><label>Arrangement</label><span>${app.arrangement}</span></div>
        <div class="rt-detail-item"><label>Current Status</label><span>${statusBadgeHTML(app.status)}</span></div>`;

      const sc = app.resume_score || 0;
      const scC = sc >= 80 ? 'var(--green)' : sc >= 65 ? 'var(--accent)' : 'var(--yellow)';
      document.getElementById('scoreDisplay').innerHTML = `
        <div style="font-family:var(--font-head);font-size:3rem;color:${scC};line-height:1;">${sc}</div>
        <div style="font-size:.8rem;color:var(--mid);margin-top:4px;">/ 100 — AI Resume Score</div>
        <div style="margin-top:12px;">${scoreBarHTML(sc)}</div>`;

      if (app.cover_letter) {
        document.getElementById('coverLetterCard').style.display = '';
        document.getElementById('coverLetterText').textContent = app.cover_letter;
      } else {
        document.getElementById('coverLetterCard').style.display = 'none';
      }

      document.getElementById('statusHistoryBody').innerHTML =
        '<div style="color:var(--mid);font-size:.82rem;">History available after status update.</div>';

      document.getElementById('newStatus').value = '';
      document.getElementById('hrNotes').value = '';
      document.getElementById('interviewDate').value = app.interview_date || '';
      document.getElementById('offerDate').value     = app.offer_date || '';
      document.getElementById('interviewDateWrap').classList.remove('show');
      document.getElementById('offerDateWrap').classList.remove('show');
      Validate.hideAlert('reviewAlert');
      new bootstrap.Modal(document.getElementById('reviewModal')).show();
    }

    function onStatusChange() {
      const s = document.getElementById('newStatus').value;
      document.getElementById('interviewDateWrap').classList.toggle('show', s === 'Interview Scheduled' || s === 'Final Interview');
      document.getElementById('offerDateWrap').classList.toggle('show',     s === 'Job Offer' || s === 'Hired');
    }

    async function submitDecision() {
      const status = document.getElementById('newStatus').value;
      const notes  = document.getElementById('hrNotes').value.trim();
      if (!status) { Validate.showAlert('reviewAlert', 'Please select a stage.', 'error'); return; }

      // POST to CI4 HRController::updateStatus() via fetch() with CSRF token
      const form = new FormData();
      form.append('status',         status);
      form.append('notes',          notes);
      form.append('interview_date', document.getElementById('interviewDate').value);
      form.append('offer_date',     document.getElementById('offerDate').value);
      form.append('<?= csrf_token() ?>', '<?= csrf_hash() ?>');  // CSRF for fetch() calls

      const res  = await fetch(`<?= base_url('hr/applications/') ?>${currentAppId}/status`, { method: 'POST', body: form });
      const data = await res.json();

      if (!data.ok) { Validate.showAlert('reviewAlert', data.msg || 'Error saving.', 'error'); return; }
      Validate.toast('Status updated to "' + status + '"', 'success');
      bootstrap.Modal.getInstance(document.getElementById('reviewModal')).hide();
      loadApplications();
      renderStats();
    }

    /* ── Jobs ── */
    function initJobFilterBar() {
      document.getElementById('jobViewToggleMount').innerHTML = buildViewToggle('hrjobs_viewmode', 'loadJobs');
      document.getElementById('jobFilterBarMount').innerHTML = buildFilterBar('hrjob', {
        searchPlaceholder: 'Search title, department…',
        filters: [
          { id: 'hrjob_dept',   placeholder: 'All Departments', width: '155px', options: ['IT Department','Human Resources','Finance','Operations','Marketing','Legal','Administration'] },
          { id: 'hrjob_type',   placeholder: 'All Types', width: '130px', options: ['Full-Time','Part-Time','Contract','Internship'] },
          { id: 'hrjob_active', placeholder: 'All Status', width: '120px', options: [{ value: '1', label: 'Active' }, { value: '0', label: 'Inactive' }] },
        ],
        sorts: [
          { value: 'created_at|desc', label: 'Newest first' },
          { value: 'created_at|asc',  label: 'Oldest first' },
          { value: 'title|asc',       label: 'A → Z' },
        ],
        onChangeFn: 'loadJobs',
      });
    }

    async function loadJobs() {
      const { search, sortBy, sortDir, filters } = getFilterBarValues('hrjob');
      const params = new URLSearchParams({
        search: search || '', sort: sortBy || 'created_at', dir: sortDir || 'desc',
        dept: filters['hrjob_dept'] || '', type: filters['hrjob_type'] || '',
      });
      const res  = await fetch(`<?= base_url('api/jobs') ?>?${params}`);
      const jobs = await res.json();

      document.getElementById('jobResultCount').textContent = jobs.length + ' posting(s)';
      const mode = document.getElementById('hrjobs_viewmode').value;
      document.getElementById('hrJobsContainer').innerHTML =
        jobs.length ? renderHRJobsUI(jobs, mode) : '<div class="rt-empty-state"><i class="fas fa-briefcase"></i><p>No job postings yet. Click "Post a Job" to add one.</p></div>';
    }

    function renderHRJobsUI(jobs, mode) {
      if (mode === 'list') {
        return `<div class="rt-table-wrap"><table class="rt-table"><thead><tr>
          <th>Code</th><th>Title</th><th>Dept</th><th>Type</th><th>Arrangement</th><th>Status</th><th>Actions</th>
        </tr></thead><tbody>` + jobs.map(j => `<tr>
          <td><code style="font-size:.82rem;">${j.job_code}</code></td>
          <td style="font-weight:600;">${j.title}</td>
          <td>${j.department}</td>
          <td><span class="rt-badge rt-badge-for-review">${j.employment_type}</span></td>
          <td>${j.arrangement}</td>
          <td>${j.is_active ? '<span class="rt-badge rt-badge-active">Active</span>' : '<span class="rt-badge rt-badge-inactive">Inactive</span>'}</td>
          <td>${hrJobActions(j)}</td>
        </tr>`).join('') + '</tbody></table></div>';
      }
      return '<div class="row g-3">' + jobs.map(j => `
        <div class="col-md-6 col-lg-4"><div class="rt-job-card ${!j.is_active ? 'rt-job-card--inactive' : ''}">
          <div class="rt-job-card-body">
            <div class="d-flex align-items-start justify-content-between gap-2 mb-2">
              <div><div class="rt-job-card-code">${j.job_code}</div><h3 class="rt-job-card-title">${j.title}</h3></div>
              ${j.is_active ? '<span class="rt-badge rt-badge-active">Active</span>' : '<span class="rt-badge rt-badge-inactive">Inactive</span>'}
            </div>
            <div class="rt-job-card-meta">
              <span><i class="fas fa-building me-1"></i>${j.department}</span>
              <span><i class="fas fa-clock me-1"></i>${j.employment_type}</span>
              <span><i class="fas fa-map-pin me-1"></i>${j.arrangement}</span>
            </div>
            <div class="rt-job-card-footer mt-3">${hrJobActions(j)}</div>
          </div>
        </div></div>`).join('') + '</div>';
    }

    function hrJobActions(j) {
      return `<button class="rt-btn rt-btn-outline rt-btn-sm me-1" onclick="openEditJob(${JSON.stringify(j).replace(/"/g,'&quot;')})">
          <i class="fas fa-pen me-1"></i>Edit</button>
        <button class="rt-btn rt-btn-sm me-1 ${j.is_active ? 'rt-btn-outline' : 'rt-btn-primary'}" onclick="toggleJob(${j.id})">
          <i class="fas fa-${j.is_active ? 'eye-slash' : 'eye'} me-1"></i>${j.is_active ? 'Deactivate' : 'Activate'}</button>
        <button class="rt-btn rt-btn-danger rt-btn-sm" onclick="deleteJob(${j.id})">
          <i class="fas fa-trash me-1"></i>Delete</button>`;
    }

    function openEditJob(job) {
      document.getElementById('editingJobId').value = job.id;
      document.getElementById('jobTitle').value       = job.title;
      document.getElementById('jobDept').value        = job.department;
      document.getElementById('jobType').value        = job.employment_type;
      document.getElementById('jobArr').value         = job.arrangement;
      document.getElementById('jobSalary').value      = job.salary_range || '';
      document.getElementById('jobDesc').value        = job.description || '';
      document.getElementById('jobReqs').value        = job.requirements || '';
      document.getElementById('postJobModalTitle').innerHTML = '<i class="fas fa-pen me-2"></i>Edit Job Posting';
      document.getElementById('postJobSubmitBtn').innerHTML = '<i class="fas fa-save me-1"></i>Save Changes';
      new bootstrap.Modal(document.getElementById('postJobModal')).show();
    }

    async function submitPostJob() {
  if (!Validate.validateForm($('#postJobForm'))) return;
  const editId = document.getElementById('editingJobId').value;
  const url = editId
    ? `${BASE_URL}hr/jobs/${editId}/update`
    : `${BASE_URL}hr/jobs/create`;

  const form = new FormData(document.getElementById('postJobForm'));
  form.append('<?= csrf_token() ?>', '<?= csrf_hash() ?>');

  try {
    const res  = await fetch(url, { method: 'POST', body: form });
    if (!res.ok) {
      Validate.showAlert('jobPostAlert', `Server error: ${res.status}. Check CSRF config.`, 'error');
      return;
    }
    const data = await res.json();
    if (!data.ok) { Validate.showAlert('jobPostAlert', data.msg || 'Error.', 'error'); return; }
    Validate.toast(editId ? 'Job updated!' : 'Job posted!', 'success');
    bootstrap.Modal.getInstance(document.getElementById('postJobModal')).hide();
    document.getElementById('postJobForm').reset();
    document.getElementById('editingJobId').value = '';
    loadJobs();
  } catch (e) {
    Validate.showAlert('jobPostAlert', 'Request failed — possible CSRF or network error.', 'error');
  }
}

    async function toggleJob(id) {
      const form = new FormData();
      form.append('<?= csrf_token() ?>', '<?= csrf_hash() ?>');
      await fetch(`<?= base_url('hr/jobs/') ?>${id}/toggle`, { method: 'POST', body: form });
      loadJobs();
    }

    async function deleteJob(id) {
      if (!confirm('Delete this job posting? This cannot be undone.')) return;
      const form = new FormData();
      form.append('<?= csrf_token() ?>', '<?= csrf_hash() ?>');
      await fetch(`<?= base_url('hr/jobs/') ?>${id}/delete`, { method: 'POST', body: form });
      Validate.toast('Job deleted.', 'success');
      loadJobs();
    }

    /* ── PDF Viewer ── */
    function openPdfViewer(filename, appCode) {
      document.getElementById('pdfModalTitle').textContent = filename;
      document.getElementById('pdfViewerBody').innerHTML =
        `<iframe src="<?= base_url('api/resumes/') ?>${appCode}" style="width:100%;height:100%;border:none;"></iframe>`;
      new bootstrap.Modal(document.getElementById('pdfModal')).show();
    }

    /* ── Job image preview in modal ── */
    document.getElementById('jobImgFile').addEventListener('change', function() {
      const f = this.files[0];
      if (!f) { document.getElementById('jobImgPreview').innerHTML = ''; return; }
      const r = new FileReader();
      r.onload = e => {
        document.getElementById('jobImgPreview').innerHTML =
          `<img src="${e.target.result}" style="max-height:120px;border-radius:var(--r-sm);margin-top:4px;" />`;
      };
      r.readAsDataURL(f);
    });

    Validate.bindLive($('#postJobForm'));

    /* ── Init ── */
    renderStats();
    initAppFilterBar();
    loadApplications();
  </script>
</body>
</html>
