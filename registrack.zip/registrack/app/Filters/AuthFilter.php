<?php
// app/Filters/AuthFilter.php
// Replaces Auth.requireRole() in JavaScript — runs on the server before page render.
namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

class AuthFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        $session = session();
        $user    = $session->get('user');

        // Not logged in at all → redirect to login
        if (!$user) {
            return redirect()->to('/login');
        }

        // A role argument was passed (e.g. 'auth:admin').
        // Check the logged-in user actually has that role.
        if (!empty($arguments) && !in_array($user['role'], $arguments)) {
            $map = [
                'admin'     => '/admin/dashboard',
                'hr'        => '/hr/dashboard',
                'applicant' => '/applicant/dashboard',
            ];
            return redirect()->to($map[$user['role']] ?? '/login');
        }
    }

    // after() is required by the interface but we don't need it
    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null) {}
}
