<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - T&N Company</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/style.css'); ?>">
</head>
<body class="bg-light">
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-6">
            <div class="text-center mb-4">
                <a href="<?php echo base_url(); ?>" class="text-decoration-none">
                    <h3 class="fw-bold"><span class="text-primary">T</span>&<span class="text-danger">N</span> Company</h3>
                </a>
                <p class="text-muted small">Create your applicant account</p>
            </div>
            <div class="d-flex justify-content-center mb-2">
                <div class="step-indicator">
                    <div class="step-circle active" id="c1">1</div>
                    <div id="l1"><div class="step-line"></div></div>
                    <div class="step-circle inactive" id="c2">2</div>
                    <div id="l2"><div class="step-line"></div></div>
                    <div class="step-circle inactive" id="c3">3</div>
                </div>
            </div>
            <div class="d-flex justify-content-center mb-4">
                <span id="lbl1" class="text-primary fw-semibold" style="width:110px;text-align:center;font-size:.72rem">PERSONAL INFO</span>
                <span id="lbl2" class="text-muted" style="width:110px;text-align:center;font-size:.72rem">ACCOUNT</span>
                <span id="lbl3" class="text-muted" style="width:110px;text-align:center;font-size:.72rem">CONFIRM</span>
            </div>
            <div class="card shadow-sm p-4 p-md-5">
                <div id="signupFormContainer"></div>
            </div>
            <div class="text-center mt-3">
                <p class="text-muted small mb-1">Already have an account? <a href="<?php echo base_url('signin'); ?>" class="text-primary fw-medium">Sign In</a></p>
                <a href="<?php echo base_url(); ?>" class="text-muted text-decoration-none small"><i class="fas fa-arrow-left me-1"></i>Back to Home</a>
            </div>
        </div>
    </div>
</div>
<div class="toast-container-custom"></div>
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo base_url('assets/js/utils.js'); ?>"></script>
<script>
const SIGNUP_URL = '<?php echo base_url("signup"); ?>';
const SIGNIN_URL = '<?php echo base_url("signin"); ?>';
const TERMS_URL  = '<?php echo base_url("terms"); ?>';
const PRIVACY_URL= '<?php echo base_url("privacy"); ?>';
let step=1, fd={};

function circles(){
    [1,2,3].forEach(s=>{
        const c=$('#c'+s);c.removeClass('active completed inactive');
        if(s<step) c.addClass('completed').html('<i class="fas fa-check" style="font-size:.65rem"></i>');
        else if(s===step) c.addClass('active').text(s);
        else c.addClass('inactive').text(s);
        $('#l'+s+' .step-line').toggleClass('completed',s<step);
    });
    ['#lbl1','#lbl2','#lbl3'].forEach((id,i)=>{
        $(id).toggleClass('text-primary fw-semibold',i+1===step).toggleClass('text-muted',i+1!==step);
    });
}
function show(s){
    step=s; circles();
    const c=$('#signupFormContainer');
    if(s===1) c.html(step1Html());
    else if(s===2) c.html(step2Html());
    else c.html(step3Html());
}
function step1Html(){return `
    <h5 class="fw-bold text-center mb-1">Personal Information</h5>
    <p class="text-muted text-center small mb-4">Tell us about yourself.</p>
    <div class="row g-3">
        <div class="col-6"><label class="form-label small">First Name *</label><input class="form-control" id="fn" value="${fd.fn||''}" placeholder="Juan"></div>
        <div class="col-6"><label class="form-label small">Last Name *</label><input class="form-control" id="ln" value="${fd.ln||''}" placeholder="Dela Cruz"></div>
        <div class="col-6"><label class="form-label small">Date of Birth *</label><input type="date" class="form-control" id="dob" value="${fd.dob||''}"></div>
        <div class="col-6"><label class="form-label small">Gender *</label>
            <select class="form-select" id="gen"><option value="">Select</option>
                <option value="male" ${fd.gen==='male'?'selected':''}>Male</option>
                <option value="female" ${fd.gen==='female'?'selected':''}>Female</option>
                <option value="other" ${fd.gen==='other'?'selected':''}>Other</option></select></div>
        <div class="col-6"><label class="form-label small">Phone *</label><input class="form-control" id="ph" value="${fd.ph||''}" placeholder="+63 912 345 6789"></div>
        <div class="col-6"><label class="form-label small">Email *</label><input type="email" class="form-control" id="em" value="${fd.em||''}" placeholder="you@email.com"></div>
        <div class="col-12"><label class="form-label small">Address *</label><textarea class="form-control" id="addr" rows="2">${fd.addr||''}</textarea></div>
        <div class="col-12"><button class="btn btn-primary w-100" onclick="s1next()">Next <i class="fas fa-arrow-right ms-1"></i></button></div>
    </div>`;}
function step2Html(){return `
    <h5 class="fw-bold text-center mb-1">Account Setup</h5>
    <p class="text-muted text-center small mb-4">Create your login credentials.</p>
    <div class="row g-3">
        <div class="col-12"><label class="form-label small">Email</label><input class="form-control" value="${fd.em}" disabled></div>
        <div class="col-12"><label class="form-label small">Password *</label>
            <div class="input-group"><input type="password" class="form-control" id="pw" value="${fd.pw||''}" placeholder="Min. 6 characters">
            <button class="btn btn-outline-secondary" type="button" onclick="const e=$('#pw');e.attr('type',e.attr('type')==='password'?'text':'password')"><i class="fas fa-eye"></i></button></div></div>
        <div class="col-12"><label class="form-label small">Confirm Password *</label>
            <div class="input-group"><input type="password" class="form-control" id="cpw" value="${fd.cpw||''}" placeholder="Re-enter password">
            <button class="btn btn-outline-secondary" type="button" onclick="const e=$('#cpw');e.attr('type',e.attr('type')==='password'?'text':'password')"><i class="fas fa-eye"></i></button></div></div>
        <div class="col-12"><div class="form-check"><input class="form-check-input" type="checkbox" id="terms" ${fd.terms?'checked':''}>
            <label class="form-check-label small" for="terms">I agree to the <a href="${TERMS_URL}" target="_blank">Terms</a> and <a href="${PRIVACY_URL}" target="_blank">Privacy Policy</a></label></div></div>
        <div class="col-12 d-flex gap-2">
            <button class="btn btn-outline-secondary flex-fill" onclick="show(1)"><i class="fas fa-arrow-left me-1"></i>Back</button>
            <button class="btn btn-primary flex-fill" onclick="s2next()">Next <i class="fas fa-arrow-right ms-1"></i></button></div>
    </div>`;}
function step3Html(){const gm={male:'Male',female:'Female',other:'Other'};return `
    <h5 class="fw-bold text-center mb-1">Confirm Details</h5>
    <p class="text-muted text-center small mb-4">Review before submitting.</p>
    <div class="bg-light rounded-3 p-3 mb-3">
        <div class="row g-2 small">
            <div class="col-6"><div class="text-muted">Full Name</div><div class="fw-medium">${fd.fn} ${fd.ln}</div></div>
            <div class="col-6"><div class="text-muted">Date of Birth</div><div class="fw-medium">${fd.dob}</div></div>
            <div class="col-6"><div class="text-muted">Gender</div><div class="fw-medium">${gm[fd.gen]||'—'}</div></div>
            <div class="col-6"><div class="text-muted">Phone</div><div class="fw-medium">${fd.ph}</div></div>
            <div class="col-12"><div class="text-muted">Email</div><div class="fw-medium">${fd.em}</div></div>
            <div class="col-12"><div class="text-muted">Address</div><div class="fw-medium">${fd.addr}</div></div>
        </div>
    </div>
    <div class="d-flex gap-2">
        <button class="btn btn-outline-secondary flex-fill" onclick="show(2)"><i class="fas fa-arrow-left me-1"></i>Back</button>
        <button class="btn btn-success flex-fill" onclick="submitSignup()"><i class="fas fa-check me-1"></i>Create Account</button></div>`;}

function s1next(){
    const fn=$('#fn').val().trim(),ln=$('#ln').val().trim(),dob=$('#dob').val(),gen=$('#gen').val(),ph=$('#ph').val().trim(),em=$('#em').val().trim(),addr=$('#addr').val().trim();
    if(!fn||!ln||!dob||!gen||!ph||!em||!addr){showToast('Fill in all required fields.','warning');return;}
    if(!/\S+@\S+\.\S+/.test(em)){showToast('Invalid email.','warning');return;}
    Object.assign(fd,{fn,ln,dob,gen,ph,em,addr}); show(2);
}
function s2next(){
    const pw=$('#pw').val(),cpw=$('#cpw').val(),terms=$('#terms').is(':checked');
    if(!pw||pw.length<6){showToast('Password must be at least 6 characters.','warning');return;}
    if(pw!==cpw){showToast('Passwords do not match.','warning');return;}
    if(!terms){showToast('Please accept the Terms of Service.','warning');return;}
    Object.assign(fd,{pw,cpw,terms:true}); show(3);
}
function submitSignup(){
    $.ajax({
        url:SIGNUP_URL, method:'POST',
        data:{first_name:fd.fn,last_name:fd.ln,dob:fd.dob,gender:fd.gen,phone:fd.ph,email:fd.em,address:fd.addr,password:fd.pw,confirm_password:fd.cpw},
        success:function(r){
            if(r.success){showToast(r.message,'success',2500);setTimeout(()=>window.location.href=SIGNIN_URL,2500);}
            else showToast(r.message,'error');
        },
        error:function(){showToast('Server error.','error');}
    });
}
$(()=>show(1));
</script>
</body>
</html>
