<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Applicant Dashboard - T&N Company</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/style.css'); ?>">
</head>
<body>
<button class="mobile-toggle" id="mobileToggle"><i class="fas fa-bars"></i></button>
<div class="sb-overlay sidebar-overlay"></div>
<div class="sidebar">
    <div class="sidebar-logo">
        <h5 class="fw-bold mb-0"><span class="text-primary">T</span>&<span class="text-danger">N</span> Company</h5>
        <p class="text-muted small mb-0">Applicant Portal</p>
    </div>
    <div class="sidebar-menu">
        <a class="sidebar-item active" id="nav-dash"><i class="fas fa-home"></i> Dashboard</a>
        <a class="sidebar-item" id="nav-jobs"><i class="fas fa-briefcase"></i> Browse Jobs</a>
        <a class="sidebar-item" id="nav-profile"><i class="fas fa-user"></i> Profile</a>
        <hr class="my-3">
        <a class="sidebar-item text-danger" id="logoutBtn"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>
</div>
<div class="main-content bg-light">
    <div class="container-fluid px-4">

        <!-- DASHBOARD -->
        <div class="dsec active" id="sec-dash">
            <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
                <div>
                    <h3 class="fw-bold mb-0">My Applications</h3>
                    <p class="text-muted mb-0">Welcome back, <?php echo $user['name']; ?></p>
                </div>
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#newAppModal">
                    <i class="fas fa-plus me-2"></i>New Application
                </button>
            </div>
            <div class="row g-3 mb-4">
                <div class="col-6 col-md-3"><div class="card stat-card"><div class="card-body text-center"><h3 class="fw-bold" id="st-total">0</h3><p class="text-muted mb-0 small">Total</p></div></div></div>
                <div class="col-6 col-md-3"><div class="card stat-card"><div class="card-body text-center"><h3 class="fw-bold text-warning" id="st-pending">0</h3><p class="text-muted mb-0 small">Pending</p></div></div></div>
                <div class="col-6 col-md-3"><div class="card stat-card"><div class="card-body text-center"><h3 class="fw-bold text-primary" id="st-review">0</h3><p class="text-muted mb-0 small">Under Review</p></div></div></div>
                <div class="col-6 col-md-3"><div class="card stat-card"><div class="card-body text-center"><h3 class="fw-bold text-success" id="st-approved">0</h3><p class="text-muted mb-0 small">Approved</p></div></div></div>
            </div>
            <div class="row mb-3 g-2">
                <div class="col-md-9"><input type="text" class="form-control" id="search" placeholder="Search by position, ID, department..."></div>
                <div class="col-md-3"><select class="form-select" id="statusF"><option value="">All Status</option><option value="pending">Pending</option><option value="review">Under Review</option><option value="approved">Approved</option><option value="rejected">Rejected</option></select></div>
            </div>
            <div class="card"><div class="card-body p-0"><div class="table-responsive">
                <table class="table table-applications mb-0">
                    <thead><tr>
                        <th class="ps-3">APP ID</th><th>Position</th><th>Department</th><th>Submitted</th><th>Status</th><th class="pe-3">Action</th>
                    </tr></thead>
                    <tbody id="appTable"><tr><td colspan="6" class="text-center py-5"><div class="spinner-border spinner-border-sm text-primary"></div></td></tr></tbody>
                </table>
            </div></div></div>
        </div>

        <!-- BROWSE JOBS -->
        <div class="dsec" id="sec-jobs">
            <div class="mb-4"><h3 class="fw-bold mb-0">Browse Open Positions</h3><p class="text-muted mb-0">Apply to available job openings</p></div>
            <div class="row mb-3 g-2">
                <div class="col-md-8"><input type="text" class="form-control" id="jobSearch" placeholder="Search position or department..."></div>
                <div class="col-md-4"><select class="form-select" id="jobDeptF"><option value="">All Departments</option><option>Information Technology</option><option>Human Resources</option><option>Finance</option><option>Education</option><option>Marketing</option><option>Operations</option></select></div>
            </div>
            <div id="jobsList"><div class="text-center py-5 text-muted"><div class="spinner-border text-primary"></div></div></div>
        </div>

        <!-- PROFILE -->
        <div class="dsec" id="sec-profile">
            <h3 class="fw-bold mb-4">My Profile</h3>
            <div class="row g-4">
                <div class="col-md-4">
                    <div class="card text-center p-4">
                        <div class="avatar-circle mx-auto mb-3" style="font-size:1.8rem"><?php echo strtoupper(substr($user['first_name'],0,1).substr($user['last_name'],0,1)); ?></div>
                        <h5 class="fw-bold"><?php echo $user['name']; ?></h5>
                        <p class="text-muted small"><?php echo $user['email']; ?></p>
                        <span class="badge bg-primary">Applicant</span><hr>
                        <div class="row text-center">
                            <div class="col-6"><h4 class="fw-bold text-primary" id="pr-total">0</h4><p class="text-muted small mb-0">Applications</p></div>
                            <div class="col-6"><h4 class="fw-bold text-success" id="pr-approved">0</h4><p class="text-muted small mb-0">Approved</p></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="card p-4">
                        <h6 class="fw-bold mb-3">Contact Information</h6>
                        <div class="row g-3">
                            <div class="col-md-6"><label class="form-label small fw-medium">Phone Number</label><input type="tel" class="form-control" id="pr-phone"></div>
                            <div class="col-12"><label class="form-label small fw-medium">Address</label><textarea class="form-control" id="pr-addr" rows="3"></textarea></div>
                            <div class="col-12"><button class="btn btn-primary" id="saveProfile"><i class="fas fa-save me-2"></i>Save Changes</button></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- New Application Modal -->
<div class="modal fade" id="newAppModal" tabindex="-1"><div class="modal-dialog modal-lg"><div class="modal-content">
    <div class="modal-header"><h5 class="modal-title fw-bold"><i class="fas fa-paper-plane text-primary me-2"></i>Submit New Application</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
    <div class="modal-body">
        <div class="mb-3"><label class="form-label fw-medium">Job Position <span class="text-danger">*</span></label><select class="form-select" id="newJobId"><option value="">Loading...</option></select><div class="form-text">Only open positions are listed.</div></div>
        <div class="mb-3"><label class="form-label fw-medium">Department</label><input type="text" class="form-control" id="newDept" readonly placeholder="Auto-filled from selected job"></div>
        <div class="mb-3"><label class="form-label fw-medium">Upload Resume (PDF)</label><input type="file" class="form-control" id="newResume" accept=".pdf"><div class="form-text">PDF only. Max 5MB.</div></div>
        <div class="mb-3"><label class="form-label fw-medium">Additional Notes</label><textarea class="form-control" id="newNotes" rows="3" placeholder="Any additional info..."></textarea></div>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-primary" id="submitAppBtn"><i class="fas fa-paper-plane me-2"></i>Submit Application</button>
    </div>
</div></div></div>

<!-- View Modal -->
<div class="modal fade" id="viewModal" tabindex="-1"><div class="modal-dialog"><div class="modal-content">
    <div class="modal-header"><h5 class="modal-title fw-bold">Application Details</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
    <div class="modal-body" id="viewBody"></div>
    <div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button></div>
</div></div></div>

<div class="toast-container-custom"></div>
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo base_url('assets/js/utils.js'); ?>"></script>
<script>
const BASE='<?php echo base_url(); ?>';
const SL={pending:'Pending',review:'Under Review',approved:'Approved',rejected:'Rejected'};
let allApps=[], allJobs=[];

function loadStats(){
    $.get(BASE+'applicant/api/stats',function(r){
        if(!r.success) return;
        const c=r.data;
        $('#st-total').text(c.total);$('#st-pending').text(c.pending);
        $('#st-review').text(c.review);$('#st-approved').text(c.approved);
        $('#pr-total').text(c.total);$('#pr-approved').text(c.approved);
    });
}
function loadApps(){
    $.get(BASE+'applicant/api/applications',function(r){
        if(!r.success) return;
        allApps=r.data; renderTable();
    });
}
function renderTable(){
    const s=$('#search').val().toLowerCase(), st=$('#statusF').val();
    let apps=[...allApps];
    if(s) apps=apps.filter(a=>a.position.toLowerCase().includes(s)||a.app_code.toLowerCase().includes(s)||a.department.toLowerCase().includes(s));
    if(st) apps=apps.filter(a=>a.status===st);
    const tb=$('#appTable');tb.html('');
    if(!apps.length){tb.html('<tr><td colspan="6" class="text-center py-5 text-muted"><i class="fas fa-inbox fa-2x d-block mb-2"></i>No applications found.</td></tr>');return;}
    apps.forEach(a=>{
        tb.append(`<tr>
            <td class="ps-3 fw-medium small">${a.app_code}</td>
            <td>${a.position}</td>
            <td><span class="badge bg-light text-dark">${a.department}</span></td>
            <td class="small">${a.submitted_fmt}</td>
            <td><span class="status-badge status-${a.status}">${SL[a.status]}</span></td>
            <td class="pe-3"><button class="btn btn-sm btn-outline-secondary view-btn" data-code="${a.app_code}"><i class="fas fa-eye me-1"></i>View</button></td>
        </tr>`);
    });
}
$('#search,#statusF').on('input change',renderTable);

function loadJobs(){
    $.get(BASE+'applicant/api/jobs',function(r){
        if(!r.success) return;
        allJobs=r.data; renderJobsList();
    });
}
function renderJobsList(){
    const s=$('#jobSearch').val().toLowerCase(), d=$('#jobDeptF').val();
    let jobs=[...allJobs];
    if(s) jobs=jobs.filter(j=>j.title.toLowerCase().includes(s)||j.department_name.toLowerCase().includes(s));
    if(d) jobs=jobs.filter(j=>j.department_name===d);
    const c=$('#jobsList');c.html('');
    if(!jobs.length){c.html('<div class="text-center py-5 text-muted"><i class="fas fa-briefcase fa-2x d-block mb-2"></i>No open positions found.</div>');return;}
    jobs.forEach(j=>{
        c.append(`<div class="card mb-3"><div class="card-body">
            <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
                <div><h5 class="fw-bold mb-1">${j.title}</h5><span class="dept-badge me-2">${j.department_name}</span><span class="badge bg-success bg-opacity-10 text-success">Open</span></div>
                ${j.already_applied?'<span class="badge bg-primary py-2 px-3">Already Applied</span>':`<button class="btn btn-primary btn-sm apply-job-btn" data-id="${j.id}" data-title="${j.title}" data-dept="${j.department_name}"><i class="fas fa-paper-plane me-1"></i>Apply Now</button>`}
            </div>
            <p class="text-muted small mt-2 mb-2">${j.description||''}</p>
            <div class="small"><strong>Requirements:</strong> ${j.requirements||'—'}</div>
            <div class="small text-muted mt-1"><i class="fas fa-calendar me-1"></i>Posted ${j.created_fmt}</div>
        </div></div>`);
    });
}
$('#jobSearch,#jobDeptF').on('input change',renderJobsList);

$('#newAppModal').on('show.bs.modal',function(){
    const sel=$('#newJobId');sel.html('<option value="">Select an open position...</option>');
    allJobs.forEach(j=>sel.append(`<option value="${j.id}" data-dept="${j.department_name}" ${j.already_applied?'disabled':''}>${j.title} — ${j.department_name}${j.already_applied?' (Already Applied)':''}</option>`));
    if(!allJobs.length) sel.html('<option value="">No open positions available</option>');
});
$('#newJobId').on('change',function(){$('#newDept').val($('option:selected',this).data('dept')||'');});

$(document).on('click','.apply-job-btn',function(){
    $('#newJobId').val($(this).data('id')).trigger('change');
    new bootstrap.Modal($('#newAppModal')[0]).show();
});

$('#submitAppBtn').on('click',function(){
    const jobId=$('#newJobId').val();
    if(!jobId){showToast('Please select a job position.','warning');return;}
    const fd=new FormData();
    fd.append('job_id',jobId);fd.append('notes',$('#newNotes').val());
    const file=$('#newResume')[0].files[0];
    if(file) fd.append('resume',file);
    $(this).prop('disabled',true).html('<span class="spinner-border spinner-border-sm me-2"></span>Submitting...');
    $.ajax({
        url:BASE+'applicant/api/apply',method:'POST',data:fd,processData:false,contentType:false,
        success:function(r){
            if(r.success){
                showToast(r.message,'success');
                bootstrap.Modal.getInstance($('#newAppModal')[0]).hide();
                $('#newJobId,#newDept,#newNotes').val('');$('#newResume').val('');
                loadStats();loadApps();loadJobs();
            } else showToast(r.message,'error');
            $('#submitAppBtn').prop('disabled',false).html('<i class="fas fa-paper-plane me-2"></i>Submit Application');
        },
        error:function(){showToast('Server error.','error');$('#submitAppBtn').prop('disabled',false).html('<i class="fas fa-paper-plane me-2"></i>Submit Application');}
    });
});

$(document).on('click','.view-btn',function(){
    const code=$(this).data('code'), a=allApps.find(x=>x.app_code===code); if(!a) return;
    $('#viewBody').html(`
        <div class="d-flex justify-content-between align-items-start mb-3">
            <div><h5 class="fw-bold mb-0">${a.position}</h5><small class="text-muted">${a.department}</small></div>
            <span class="status-badge status-${a.status}">${SL[a.status]}</span>
        </div>
        <div class="app-detail-row"><span class="text-muted">Application ID</span><strong>${a.app_code}</strong></div>
        <div class="app-detail-row"><span class="text-muted">Submitted</span><span>${a.submitted_fmt}</span></div>
        <div class="app-detail-row"><span class="text-muted">Status</span><span class="status-badge status-${a.status}">${SL[a.status]}</span></div>
        ${a.notes?`<div class="app-detail-row"><span class="text-muted">Your Notes</span><span>${a.notes}</span></div>`:''}
        ${a.review_notes?`<div class="app-detail-row"><span class="text-muted">HR Notes</span><span>${a.review_notes}</span></div>`:''}
        ${a.reviewer_name?`<div class="app-detail-row"><span class="text-muted">Reviewed By</span><span>${a.reviewer_name}</span></div>`:''}
        ${a.resume_url?`<div class="mt-3"><a href="${a.resume_url}" target="_blank" class="btn btn-sm btn-outline-primary"><i class="fas fa-file-pdf me-1"></i>View Resume</a></div>`:'<div class="mt-2 small text-muted">No resume uploaded.</div>'}
    `);
    new bootstrap.Modal($('#viewModal')[0]).show();
});

$('#saveProfile').on('click',function(){
    $.post(BASE+'applicant/api/profile',{phone:$('#pr-phone').val(),address:$('#pr-addr').val()},function(r){
        showToast(r.success?'Profile saved!':r.message,r.success?'success':'error');
    });
});

function showSec(id,el){$('.dsec').removeClass('active');$('#'+id).addClass('active');$('.sidebar-item').removeClass('active');$(el).addClass('active');}
$('#nav-dash').on('click',function(){showSec('sec-dash',this);loadStats();loadApps();});
$('#nav-jobs').on('click',function(){showSec('sec-jobs',this);loadJobs();});
$('#nav-profile').on('click',function(){showSec('sec-profile',this);loadStats();});
$('#logoutBtn').on('click',()=>window.location.href=BASE+'signout');
$('#mobileToggle').on('click',()=>{$('.sidebar').toggleClass('open');$('.sb-overlay').toggleClass('show');});
$('.sb-overlay').on('click',()=>{$('.sidebar').removeClass('open');$('.sb-overlay').removeClass('show');});

$(()=>{loadStats();loadApps();});
</script>
</body>
</html>
