<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HR Dashboard - T&N Company</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/style.css'); ?>">
</head>
<body>
<button class="mobile-toggle" id="mobileToggle"><i class="fas fa-bars"></i></button>
<div class="sb-overlay sidebar-overlay"></div>
<div class="sidebar">
    <div class="sidebar-logo">
        <h5 class="fw-bold mb-0"><span class="text-primary">T</span>&<span class="text-danger">N</span> Company</h5>
        <p class="text-muted small mb-0">HR Staff Portal</p>
    </div>
    <div class="sidebar-menu">
        <a class="sidebar-item active" id="nav-dash"><i class="fas fa-home"></i> Dashboard</a>
        <a class="sidebar-item" id="nav-apps"><i class="fas fa-file-alt"></i> Applications</a>
        <a class="sidebar-item" id="nav-jobs"><i class="fas fa-briefcase"></i> Job Postings</a>
        <a class="sidebar-item" id="nav-audit"><i class="fas fa-history"></i> Audit Log</a>
        <hr class="my-3">
        <div class="px-3 py-1"><p class="text-muted small mb-0">Logged in as</p><p class="fw-medium small mb-0"><?php echo $user['name']; ?></p></div>
        <hr class="my-3">
        <a class="sidebar-item text-danger" id="logoutBtn"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>
</div>
<div class="main-content bg-light">
    <div class="container-fluid px-4">

        <!-- DASHBOARD -->
        <div class="dsec active" id="sec-dash">
            <div class="mb-4"><h3 class="fw-bold">HR Dashboard</h3><p class="text-muted mb-0">Review and manage all applications</p></div>
            <div class="row g-3 mb-4">
                <div class="col-6 col-md"><div class="card stat-card" style="background:#bfdbfe"><div class="card-body text-center py-3"><h3 class="fw-bold" id="hs-total">0</h3><p class="mb-0 small">Total</p></div></div></div>
                <div class="col-6 col-md"><div class="card stat-card" style="background:#fef9c3"><div class="card-body text-center py-3"><h3 class="fw-bold" id="hs-pend">0</h3><p class="mb-0 small">Pending</p></div></div></div>
                <div class="col-6 col-md"><div class="card stat-card" style="background:#f3e8ff"><div class="card-body text-center py-3"><h3 class="fw-bold" id="hs-rev">0</h3><p class="mb-0 small">Under Review</p></div></div></div>
                <div class="col-6 col-md"><div class="card stat-card" style="background:#dcfce7"><div class="card-body text-center py-3"><h3 class="fw-bold" id="hs-app">0</h3><p class="mb-0 small">Approved</p></div></div></div>
                <div class="col-6 col-md"><div class="card stat-card" style="background:#fee2e2"><div class="card-body text-center py-3"><h3 class="fw-bold" id="hs-rej">0</h3><p class="mb-0 small">Rejected</p></div></div></div>
            </div>
            <div class="row mb-3 g-2">
                <div class="col-md-9"><input type="text" class="form-control" id="srch" placeholder="Search applicant, position, ID..."></div>
                <div class="col-md-3"><select class="form-select" id="stF"><option value="">All Status</option><option value="pending">Pending</option><option value="review">Under Review</option><option value="approved">Approved</option><option value="rejected">Rejected</option></select></div>
            </div>
            <div class="card">
                <div class="card-header bg-white"><h6 class="fw-bold mb-0">Applications (<span id="appCount">0</span>)</h6></div>
                <div class="card-body" id="appsList"><div class="text-center py-5"><div class="spinner-border text-primary"></div></div></div>
            </div>
        </div>

        <!-- APPLICATIONS -->
        <div class="dsec" id="sec-apps">
            <div class="mb-4"><h3 class="fw-bold">All Applications</h3></div>
            <div class="row mb-3 g-2">
                <div class="col-md-9"><input type="text" class="form-control" id="srch2" placeholder="Search..."></div>
                <div class="col-md-3"><select class="form-select" id="stF2"><option value="">All Status</option><option value="pending">Pending</option><option value="review">Under Review</option><option value="approved">Approved</option><option value="rejected">Rejected</option></select></div>
            </div>
            <div class="card">
                <div class="card-header bg-white"><h6 class="fw-bold mb-0">Applications (<span id="appCount2">0</span>)</h6></div>
                <div class="card-body" id="appsList2"></div>
            </div>
        </div>

        <!-- JOB POSTINGS -->
        <div class="dsec" id="sec-jobs">
            <div class="mb-4"><h3 class="fw-bold">Job Postings</h3></div>
            <div class="row g-4">
                <div class="col-md-5">
                    <div class="card"><div class="card-header bg-white"><h6 class="fw-bold mb-0"><i class="fas fa-plus-circle text-primary me-2"></i>Post New Job</h6></div>
                    <div class="card-body">
                        <input type="hidden" id="jobEditId">
                        <div class="mb-3"><label class="form-label small fw-medium">Job Title *</label><input type="text" class="form-control" id="jt" placeholder="e.g. Software Engineer"></div>
                        <div class="mb-3"><label class="form-label small fw-medium">Department *</label>
                            <select class="form-select" id="jd"><option value="">Select</option><option value="1">Information Technology</option><option value="2">Human Resources</option><option value="3">Finance</option><option value="4">Education</option><option value="5">Operations</option></select>
                        </div>
                        <div class="mb-3"><label class="form-label small fw-medium">Description</label><textarea class="form-control" id="jdesc" rows="2"></textarea></div>
                        <div class="mb-3"><label class="form-label small fw-medium">Requirements</label><textarea class="form-control" id="jreq" rows="2"></textarea></div>
                        <div class="mb-3"><label class="form-label small fw-medium">Slots</label><input type="number" class="form-control" id="jslots" value="1" min="1"></div>
                        <button type="button" class="btn btn-primary w-100" id="postJobBtn" onclick="saveJob()"><i class="fas fa-bullhorn me-2"></i>Post Job</button>
                    </div></div>
                </div>
                <div class="col-md-7">
                    <div class="card"><div class="card-header bg-white d-flex justify-content-between align-items-center">
                        <h6 class="fw-bold mb-0">Jobs (<span id="jobCount">0</span>)</h6>
                        <div class="d-flex gap-2">
                            <input type="text" class="form-control form-control-sm" id="jobSearch" placeholder="Search..." style="width:150px">
                            <select class="form-select form-select-sm" id="jobStF" style="width:120px"><option value="">All</option><option value="open">Open</option><option value="closed">Closed</option><option value="on_hold">On Hold</option></select>
                        </div>
                    </div>
                    <div class="card-body p-0"><div class="table-responsive">
                        <table class="table table-sm table-applications mb-0">
                            <thead><tr><th>Title</th><th>Department</th><th>Status</th><th>Posted</th><th>Actions</th></tr></thead>
                            <tbody id="jobsTable"><tr><td colspan="5" class="text-center py-4"><div class="spinner-border spinner-border-sm text-primary"></div></td></tr></tbody>
                        </table>
                    </div></div></div>
                </div>
            </div>
        </div>

        <!-- AUDIT -->
        <div class="dsec" id="sec-audit">
            <div class="mb-4"><h3 class="fw-bold">Audit Log</h3></div>
            <div class="card"><div class="card-body" id="auditList"><div class="text-center py-4"><div class="spinner-border text-primary"></div></div></div></div>
        </div>
    </div>
</div>

<!-- Review Modal -->
<div class="modal fade" id="reviewModal" tabindex="-1"><div class="modal-dialog modal-lg"><div class="modal-content">
    <div class="modal-header">
        <div><h5 class="modal-title fw-bold" id="rv-title">Review Application</h5><p class="text-muted small mb-0" id="rv-sub"></p></div>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
    </div>
    <div class="modal-body">
        <input type="hidden" id="rv-code">
        <div class="row g-3 mb-3">
            <div class="col-md-6"><div class="review-section">
                <h6 class="fw-semibold text-muted mb-2" style="font-size:.72rem;text-transform:uppercase">Applicant Info</h6>
                <div class="app-detail-row"><span class="text-muted small">Name</span><span class="fw-medium" id="rv-name">—</span></div>
                <div class="app-detail-row"><span class="text-muted small">Email</span><span id="rv-email">—</span></div>
                <div class="app-detail-row"><span class="text-muted small">Phone</span><span id="rv-phone">—</span></div>
            </div></div>
            <div class="col-md-6"><div class="review-section">
                <h6 class="fw-semibold text-muted mb-2" style="font-size:.72rem;text-transform:uppercase">Application Details</h6>
                <div class="app-detail-row"><span class="text-muted small">Position</span><span class="fw-medium" id="rv-pos">—</span></div>
                <div class="app-detail-row"><span class="text-muted small">Department</span><span id="rv-dept">—</span></div>
                <div class="app-detail-row"><span class="text-muted small">Submitted</span><span id="rv-sub-date">—</span></div>
                <div class="app-detail-row"><span class="text-muted small">Status</span><span id="rv-status">—</span></div>
            </div></div>
        </div>
        <div class="mb-3"><label class="form-label fw-medium">Resume</label><div id="rv-resume"></div></div>
        <div class="mb-3"><label class="form-label fw-medium">Update Status</label>
            <select class="form-select" id="rv-statusSel"><option value="pending">Pending</option><option value="review">Under Review</option><option value="approved">Approved</option><option value="rejected">Rejected</option></select>
        </div>
        <div class="mb-3"><label class="form-label fw-medium">Review Notes</label><textarea class="form-control" id="rv-notes" rows="4" placeholder="Add your comments..."></textarea></div>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-primary" id="saveReview"><i class="fas fa-save me-2"></i>Save Review</button>
    </div>
</div></div></div>

<div class="toast-container-custom"></div>
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo base_url('assets/js/utils.js'); ?>"></script>
<script>
const BASE='<?php echo base_url(); ?>';
const SL={pending:'Pending',review:'Under Review',approved:'Approved',rejected:'Rejected'};
const JSL={open:'<span class="status-badge status-approved">Open</span>',closed:'<span class="status-badge status-rejected">Closed</span>',on_hold:'<span class="status-badge status-review">On Hold</span>'};
let allApps=[], allJobs=[];

function loadStats(){$.get(BASE+'hr/api/stats',function(r){if(!r.success)return;const c=r.data;$('#hs-total').text(c.total);$('#hs-pend').text(c.pending);$('#hs-rev').text(c.review);$('#hs-app').text(c.approved);$('#hs-rej').text(c.rejected);});}
function loadApps(){$.get(BASE+'hr/api/applications',function(r){if(!r.success)return;allApps=r.data;renderApps();renderApps2();});}

function renderApps(){
    const s=$('#srch').val().toLowerCase(),st=$('#stF').val();
    let apps=[...allApps];
    if(s) apps=apps.filter(a=>a.applicant_name.toLowerCase().includes(s)||a.position.toLowerCase().includes(s)||a.app_code.toLowerCase().includes(s));
    if(st) apps=apps.filter(a=>a.status===st);
    const c=$('#appsList'),clrs=['bg-primary','bg-success','bg-warning','bg-info','bg-danger'];
    c.html('');$('#appCount').text(apps.length);
    if(!apps.length){c.html('<div class="text-center py-5 text-muted"><i class="fas fa-inbox fa-2x d-block mb-2"></i>No applications found.</div>');return;}
    apps.forEach(a=>{
        const ini=a.applicant_name.split(' ').map(n=>n[0]).join('').toUpperCase().slice(0,2);
        const cl=clrs[a.app_code.charCodeAt(a.app_code.length-1)%clrs.length];
        c.append(`<div class="card mb-3"><div class="card-body"><div class="d-flex gap-3">
            <div class="rounded-circle ${cl} text-white d-flex align-items-center justify-content-center flex-shrink-0 fw-bold" style="width:42px;height:42px;font-size:.8rem">${ini}</div>
            <div class="flex-grow-1"><div class="d-flex justify-content-between flex-wrap gap-2">
                <div><h6 class="fw-bold mb-0">${a.applicant_name}</h6>
                <p class="text-muted small mb-1">${a.position} • <span class="badge bg-light text-dark">${a.department}</span></p>
                <div class="small text-muted"><i class="fas fa-envelope me-1"></i>${a.email||'—'} &nbsp;<i class="fas fa-calendar me-1"></i>${a.submitted_fmt}</div>
                ${a.resume_url?`<a href="${a.resume_url}" target="_blank" class="btn btn-sm btn-outline-primary mt-1 py-0 px-2" style="font-size:.7rem"><i class="fas fa-file-pdf me-1"></i>View Resume</a>`:''}</div>
                <div class="d-flex flex-column align-items-end gap-1">
                    <span class="status-badge status-${a.status}">${SL[a.status]}</span>
                    <button class="btn btn-sm btn-primary review-btn" data-code="${a.app_code}"><i class="fas fa-search me-1"></i>Review</button>
                </div>
            </div></div>
        </div></div></div>`);
    });
}
function renderApps2(){
    const s=$('#srch2').val().toLowerCase(),st=$('#stF2').val();
    let apps=[...allApps];
    if(s) apps=apps.filter(a=>a.applicant_name.toLowerCase().includes(s)||a.position.toLowerCase().includes(s));
    if(st) apps=apps.filter(a=>a.status===st);
    const c=$('#appsList2'),clrs=['bg-primary','bg-success','bg-warning','bg-info','bg-danger'];
    c.html('');$('#appCount2').text(apps.length);
    if(!apps.length){c.html('<div class="text-center py-5 text-muted">No applications found.</div>');return;}
    apps.forEach(a=>{
        const ini=a.applicant_name.split(' ').map(n=>n[0]).join('').toUpperCase().slice(0,2);
        const cl=clrs[a.app_code.charCodeAt(a.app_code.length-1)%clrs.length];
        c.append(`<div class="card mb-3"><div class="card-body"><div class="d-flex gap-3">
            <div class="rounded-circle ${cl} text-white d-flex align-items-center justify-content-center flex-shrink-0 fw-bold" style="width:42px;height:42px;font-size:.8rem">${ini}</div>
            <div class="flex-grow-1"><div class="d-flex justify-content-between flex-wrap gap-2">
                <div><h6 class="fw-bold mb-0">${a.applicant_name}</h6><p class="text-muted small mb-1">${a.position}</p></div>
                <div class="d-flex flex-column align-items-end gap-1">
                    <span class="status-badge status-${a.status}">${SL[a.status]}</span>
                    <button class="btn btn-sm btn-primary review-btn" data-code="${a.app_code}"><i class="fas fa-search me-1"></i>Review</button>
                </div>
            </div></div>
        </div></div></div>`);
    });
}
$('#srch,#stF').on('input change',renderApps);
$('#srch2,#stF2').on('input change',renderApps2);

$(document).on('click','.review-btn',function(){
    const code=$(this).data('code'),a=allApps.find(x=>x.app_code===code);if(!a)return;
    $('#rv-code').val(a.app_code);$('#rv-title').text(a.position);$('#rv-sub').text(a.department+' • '+a.applicant_name);
    $('#rv-name').text(a.applicant_name);$('#rv-email').text(a.email||'—');$('#rv-phone').text(a.phone||'—');
    $('#rv-pos').text(a.position);$('#rv-dept').text(a.department);$('#rv-sub-date').text(a.submitted_fmt);
    $('#rv-status').html(`<span class="status-badge status-${a.status}">${SL[a.status]}</span>`);
    $('#rv-notes').val(a.review_notes||'');$('#rv-statusSel').val(a.status);
    $('#rv-resume').html(a.resume_url?`<a href="${a.resume_url}" target="_blank" class="btn btn-sm btn-outline-primary"><i class="fas fa-file-pdf me-1"></i>View Resume</a>`:'<span class="text-muted small">No resume uploaded.</span>');
    new bootstrap.Modal($('#reviewModal')[0]).show();
});
$('#saveReview').on('click',function(){
    $(this).prop('disabled',true).html('<span class="spinner-border spinner-border-sm me-2"></span>Saving...');
    $.post(BASE+'hr/api/review',{app_code:$('#rv-code').val(),status:$('#rv-statusSel').val(),review_notes:$('#rv-notes').val()},function(r){
        if(r.success){showToast(r.message,'success');bootstrap.Modal.getInstance($('#reviewModal')[0]).hide();loadStats();loadApps();}
        else showToast(r.message,'error');
        $('#saveReview').prop('disabled',false).html('<i class="fas fa-save me-2"></i>Save Review');
    });
});

function loadJobs(){$.get(BASE+'hr/api/jobs',function(r){if(!r.success)return;allJobs=r.data;renderJobs();});}
function renderJobs(){
    const s=$('#jobSearch').val().toLowerCase(),st=$('#jobStF').val();
    let jobs=[...allJobs];
    if(s) jobs=jobs.filter(j=>j.title.toLowerCase().includes(s));
    if(st) jobs=jobs.filter(j=>j.status===st);
    const tb=$('#jobsTable');tb.html('');$('#jobCount').text(jobs.length);
    if(!jobs.length){tb.html('<tr><td colspan="5" class="text-center py-4 text-muted">No jobs found.</td></tr>');return;}
    jobs.forEach(j=>tb.append(`<tr><td class="fw-medium">${j.title}</td><td><span class="badge bg-light text-dark">${j.department_name}</span></td><td>${JSL[j.status]||j.status}</td><td class="small text-muted">${j.created_fmt}</td><td><button class="btn btn-sm btn-outline-secondary edit-job-btn me-1" data-id="${j.id}"><i class="fas fa-edit"></i></button><button class="btn btn-sm btn-outline-danger del-job-btn" data-id="${j.id}"><i class="fas fa-trash"></i></button></td></tr>`));
}
$('#jobSearch,#jobStF').on('input change',renderJobs);
function saveJob(){
    const id=$('#jobEditId').val(),title=$('#jt').val().trim(),dept=$('#jd').val(),desc=$('#jdesc').val(),req=$('#jreq').val();
    if(!title||!dept){showToast('Title and department required.','warning');return;}
    $.post(BASE+'hr/api/job/save',{id,title,department_id:dept,description:desc,requirements:req},function(r){
        if(r.success){showToast(r.message,'success');$('#jobEditId').val('');$('#jt,#jdesc,#jreq').val('');$('#jd').val('');$('#postJobBtn').html('<i class="fas fa-bullhorn me-2"></i>Post Job');loadJobs();}
        else showToast(r.message,'error');
    });
}
$(document).on('click','.edit-job-btn',function(){
    const j=allJobs.find(x=>x.id==parseInt($(this).data('id')));if(!j)return;
    $('#jobEditId').val(j.id);$('#jt').val(j.title);$('#jd').val(j.department_id);$('#jdesc').val(j.description);$('#jreq').val(j.requirements);
    $('#postJobBtn').html('<i class="fas fa-save me-2"></i>Update Job');
    showSec('sec-jobs',$('#nav-jobs')[0]);
});
$(document).on('click','.del-job-btn',function(){
    if(!confirm('Delete this job?'))return;
    $.post(BASE+'hr/api/job/delete',{id:$(this).data('id')},function(r){r.success?showToast(r.message,'warning')&&loadJobs():showToast(r.message,'error');loadJobs();});
});

function loadAudit(){
    $.get(BASE+'hr/api/audit',function(r){
        if(!r.success)return;
        const ac={login:'success',logout:'secondary',application_create:'primary',status_update:'warning',job_post:'success',job_update:'info',job_delete:'danger'};
        const c=$('#auditList');c.html('');
        r.data.forEach(l=>{const col=ac[l.action]||'secondary';c.append(`<div class="audit-item"><div class="audit-dot" style="background:var(--bs-${col})"></div><div class="flex-grow-1"><div class="small fw-medium">${l.description}</div><div class="text-muted" style="font-size:.72rem">${l.user_name||''} • ${l.ts_fmt}</div></div><span class="badge bg-${col}" style="font-size:.65rem;white-space:nowrap;align-self:start">${l.action.replace(/_/g,' ')}</span></div>`);});
    });
}

function showSec(id,el){$('.dsec').removeClass('active');$('#'+id).addClass('active');$('.sidebar-item').removeClass('active');$(el).addClass('active');}
$('#nav-dash').on('click',function(){showSec('sec-dash',this);loadStats();loadApps();});
$('#nav-apps').on('click',function(){showSec('sec-apps',this);});
$('#nav-jobs').on('click',function(){showSec('sec-jobs',this);loadJobs();});
$('#nav-audit').on('click',function(){showSec('sec-audit',this);loadAudit();});
$('#logoutBtn').on('click',()=>window.location.href=BASE+'signout');
$('#mobileToggle').on('click',()=>{$('.sidebar').toggleClass('open');$('.sb-overlay').toggleClass('show');});
$('.sb-overlay').on('click',()=>{$('.sidebar').removeClass('open');$('.sb-overlay').removeClass('show');});
$(()=>{loadStats();loadApps();});
</script>
</body>
</html>
