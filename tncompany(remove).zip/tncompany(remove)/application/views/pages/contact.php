<?php $title = 'Contact Us - T&N Company'; ?>
<?php $this->load->view('layouts/public_header'); ?>
<div class="static-hero text-center"><div class="container"><h1 class="fw-bold display-5">Contact Us</h1><p class="text-white-50 mt-2">We're here to help.</p></div></div>
<div class="container pb-5">
    <div class="row g-4 justify-content-center">
        <div class="col-md-5">
            <div class="card p-4">
                <h5 class="fw-bold mb-4">Send us a Message</h5>
                <div class="mb-3"><label class="form-label small fw-medium">Full Name *</label><input type="text" class="form-control" id="cName" placeholder="Your full name"></div>
                <div class="mb-3"><label class="form-label small fw-medium">Email *</label><input type="email" class="form-control" id="cEmail" placeholder="you@email.com"></div>
                <div class="mb-3"><label class="form-label small fw-medium">Subject *</label><input type="text" class="form-control" id="cSubject" placeholder="What is this about?"></div>
                <div class="mb-3"><label class="form-label small fw-medium">Message *</label><textarea class="form-control" id="cMsg" rows="5"></textarea></div>
                <button class="btn btn-primary w-100" onclick="sendMsg()"><i class="fas fa-paper-plane me-2"></i>Send Message</button>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card p-4 mb-3"><h6 class="fw-bold mb-3"><i class="fas fa-envelope text-primary me-2"></i>Email</h6><p class="text-muted small mb-0">support@tncompany.com</p></div>
            <div class="card p-4 mb-3"><h6 class="fw-bold mb-3"><i class="fas fa-phone text-primary me-2"></i>Phone</h6><p class="text-muted small mb-0">+63 912 345 6789<br>Mon–Fri, 8AM–5PM</p></div>
            <div class="card p-4"><h6 class="fw-bold mb-3"><i class="fas fa-map-marker-alt text-primary me-2"></i>Address</h6><p class="text-muted small mb-0">Manila, Philippines</p></div>
        </div>
    </div>
</div>
<?php $this->load->view('layouts/public_footer'); ?>
<script>
function sendMsg(){
    const n=$('#cName').val().trim(),e=$('#cEmail').val().trim(),s=$('#cSubject').val().trim(),m=$('#cMsg').val().trim();
    if(!n||!e||!s||!m){showToast('Please fill in all fields.','warning');return;}
    showToast('Message sent! We will respond within 1-2 business days.','success');
    $('#cName,#cEmail,#cSubject,#cMsg').val('');
}
</script>
