<?php $title = 'Help Center - T&N Company'; ?>
<?php $this->load->view('layouts/public_header'); ?>
<div class="static-hero text-center"><div class="container"><h1 class="fw-bold display-5">Help Center</h1><p class="text-white-50 mt-2">Everything you need to get started.</p></div></div>
<div class="container pb-5">
    <div class="row g-4 mb-5">
        <div class="col-md-4"><a href="#applicant-guide" class="text-decoration-none"><div class="card p-4 text-center h-100 job-card"><i class="fas fa-user fa-2x text-primary mb-3"></i><h5 class="fw-bold">Applicant Guide</h5><p class="text-muted small">How to register, apply for jobs, and track your application.</p></div></a></div>
        <div class="col-md-4"><a href="#hr-guide" class="text-decoration-none"><div class="card p-4 text-center h-100 job-card"><i class="fas fa-users fa-2x text-success mb-3"></i><h5 class="fw-bold">HR Staff Guide</h5><p class="text-muted small">How to review applications, post jobs, and manage the system.</p></div></a></div>
        <div class="col-md-4"><a href="<?php echo base_url('faq'); ?>" class="text-decoration-none"><div class="card p-4 text-center h-100 job-card"><i class="fas fa-question-circle fa-2x text-warning mb-3"></i><h5 class="fw-bold">FAQ</h5><p class="text-muted small">Answers to the most commonly asked questions.</p></div></a></div>
    </div>
    <div id="applicant-guide" class="mb-5">
        <h3 class="fw-bold mb-4"><i class="fas fa-user text-primary me-2"></i>Applicant Guide</h3>
        <div class="row g-3">
            <div class="col-md-6"><div class="card p-3"><h6 class="fw-bold"><span class="badge bg-primary me-2">1</span>Create Account</h6><p class="text-muted small mb-0">Click "Apply Now" and complete the 3-step registration form.</p></div></div>
            <div class="col-md-6"><div class="card p-3"><h6 class="fw-bold"><span class="badge bg-primary me-2">2</span>Browse Jobs</h6><p class="text-muted small mb-0">Go to "Browse Jobs" in the sidebar to see all open positions.</p></div></div>
            <div class="col-md-6"><div class="card p-3"><h6 class="fw-bold"><span class="badge bg-primary me-2">3</span>Submit Application</h6><p class="text-muted small mb-0">Select a position, upload your PDF resume, and submit.</p></div></div>
            <div class="col-md-6"><div class="card p-3"><h6 class="fw-bold"><span class="badge bg-primary me-2">4</span>Track Status</h6><p class="text-muted small mb-0">View your applications and click "View" to see status and reviewer notes.</p></div></div>
        </div>
    </div>
    <div id="hr-guide" class="mb-5">
        <h3 class="fw-bold mb-4"><i class="fas fa-users text-success me-2"></i>HR Staff Guide</h3>
        <div class="row g-3">
            <div class="col-md-6"><div class="card p-3"><h6 class="fw-bold"><span class="badge bg-success me-2">1</span>Sign In as HR</h6><p class="text-muted small mb-0">Select "HR Staff" tab on the Sign In page and use your credentials.</p></div></div>
            <div class="col-md-6"><div class="card p-3"><h6 class="fw-bold"><span class="badge bg-success me-2">2</span>Review Applications</h6><p class="text-muted small mb-0">Click "Review" on any application to update status with notes.</p></div></div>
            <div class="col-md-6"><div class="card p-3"><h6 class="fw-bold"><span class="badge bg-success me-2">3</span>Post Job Openings</h6><p class="text-muted small mb-0">Go to "Job Postings" and fill in the job details form.</p></div></div>
            <div class="col-md-6"><div class="card p-3"><h6 class="fw-bold"><span class="badge bg-success me-2">4</span>View Resumes</h6><p class="text-muted small mb-0">Click "View Applicant Resume" in the Review modal to open the PDF.</p></div></div>
        </div>
    </div>
    <div class="alert alert-primary"><i class="fas fa-headset me-2"></i>Need more help? <a href="<?php echo base_url('contact'); ?>" class="alert-link">Contact our support team</a>.</div>
</div>
<?php $this->load->view('layouts/public_footer'); ?>
