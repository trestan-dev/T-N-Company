<?php $title = 'Privacy Policy - T&N Company'; ?>
<?php $this->load->view('layouts/public_header'); ?>
<div class="static-hero text-center"><div class="container"><h1 class="fw-bold display-5">Privacy Policy</h1><p class="text-white-50 mt-2">Last updated: January 1, 2026</p></div></div>
<div class="container pb-5">
    <div class="alert alert-primary mb-4"><i class="fas fa-shield-alt me-2"></i>T&N Company is committed to protecting your privacy in accordance with the Data Privacy Act of 2012 (RA 10173).</div>
    <h4 class="fw-bold mt-4 mb-3">1. Information We Collect</h4>
    <p class="text-muted">We collect personal information you provide during registration: full name, email, phone, date of birth, gender, address, and uploaded resume documents.</p>
    <h4 class="fw-bold mt-4 mb-3">2. How We Use Your Information</h4>
    <p class="text-muted">Your information is used to process job applications, communicate status updates, verify qualifications, and maintain audit trails.</p>
    <h4 class="fw-bold mt-4 mb-3">3. Data Sharing</h4>
    <p class="text-muted">We do not sell or transfer your personal information to third parties. Data is only accessible to authorized HR staff and administrators.</p>
    <h4 class="fw-bold mt-4 mb-3">4. Data Security</h4>
    <p class="text-muted">We implement role-based access control, session management, and audit logging to protect your information.</p>
    <h4 class="fw-bold mt-4 mb-3">5. Data Retention</h4>
    <p class="text-muted">Application data is retained for a maximum of 2 years. You may request deletion by contacting support@tncompany.com.</p>
    <h4 class="fw-bold mt-4 mb-3">6. Your Rights</h4>
    <p class="text-muted">Under the Data Privacy Act, you have the right to access, correct, or request deletion of your personal data.</p>
    <h4 class="fw-bold mt-4 mb-3">7. Contact</h4>
    <p class="text-muted">For privacy concerns: <a href="mailto:privacy@tncompany.com">privacy@tncompany.com</a></p>
</div>
<?php $this->load->view('layouts/public_footer'); ?>
