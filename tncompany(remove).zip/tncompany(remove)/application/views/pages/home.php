<?php $title = 'T&N Company - Online Registration System'; ?>
<?php $this->load->view('layouts/public_header'); ?>

<section class="hero-section d-flex align-items-center min-vh-100 pt-5">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <h1 class="display-4 fw-bold mb-4">
                    Transform Paper-Based Registration into a <span class="text-primary">Digital Experience</span>
                </h1>
                <p class="lead text-muted mb-5">
                    Streamline your company's registration workflow with automated forms, real-time tracking, and intelligent document management. No more lost paperwork, no more manual errors.
                </p>
                <div class="d-flex gap-3">
                    <a href="<?php echo base_url('signup'); ?>" class="btn btn-primary btn-lg px-5">
                        Start Application <i class="fas fa-arrow-right ms-2"></i>
                    </a>
                    <a href="#features" class="btn btn-outline-secondary btn-lg px-5">Learn More</a>
                </div>
            </div>
            <div class="col-lg-6 d-none d-lg-block">
                <div class="hero-visual bg-light rounded-4 p-5 shadow-sm">
                    <div class="text-center">
                        <i class="fas fa-file-alt text-primary" style="font-size:6rem;"></i>
                        <div class="mt-4">
                            <div class="d-flex justify-content-around">
                                <div class="text-center"><h3 class="fw-bold text-primary">32+</h3><p class="text-muted">Total Applications</p></div>
                                <div class="text-center"><h3 class="fw-bold text-success">14+</h3><p class="text-muted">Approved</p></div>
                                <div class="text-center"><h3 class="fw-bold text-warning">8+</h3><p class="text-muted">Pending Review</p></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section id="features" class="py-5 bg-light">
    <div class="container py-5">
        <div class="text-center mb-5">
            <h2 class="fw-bold">System Features</h2>
            <p class="text-muted">Everything you need for modern registration management</p>
        </div>
        <div class="row g-4">
            <div class="col-md-4">
                <div class="card h-100 border-0 shadow-sm"><div class="card-body p-4">
                    <div class="icon-box bg-primary bg-opacity-10 mb-3"><i class="fas fa-user-edit text-primary"></i></div>
                    <h5 class="fw-bold">Digital Application Forms</h5>
                    <p class="text-muted">Complete online application forms with smart validation, file uploads, and progress saving.</p>
                </div></div>
            </div>
            <div class="col-md-4">
                <div class="card h-100 border-0 shadow-sm"><div class="card-body p-4">
                    <div class="icon-box bg-success bg-opacity-10 mb-3"><i class="fas fa-check-double text-success"></i></div>
                    <h5 class="fw-bold">Real-Time Status Tracking</h5>
                    <p class="text-muted">Applicants can check their application status at any time with instant updates.</p>
                </div></div>
            </div>
            <div class="col-md-4">
                <div class="card h-100 border-0 shadow-sm"><div class="card-body p-4">
                    <div class="icon-box bg-warning bg-opacity-10 mb-3"><i class="fas fa-shield-alt text-warning"></i></div>
                    <h5 class="fw-bold">Secure Document Storage</h5>
                    <p class="text-muted">All uploaded documents are securely stored and only accessible by authorized HR staff.</p>
                </div></div>
            </div>
            <div class="col-md-4">
                <div class="card h-100 border-0 shadow-sm"><div class="card-body p-4">
                    <div class="icon-box bg-info bg-opacity-10 mb-3"><i class="fas fa-users text-info"></i></div>
                    <h5 class="fw-bold">HR Management Dashboard</h5>
                    <p class="text-muted">Streamlined interface for HR staff to review, verify, approve or reject applications efficiently.</p>
                </div></div>
            </div>
            <div class="col-md-4">
                <div class="card h-100 border-0 shadow-sm"><div class="card-body p-4">
                    <div class="icon-box bg-danger bg-opacity-10 mb-3"><i class="fas fa-chart-bar text-danger"></i></div>
                    <h5 class="fw-bold">Analytics & Reporting</h5>
                    <p class="text-muted">Comprehensive statistics, charts and audit logs for system monitoring and decision making.</p>
                </div></div>
            </div>
            <div class="col-md-4">
                <div class="card h-100 border-0 shadow-sm"><div class="card-body p-4">
                    <div class="icon-box bg-secondary bg-opacity-10 mb-3"><i class="fas fa-user-shield text-secondary"></i></div>
                    <h5 class="fw-bold">Role-Based Access</h5>
                    <p class="text-muted">Three distinct user roles: Applicant, HR Staff, and Administrator with appropriate permissions.</p>
                </div></div>
            </div>
        </div>
    </div>
</section>

<?php $this->load->view('layouts/public_footer'); ?>
<script>
$('a[href^="#"]').on('click',function(e){
    const t=$($(this).attr('href'));
    if(t.length){e.preventDefault();$('html,body').animate({scrollTop:t.offset().top-70},500);}
});
</script>
