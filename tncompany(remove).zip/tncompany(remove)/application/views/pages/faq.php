<?php $title = 'FAQ - T&N Company'; ?>
<?php $this->load->view('layouts/public_header'); ?>
<div class="static-hero text-center"><div class="container"><h1 class="fw-bold">Frequently Asked Questions</h1><p class="text-white-75 mt-2">Find answers to common questions.</p></div></div>
<div class="container pb-5">
    <h5 class="fw-bold text-primary mb-4">Application Process</h5>
    <div class="faq-item open">
        <div class="faq-question" onclick="toggleFaq(this)">How do I create an account?<span class="faq-icon">+</span></div>
        <div class="faq-answer">Click "Apply Now" on the homepage. Complete the 3-step registration: personal information, account credentials, then confirm and submit.</div>
    </div>
    <div class="faq-item">
        <div class="faq-question" onclick="toggleFaq(this)">How do I submit a job application?<span class="faq-icon">+</span></div>
        <div class="faq-answer">After signing in as an Applicant, click "New Application". Select the position, upload your resume (PDF), add notes, and click Submit.</div>
    </div>
    <div class="faq-item">
        <div class="faq-question" onclick="toggleFaq(this)">How can I check my application status?<span class="faq-icon">+</span></div>
        <div class="faq-answer">Log in and view the Applications table on your dashboard. Each application shows: Pending, Under Review, Approved, or Rejected.</div>
    </div>
    <div class="faq-item">
        <div class="faq-question" onclick="toggleFaq(this)">Can I submit multiple applications?<span class="faq-icon">+</span></div>
        <div class="faq-answer">Yes, you can apply for multiple positions. Each is tracked separately with its own application ID.</div>
    </div>
    <h5 class="fw-bold text-primary mt-5 mb-4">Account & Security</h5>
    <div class="faq-item">
        <div class="faq-question" onclick="toggleFaq(this)">Is my personal information secure?<span class="faq-icon">+</span></div>
        <div class="faq-answer">Yes. All data is stored securely with role-based access control in compliance with the Data Privacy Act.</div>
    </div>
    <div class="faq-item">
        <div class="faq-question" onclick="toggleFaq(this)">What are the different user roles?<span class="faq-icon">+</span></div>
        <div class="faq-answer">Three roles: Applicant (submit and track), HR Staff (review applications), and Administrator (full system access).</div>
    </div>
    <h5 class="fw-bold text-primary mt-5 mb-4">Technical</h5>
    <div class="faq-item">
        <div class="faq-question" onclick="toggleFaq(this)">What file types are accepted for resume upload?<span class="faq-icon">+</span></div>
        <div class="faq-answer">Only PDF files, under 5MB.</div>
    </div>
    <div class="alert alert-primary mt-5"><i class="fas fa-headset me-2"></i>Still have questions? <a href="<?php echo base_url('contact'); ?>" class="alert-link">Contact our support team</a>.</div>
</div>
<?php $this->load->view('layouts/public_footer'); ?>
<script>function toggleFaq(el){el.closest('.faq-item').classList.toggle('open');}</script>
