<?php $title = 'About Us - T&N Company'; ?>
<?php $this->load->view('layouts/public_header'); ?>
<div class="static-hero text-center">
    <div class="container"><h1 class="fw-bold display-5">About T&N Company</h1><p class="text-white-50 mt-2 lead">Empowering careers through digital innovation</p></div>
</div>
<div class="container pb-5">
    <div class="row g-4 mb-5">
        <div class="col-md-6">
            <h2 class="fw-bold mb-3">Our Mission</h2>
            <p class="text-muted">T&N Company is dedicated to transforming the traditional paper-based hiring process into a seamless digital experience. We believe that connecting the right talent with the right opportunities should be effortless, transparent, and efficient.</p>
            <p class="text-muted">Founded with a vision to modernize Philippine company recruitment, our Online Registration System eliminates bottlenecks, reduces manual errors, and provides real-time visibility for both applicants and HR professionals.</p>
        </div>
        <div class="col-md-6">
            <div class="bg-primary bg-opacity-10 rounded-3 p-4">
                <h5 class="fw-bold text-primary mb-3"><i class="fas fa-bullseye me-2"></i>What We Offer</h5>
                <ul class="list-unstyled text-muted">
                    <li class="mb-2"><i class="fas fa-check text-success me-2"></i>Digital job application submission</li>
                    <li class="mb-2"><i class="fas fa-check text-success me-2"></i>Real-time application status tracking</li>
                    <li class="mb-2"><i class="fas fa-check text-success me-2"></i>Secure document management</li>
                    <li class="mb-2"><i class="fas fa-check text-success me-2"></i>Role-based access control</li>
                    <li class="mb-2"><i class="fas fa-check text-success me-2"></i>Comprehensive audit logging</li>
                    <li class="mb-2"><i class="fas fa-check text-success me-2"></i>Analytics and reporting dashboard</li>
                </ul>
            </div>
        </div>
    </div>
    <h2 class="fw-bold text-center mb-4">Meet the Development Team</h2>
    <div class="row g-4 justify-content-center">
        <div class="col-md-4"><div class="team-card"><div class="team-avatar mx-auto" style="background:linear-gradient(135deg,#0d6efd,#7c3aed)">F</div><h5 class="fw-bold">Famini</h5><p class="text-muted small">Lead Developer</p><p class="text-muted small">Full-stack development, system architecture, and database design.</p><span class="badge bg-primary">BSIT 2C</span></div></div>
        <div class="col-md-4"><div class="team-card"><div class="team-avatar mx-auto" style="background:linear-gradient(135deg,#16a34a,#0d6efd)">P</div><h5 class="fw-bold">Pacalioga</h5><p class="text-muted small">Co-Developer</p><p class="text-muted small">UI/UX design, frontend development, and system testing.</p><span class="badge bg-success">BSIT 2C</span></div></div>
    </div>
    <div class="row g-4 mt-4 text-center">
        <div class="col-md-3"><div class="card p-3"><h3 class="fw-bold text-primary">32+</h3><p class="text-muted small">Applications Processed</p></div></div>
        <div class="col-md-3"><div class="card p-3"><h3 class="fw-bold text-success">14+</h3><p class="text-muted small">Successful Hires</p></div></div>
        <div class="col-md-3"><div class="card p-3"><h3 class="fw-bold text-warning">6+</h3><p class="text-muted small">Job Categories</p></div></div>
        <div class="col-md-3"><div class="card p-3"><h3 class="fw-bold text-info">3</h3><p class="text-muted small">User Roles</p></div></div>
    </div>
</div>
<?php $this->load->view('layouts/public_footer'); ?>
