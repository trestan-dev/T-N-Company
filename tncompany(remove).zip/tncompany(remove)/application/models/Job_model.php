<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Job_model extends CI_Model {

    public function get_all_with_dept() {
        return $this->db->select('j.*, d.name as department_name')
            ->from('job_positions j')
            ->join('departments d', 'd.id = j.department_id', 'left')
            ->order_by('j.created_at', 'DESC')
            ->get()->result_array();
    }

    public function get_open_with_dept() {
        return $this->db->select('j.*, d.name as department_name')
            ->from('job_positions j')
            ->join('departments d', 'd.id = j.department_id', 'left')
            ->where('j.status', 'open')
            ->order_by('j.created_at', 'DESC')
            ->get()->result_array();
    }

    public function get_open_count() {
        return $this->db->where('status', 'open')->count_all_results('job_positions');
    }

    public function find_by_id($id) {
        return $this->db->select('j.*, d.name as department_name')
            ->from('job_positions j')
            ->join('departments d', 'd.id = j.department_id', 'left')
            ->where('j.id', $id)
            ->get()->row_array();
    }

    public function create($data) {
        $this->db->insert('job_positions', $data);
        return $this->db->insert_id();
    }

    public function update_job($id, $data) {
        $this->db->where('id', $id)->update('job_positions', $data);
    }

    public function delete_job($id) {
        $this->db->where('id', $id)->delete('job_positions');
    }
}
