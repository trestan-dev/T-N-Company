<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Audit_model extends CI_Model {

    public function add_log($user_id, $action, $description) {
        $this->db->insert('audit_logs', [
            'user_id'     => $user_id,
            'action'      => $action,
            'description' => $description,
            'ip_address'  => $this->input->ip_address(),
        ]);
    }

    public function get_logs_with_user($limit = 200, $search = '', $action = '') {
        $this->db->select('l.*, CONCAT(u.first_name," ",u.last_name) as user_name, u.role')
            ->from('audit_logs l')
            ->join('users u', 'u.id = l.user_id', 'left')
            ->order_by('l.created_at', 'DESC')
            ->limit($limit);
        if ($search) $this->db->like('l.description', $search);
        if ($action) $this->db->where('l.action', $action);
        return $this->db->get()->result_array();
    }
}
