<?php
defined('BASEPATH') OR exit('No direct script access allowed');

#[AllowDynamicProperties]
class Applicant extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model(['Application_model','Job_model','User_model','Audit_model']);
    }

    public function index() {
        $user = require_auth('applicant');
        $this->Audit_model->add_log($user['id'], 'page_view', 'Applicant viewed dashboard.');
        $this->load->view('applicant/dashboard', ['user' => $user]);
    }

    public function api_stats() {
        $user   = require_auth('applicant');
        $counts = $this->Application_model->get_status_counts_for_applicant($user['id']);
        json_success($counts);
    }

    public function api_applications() {
        $user = require_auth('applicant');
        $apps = $this->Application_model->get_for_applicant($user['id']);
        foreach ($apps as &$a) {
            $a['submitted_fmt']   = fmt_date($a['created_at']);
            $a['reviewed_at_fmt'] = fmt_date($a['reviewed_at']);
            $a['resume_url']      = $a['resume_path']
                ? base_url('assets/uploads/resumes/'.$a['resume_path']) : null;
        }
        json_success($apps);
    }

    public function api_jobs() {
        $user   = require_auth('applicant');
        $jobs   = $this->Job_model->get_open_with_dept();
        $my_apps = $this->Application_model->get_for_applicant($user['id']);
        $applied = array_column($my_apps, 'position');
        foreach ($jobs as &$j) {
            $j['already_applied'] = in_array($j['title'], $applied);
            $j['created_fmt']     = fmt_date($j['created_at']);
        }
        json_success($jobs);
    }

    public function api_apply() {
        $user   = require_auth('applicant');
        $job_id = (int)$this->input->post('job_id');
        $notes  = $this->input->post('notes');

        if (!$job_id) json_error('Please select a job position.');

        $job = $this->Job_model->find_by_id($job_id);
        if (!$job || $job['status'] !== 'open') json_error('Position no longer available.');

        if ($this->Application_model->has_applied($user['id'], $job['title'])) {
            json_error('You have already applied for this position.');
        }

        // Handle resume upload
        $resume_path = null;
        if (!empty($_FILES['resume']['name'])) {
            $config = [
                'upload_path'   => FCPATH . '../assets/uploads/resumes/',
                'allowed_types' => 'pdf',
                'max_size'      => 5120,
                'encrypt_name'  => TRUE,
            ];
            $this->load->library('upload', $config);
            if ($this->upload->do_upload('resume')) {
                $resume_path = $this->upload->data('file_name');
            } else {
                json_error($this->upload->display_errors('', ''));
            }
        }

        $count    = $this->Application_model->count_all();
        $app_code = gen_app_code($count);

        $this->Application_model->create([
            'app_code'     => $app_code,
            'applicant_id' => $user['id'],
            'position'     => $job['title'],
            'department'   => $job['department_name'],
            'resume_path'  => $resume_path,
            'notes'        => $notes,
            'status'       => 'pending',
        ]);

        $this->Audit_model->add_log($user['id'], 'application_create',
            'Application '.$app_code.' submitted for '.$job['title'].'.');

        json_success(['app_code' => $app_code], 'Application '.$app_code.' submitted!');
    }

    public function api_profile() {
        $user  = require_auth('applicant');
        $phone = $this->input->post('phone');
        $addr  = $this->input->post('address');
        $this->User_model->update_user($user['id'], ['phone'=>$phone,'address'=>$addr]);
        $this->Audit_model->add_log($user['id'], 'profile_update', 'Profile updated.');
        json_success([], 'Profile saved!');
    }
}
