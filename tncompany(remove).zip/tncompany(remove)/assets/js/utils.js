// T&N Shared Utils
function showToast(msg, type, ms) {
    type = type || 'info';
    ms   = ms   || 3000;
    var c = document.querySelector('.toast-container-custom');
    if (!c) { c = document.createElement('div'); c.className = 'toast-container-custom'; document.body.appendChild(c); }
    var t = document.createElement('div');
    var ico = { success:'fa-check-circle text-success', error:'fa-times-circle text-danger', warning:'fa-exclamation-circle text-warning', info:'fa-info-circle text-primary' };
    t.className = 'toast-custom ' + type;
    t.innerHTML = '<div class="d-flex align-items-center gap-2"><i class="fas ' + (ico[type] || ico.info) + '"></i><span>' + msg + '</span><button onclick="this.closest(\'.toast-custom\').remove()" class="btn-close btn-close-sm ms-auto" style="font-size:0.6rem"></button></div>';
    c.appendChild(t);
    setTimeout(function() { t.style.animation = 'slideOut 0.3s forwards'; setTimeout(function() { if(t.parentNode) t.parentNode.removeChild(t); }, 300); }, ms);
}
function fmtDate(d) {
    if (!d || d === '—') return '—';
    try { return new Date(d).toLocaleDateString('en-PH', {year:'numeric',month:'short',day:'numeric'}); } catch(e) { return d; }
}
