<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - T&N Company</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/style.css'); ?>">
</head>
<body>
<button class="mobile-toggle" id="mobileToggle"><i class="fas fa-bars"></i></button>
<div class="sb-overlay sidebar-overlay"></div>
<div class="sidebar">
    <div class="sidebar-logo">
        <h5 class="fw-bold mb-0"><span class="text-primary">T</span>&<span class="text-danger">N</span> Company</h5>
        <p class="text-muted small mb-0">Administrator Portal</p>
    </div>
    <div class="sidebar-menu">
        <a class="sidebar-item active" id="nav-dash"><i class="fas fa-home"></i> Dashboard</a>
        <a class="sidebar-item" id="nav-apps"><i class="fas fa-file-alt"></i> Applications</a>
        <a class="sidebar-item" id="nav-jobs"><i class="fas fa-briefcase"></i> Job Postings</a>
        <a class="sidebar-item" id="nav-hr"><i class="fas fa-users"></i> HR Accounts</a>
        <a class="sidebar-item" id="nav-users"><i class="fas fa-user-circle"></i> All Users</a>
        <a class="sidebar-item" id="nav-audit"><i class="fas fa-history"></i> Audit Log</a>
        <hr class="my-3">
        <a class="sidebar-item text-danger" id="logoutBtn"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>
</div>
<div class="main-content bg-light">
    <div class="container-fluid px-4">

        <!-- DASHBOARD -->
        <div class="dsec active" id="sec-dash">
            <div class="mb-4"><h3 class="fw-bold">Admin Dashboard</h3><p class="text-muted mb-0">System overview and analytics</p></div>
            <div class="row g-3 mb-4">
                <div class="col-6 col-md-3"><div class="card stat-card"><div class="card-body text-center"><h3 class="fw-bold" id="as-total">0</h3><p class="text-muted mb-0 small">Total Applications</p></div></div></div>
                <div class="col-6 col-md-3"><div class="card stat-card"><div class="card-body text-center"><h3 class="fw-bold" id="as-users">0</h3><p class="text-muted mb-0 small">Registered Users</p></div></div></div>
                <div class="col-6 col-md-3"><div class="card stat-card"><div class="card-body text-center"><h3 class="fw-bold text-success" id="as-approved">0</h3><p class="text-muted mb-0 small">Approved</p></div></div></div>
                <div class="col-6 col-md-3"><div class="card stat-card"><div class="card-body text-center"><h3 class="fw-bold text-info" id="as-jobs">0</h3><p class="text-muted mb-0 small">Open Jobs</p></div></div></div>
            </div>
            <div class="row g-4">
                <div class="col-md-5"><div class="card h-100"><div class="card-header bg-white"><h6 class="fw-bold mb-0">Status Breakdown</h6></div>
                    <div class="card-body text-center">
                        <div class="d-flex justify-content-center mb-3">
    <svg id="donutChart" viewBox="0 0 160 160" width="160" height="160">
        <circle cx="80" cy="80" r="60" fill="none" stroke="#e2e8f0" stroke-width="28"/>
        <g id="donutSegments"></g>
        <text x="80" y="85" text-anchor="middle" font-size="22" font-weight="700" fill="#1e293b" id="pieTotal">0</text>
    </svg>
</div>
                        <div class="row text-start mt-3">
                            <div class="col-6"><div class="d-flex gap-2 align-items-center mb-2"><span class="badge bg-success">&nbsp;</span><span class="small">Approved: <strong id="pie-app">0</strong></span></div><div class="d-flex gap-2 align-items-center mb-2"><span class="badge bg-warning">&nbsp;</span><span class="small">Pending: <strong id="pie-pend">0</strong></span></div></div>
                            <div class="col-6"><div class="d-flex gap-2 align-items-center mb-2"><span class="badge bg-primary">&nbsp;</span><span class="small">Review: <strong id="pie-rev">0</strong></span></div><div class="d-flex gap-2 align-items-center mb-2"><span class="badge bg-danger">&nbsp;</span><span class="small">Rejected: <strong id="pie-rej">0</strong></span></div></div>
                        </div>
                    </div>
                </div></div>
                <div class="col-md-7"><div class="card h-100"><div class="card-header bg-white"><h6 class="fw-bold mb-0">Recent Applications</h6></div><div class="card-body" id="recentApps"><div class="text-center py-3 text-muted">Loading...</div></div></div></div>
            </div>
        </div>

        <!-- APPLICATIONS -->
        <div class="dsec" id="sec-apps">
            <div class="mb-4"><h3 class="fw-bold">All Applications</h3></div>
            <div class="row mb-3 g-2">
                <div class="col-md-8"><input type="text" class="form-control" id="aSearch" placeholder="Search applicant, position, ID..."></div>
                <div class="col-md-4"><select class="form-select" id="aStF"><option value="">All Status</option><option value="pending">Pending</option><option value="review">Under Review</option><option value="approved">Approved</option><option value="rejected">Rejected</option></select></div>
            </div>
            <div class="card"><div class="card-header bg-white"><h6 class="fw-bold mb-0">Applications (<span id="aCount">0</span>)</h6></div>
            <div class="card-body p-0"><div class="table-responsive"><table class="table table-applications mb-0">
                <thead><tr><th class="ps-3">APP ID</th><th>Applicant</th><th>Position</th><th>Department</th><th>Submitted</th><th>Status</th><th class="pe-3">Resume</th></tr></thead>
                <tbody id="appsTable"></tbody>
            </table></div></div></div>
        </div>

        <!-- JOBS -->
        <div class="dsec" id="sec-jobs">
            <div class="mb-4"><h3 class="fw-bold">Job Postings</h3></div>
            <div class="row g-4">
                <div class="col-md-5"><div class="card"><div class="card-header bg-white"><h6 class="fw-bold mb-0"><i class="fas fa-plus-circle text-primary me-2"></i>Post New Job</h6></div>
                <div class="card-body">
                    <input type="hidden" id="jobEditId">
                    <div class="mb-3"><label class="form-label small fw-medium">Job Title *</label><input type="text" class="form-control" id="jt" placeholder="e.g. Software Engineer"></div>
                    <div class="mb-3"><label class="form-label small fw-medium">Department *</label><select class="form-select" id="jd"><option value="">Select</option><option value="1">Information Technology</option><option value="2">Human Resources</option><option value="3">Finance</option><option value="4">Education</option><option value="5">Operations</option></select></div>
                    <div class="mb-3"><label class="form-label small fw-medium">Description</label><textarea class="form-control" id="jdesc" rows="2"></textarea></div>
                    <div class="mb-3"><label class="form-label small fw-medium">Requirements</label><textarea class="form-control" id="jreq" rows="2"></textarea></div>
                    <div class="row g-2 mb-3">
                        <div class="col-6"><label class="form-label small fw-medium">Slots</label><input type="number" class="form-control" id="jslots" value="1" min="1"></div>
                        <div class="col-6"><label class="form-label small fw-medium">Status</label><select class="form-select" id="jstatus"><option value="open">Open</option><option value="closed">Closed</option><option value="on_hold">On Hold</option></select></div>
                    </div>
                    <button type="button" class="btn btn-primary w-100" id="postJobBtn" onclick="saveJob()"><i class="fas fa-bullhorn me-2"></i>Post Job</button>
                </div></div></div>
                <div class="col-md-7"><div class="card"><div class="card-header bg-white d-flex justify-content-between align-items-center flex-wrap gap-2">
                    <h6 class="fw-bold mb-0">Jobs (<span id="jCount">0</span>)</h6>
                    <div class="d-flex gap-2"><input type="text" class="form-control form-control-sm" id="jSearch" placeholder="Search..." style="width:130px"><select class="form-select form-select-sm" id="jStF" style="width:110px"><option value="">All</option><option value="open">Open</option><option value="closed">Closed</option><option value="on_hold">On Hold</option></select></div>
                </div>
                <div class="card-body p-0"><div class="table-responsive"><table class="table table-sm table-applications mb-0">
                    <thead><tr><th>Title</th><th>Department</th><th>Status</th><th>Date</th><th>Actions</th></tr></thead>
                    <tbody id="jobsTable"></tbody>
                </table></div></div></div></div>
            </div>
        </div>

        <!-- HR ACCOUNTS -->
        <div class="dsec" id="sec-hr">
            <div class="mb-4"><h3 class="fw-bold">HR Staff Management</h3></div>
            <div class="row g-4">
                <div class="col-md-5"><div class="card"><div class="card-header bg-white"><h6 class="fw-bold mb-0"><i class="fas fa-user-plus text-primary me-2"></i>Create HR Account</h6></div>
                <div class="card-body">
                    <div class="mb-3"><label class="form-label small fw-medium">Full Name *</label><input type="text" class="form-control" id="hr-name" placeholder="Maria Santos"></div>
                    <div class="mb-3"><label class="form-label small fw-medium">Email *</label><input type="email" class="form-control" id="hr-email" placeholder="maria@tncompany.com"></div>
                    <div class="mb-3"><label class="form-label small fw-medium">Password *</label><input type="password" class="form-control" id="hr-pw" placeholder="Min. 6 characters"></div>
                    <div class="mb-3"><label class="form-label small fw-medium">Department *</label><select class="form-select" id="hr-dept"><option value="">Select</option><option>Human Resources</option><option>Information Technology</option><option>Finance</option><option>Education</option><option>Marketing</option><option>Operations</option></select></div>
                    <button type="button" class="btn btn-dark w-100" onclick="createHR()"><i class="fas fa-plus me-2"></i>Create HR Account</button>
                </div></div></div>
                <div class="col-md-7"><div class="card"><div class="card-header bg-white d-flex justify-content-between align-items-center">
                    <h6 class="fw-bold mb-0">HR Staff (<span id="hrCount">0</span>)</h6>
                    <input type="text" class="form-control form-control-sm" id="hrSearch" placeholder="Search..." style="width:180px">
                </div>
                <div class="card-body p-0"><div class="table-responsive"><table class="table table-sm table-applications mb-0">
                    <thead><tr><th class="ps-3">Name</th><th>Email</th><th>Status</th><th class="pe-3">Actions</th></tr></thead>
                    <tbody id="hrTable"></tbody>
                </table></div></div></div></div>
            </div>
        </div>

        <!-- ALL USERS -->
        <div class="dsec" id="sec-users">
            <div class="mb-4"><h3 class="fw-bold">All Users</h3></div>
            <div class="row mb-3 g-2">
                <div class="col-md-8"><input type="text" class="form-control" id="uSearch" placeholder="Search name or email..."></div>
                <div class="col-md-4"><select class="form-select" id="uRoleF"><option value="">All Roles</option><option value="applicant">Applicant</option><option value="hr">HR Staff</option><option value="admin">Admin</option></select></div>
            </div>
            <div class="card"><div class="card-header bg-white"><h6 class="fw-bold mb-0">Users (<span id="uCount">0</span>)</h6></div>
            <div class="card-body p-0"><div class="table-responsive"><table class="table table-applications mb-0">
                <thead><tr><th class="ps-3">Name</th><th>Email</th><th>Role</th><th>Status</th><th class="pe-3">Registered</th></tr></thead>
                <tbody id="usersTable"></tbody>
            </table></div></div></div>
        </div>

        <!-- AUDIT -->
        <div class="dsec" id="sec-audit">
            <div class="mb-4"><h3 class="fw-bold">System Audit Log</h3><p class="text-muted mb-0">(<span id="logCount">0</span> records)</p></div>
            <div class="row mb-3 g-2">
                <div class="col-md-8"><input type="text" class="form-control" id="auditSearch" placeholder="Search log descriptions..."></div>
                <div class="col-md-4"><select class="form-select" id="auditActF"><option value="">All Actions</option><option value="login">Login</option><option value="logout">Logout</option><option value="application_create">Application Create</option><option value="status_update">Status Update</option><option value="job_post">Job Post</option><option value="job_update">Job Update</option><option value="job_delete">Job Delete</option><option value="account_created">Account Created</option><option value="account_update">Account Update</option><option value="account_delete">Account Delete</option></select></div>
            </div>
            <div class="card"><div class="card-body" id="auditList"><div class="text-center py-4"><div class="spinner-border text-primary"></div></div></div></div>
        </div>
    </div>
</div>
<div class="toast-container-custom"></div>
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo base_url('assets/js/utils.js'); ?>"></script>
<script>
const BASE='<?php echo base_url(); ?>';
const SL={pending:'Pending',review:'Under Review',approved:'Approved',rejected:'Rejected'};
const JSL={open:'<span class="status-badge status-approved">Open</span>',closed:'<span class="status-badge status-rejected">Closed</span>',on_hold:'<span class="status-badge status-review">On Hold</span>'};
let allApps=[],allJobs=[],allHR=[],allUsers=[];

function drawDonut(approved, pending, review, rejected) {
    var total = approved + pending + review + rejected;
    var seg = document.getElementById('donutSegments');
    seg.innerHTML = '';
    if (total === 0) return;
    var colors = ['#16a34a','#eab308','#9333ea','#dc2626'];
    var values = [approved, pending, review, rejected];
    var r = 60, circ = 2 * Math.PI * r;
    var startOffset = circ * 0.25;
    for (var i = 0; i < values.length; i++) {
        if (values[i] === 0) continue;
        var dash = (values[i] / total) * circ;
        var circle = document.createElementNS('http://www.w3.org/2000/svg','circle');
        circle.setAttribute('cx','80');
        circle.setAttribute('cy','80');
        circle.setAttribute('r', r);
        circle.setAttribute('fill','none');
        circle.setAttribute('stroke', colors[i]);
        circle.setAttribute('stroke-width','28');
        circle.setAttribute('stroke-dasharray', dash + ' ' + (circ - dash));
        circle.setAttribute('stroke-dashoffset', startOffset);
        seg.appendChild(circle);
        startOffset -= dash;
    }
}

function loadStats(){$.get(BASE+'admin/api/stats',function(r){if(!r.success)return;const d=r.data,c=d.counts;$('#as-total').text(c.total);$('#as-users').text(d.userCount);$('#as-approved').text(c.approved);$('#as-jobs').text(d.openJobs);$('#pie-app').text(c.approved);$('#pie-pend').text(c.pending);$('#pie-rev').text(c.review);$('#pie-rej').text(c.rejected);$('#pieTotal').text(c.total);drawDonut(c.approved, c.pending, c.review, c.rejected);const rc=$('#recentApps');rc.html('');if(!d.recent.length){rc.html('<p class="text-muted text-center py-4">No applications yet.</p>');return;}d.recent.forEach(x=>rc.append(`<div class="d-flex justify-content-between align-items-center py-2 border-bottom"><div><div class="fw-medium small">${x.applicant_name}</div><div class="text-muted" style="font-size:.72rem">${x.position}</div></div><span class="status-badge status-${x.status}" style="font-size:.7rem">${SL[x.status]}</span></div>`));});}

function loadApps(){$.get(BASE+'admin/api/applications',function(r){if(!r.success)return;allApps=r.data;renderApps();});}
function renderApps(){
    const s=$('#aSearch').val().toLowerCase(),st=$('#aStF').val();
    let apps=[...allApps];
    if(s) apps=apps.filter(a=>a.applicant_name.toLowerCase().includes(s)||a.position.toLowerCase().includes(s)||a.app_code.toLowerCase().includes(s));
    if(st) apps=apps.filter(a=>a.status===st);
    const tb=$('#appsTable');tb.html('');$('#aCount').text(apps.length);
    if(!apps.length){tb.html('<tr><td colspan="7" class="text-center py-4 text-muted">No applications found.</td></tr>');return;}
    apps.forEach(a=>tb.append(`<tr><td class="ps-3 fw-medium small">${a.app_code}</td><td>${a.applicant_name}</td><td>${a.position}</td><td><span class="badge bg-light text-dark">${a.department}</span></td><td class="small">${a.submitted_fmt}</td><td><span class="status-badge status-${a.status}">${SL[a.status]}</span></td><td class="pe-3">${a.resume_url?`<a href="${a.resume_url}" target="_blank" class="btn btn-sm btn-outline-primary py-0 px-2" style="font-size:.7rem"><i class="fas fa-file-pdf me-1"></i>Resume</a>`:'<span class="text-muted small">—</span>'}</td></tr>`));
}
$('#aSearch,#aStF').on('input change',renderApps);

function loadJobs(){$.get(BASE+'admin/api/jobs',function(r){if(!r.success)return;allJobs=r.data;renderJobs();});}
function renderJobs(){
    const s=$('#jSearch').val().toLowerCase(),st=$('#jStF').val();
    let jobs=[...allJobs];
    if(s) jobs=jobs.filter(j=>j.title.toLowerCase().includes(s));
    if(st) jobs=jobs.filter(j=>j.status===st);
    const tb=$('#jobsTable');tb.html('');$('#jCount').text(jobs.length);
    if(!jobs.length){tb.html('<tr><td colspan="5" class="text-center py-4 text-muted">No jobs found.</td></tr>');return;}
    jobs.forEach(j=>tb.append(`<tr><td class="fw-medium">${j.title}</td><td><span class="badge bg-light text-dark">${j.department_name}</span></td><td>${JSL[j.status]||j.status}</td><td class="small text-muted">${j.created_fmt}</td><td><button class="btn btn-sm btn-outline-secondary edit-job-btn me-1" data-id="${j.id}"><i class="fas fa-edit"></i></button><button class="btn btn-sm btn-outline-danger del-job-btn" data-id="${j.id}"><i class="fas fa-trash"></i></button></td></tr>`));
}
$('#jSearch,#jStF').on('input change',renderJobs);
function saveJob(){
    const id=$('#jobEditId').val(),title=$('#jt').val().trim(),dept=$('#jd').val(),desc=$('#jdesc').val(),req=$('#jreq').val(),status=$('#jstatus').val();
    if(!title||!dept){showToast('Title and department required.','warning');return;}
    $.post(BASE+'admin/api/job/save',{id,title,department_id:dept,description:desc,requirements:req,status},function(r){
        if(r.success){showToast(r.message,'success');$('#jobEditId').val('');$('#jt,#jdesc,#jreq').val('');$('#jd').val('');$('#jstatus').val('open');$('#postJobBtn').html('<i class="fas fa-bullhorn me-2"></i>Post Job');loadJobs();loadStats();}
        else showToast(r.message,'error');
    });
}
$(document).on('click','.edit-job-btn',function(){const j=allJobs.find(x=>x.id==parseInt($(this).data('id')));if(!j)return;$('#jobEditId').val(j.id);$('#jt').val(j.title);$('#jd').val(j.department_id);$('#jdesc').val(j.description);$('#jreq').val(j.requirements);$('#jstatus').val(j.status);$('#postJobBtn').html('<i class="fas fa-save me-2"></i>Update Job');showSec('sec-jobs',$('#nav-jobs')[0]);});
$(document).on('click','.del-job-btn',function(){if(!confirm('Delete this job?'))return;$.post(BASE+'admin/api/job/delete',{id:$(this).data('id')},function(r){if(r.success){showToast(r.message,'warning');loadJobs();loadStats();}else showToast(r.message,'error');});});

function loadHR(){$.get(BASE+'admin/api/hr-accounts',function(r){if(!r.success)return;allHR=r.data;renderHR();});}
function renderHR(){
    const s=$('#hrSearch').val().toLowerCase();
    let hrs=[...allHR];if(s)hrs=hrs.filter(u=>u.full_name.toLowerCase().includes(s)||u.email.toLowerCase().includes(s));
    const tb=$('#hrTable');tb.html('');$('#hrCount').text(hrs.length);
    if(!hrs.length){tb.html('<tr><td colspan="4" class="text-center py-4 text-muted">No HR accounts.</td></tr>');return;}
    hrs.forEach(u=>tb.append(`<tr><td class="ps-3 fw-medium">${u.full_name}</td><td>${u.email}</td><td><span class="status-badge status-${u.status==='active'?'approved':'rejected'}">${u.status==='active'?'Active':u.status}</span></td><td class="pe-3"><button class="btn btn-sm btn-outline-warning me-1 tog-hr" data-id="${u.id}" data-status="${u.status}"><i class="fas fa-${u.status==='active'?'ban':'check'}"></i></button><button class="btn btn-sm btn-outline-danger del-hr" data-id="${u.id}"><i class="fas fa-trash"></i></button></td></tr>`));
}
$('#hrSearch').on('input',renderHR);
function createHR(){
    const name=$('#hr-name').val().trim(),email=$('#hr-email').val().trim(),pw=$('#hr-pw').val(),dept=$('#hr-dept').val();
    if(!name||!email||!pw||!dept){showToast('Fill all fields.','warning');return;}
    $.post(BASE+'admin/api/hr/create',{name,email,password:pw,department:dept},function(r){if(r.success){showToast(r.message,'success');$('#hr-name,#hr-email,#hr-pw').val('');$('#hr-dept').val('');loadHR();loadStats();}else showToast(r.message,'error');});
}
$(document).on('click','.tog-hr',function(){$.post(BASE+'admin/api/hr/toggle',{id:$(this).data('id')},function(r){if(r.success){showToast(r.message,r.data.status==='active'?'success':'warning');loadHR();}else showToast(r.message,'error');});});
$(document).on('click','.del-hr',function(){if(!confirm('Delete this HR account?'))return;$.post(BASE+'admin/api/hr/delete',{id:$(this).data('id')},function(r){if(r.success){showToast(r.message,'warning');loadHR();loadStats();}else showToast(r.message,'error');});});

function loadUsers(){$.get(BASE+'admin/api/users',function(r){if(!r.success)return;allUsers=r.data;renderUsers();});}
function renderUsers(){
    const s=$('#uSearch').val().toLowerCase(),role=$('#uRoleF').val();
    let users=[...allUsers];if(s)users=users.filter(u=>u.full_name.toLowerCase().includes(s)||u.email.toLowerCase().includes(s));if(role)users=users.filter(u=>u.role===role);
    const tb=$('#usersTable');tb.html('');$('#uCount').text(users.length);
    const rc={applicant:'bg-primary',hr:'bg-success',admin:'bg-warning text-dark'};
    users.forEach(u=>tb.append(`<tr><td class="ps-3 fw-medium">${u.full_name}</td><td>${u.email}</td><td><span class="badge ${rc[u.role]||'bg-secondary'}">${u.role}</span></td><td><span class="status-badge status-${u.status==='active'?'approved':'rejected'}">${u.status}</span></td><td class="pe-3 small text-muted">${u.created_fmt}</td></tr>`));
}
$('#uSearch,#uRoleF').on('input change',renderUsers);

function loadAudit(){
    const s=$('#auditSearch').val(),a=$('#auditActF').val();
    $.get(BASE+'admin/api/audit',{search:s,action:a},function(r){
        if(!r.success)return;
        const ac={login:'success',logout:'secondary',application_create:'primary',status_update:'warning',profile_update:'info',job_post:'success',job_update:'info',job_delete:'danger',account_created:'success',account_delete:'danger',account_update:'warning'};
        const c=$('#auditList');c.html('');$('#logCount').text(r.data.length);
        if(!r.data.length){c.html('<p class="text-muted text-center py-4">No logs found.</p>');return;}
        r.data.forEach(l=>{const col=ac[l.action]||'secondary';c.append(`<div class="audit-item"><div class="audit-dot" style="background:var(--bs-${col})"></div><div class="flex-grow-1"><div class="small fw-medium">${l.description}</div><div class="text-muted" style="font-size:.72rem">${l.user_name?l.user_name+' •':''} ${l.ts_fmt}</div></div><span class="badge bg-${col} ${col==='warning'?'text-dark':''}" style="font-size:.65rem;white-space:nowrap;align-self:start">${l.action.replace(/_/g,' ')}</span></div>`);});
    });
}
$('#auditSearch,#auditActF').on('input change',loadAudit);

function showSec(id,el){$('.dsec').removeClass('active');$('#'+id).addClass('active');$('.sidebar-item').removeClass('active');$(el).addClass('active');}
$('#nav-dash').on('click',function(){showSec('sec-dash',this);loadStats();});
$('#nav-apps').on('click',function(){showSec('sec-apps',this);loadApps();});
$('#nav-jobs').on('click',function(){showSec('sec-jobs',this);loadJobs();});
$('#nav-hr').on('click',function(){showSec('sec-hr',this);loadHR();});
$('#nav-users').on('click',function(){showSec('sec-users',this);loadUsers();});
$('#nav-audit').on('click',function(){showSec('sec-audit',this);loadAudit();});
$('#logoutBtn').on('click',()=>window.location.href=BASE+'signout');
$('#mobileToggle').on('click',()=>{$('.sidebar').toggleClass('open');$('.sb-overlay').toggleClass('show');});
$('.sb-overlay').on('click',()=>{$('.sidebar').removeClass('open');$('.sb-overlay').removeClass('show');});
$(()=>{loadStats();});
</script>
</body>
</html>
