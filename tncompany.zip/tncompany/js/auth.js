$(document).ready(function(){
  // SIGN IN
  if($('#signinForm').length){
    $('#togglePassword').on('click',function(){
      const p=$('#password'),i=$(this).find('i');
      p.attr('type',p.attr('type')==='password'?'text':'password');
      i.toggleClass('fa-eye fa-eye-slash');
    });
    $('#signinForm').on('submit',function(e){
      e.preventDefault();
      const email=$('#email').val().trim().toLowerCase(), pw=$('#password').val();
      let role='applicant';
      if($('#hr-tab').hasClass('active')) role='hr';
      if($('#admin-tab').hasClass('active')) role='admin';
      const u=DB.getUsers().find(u=>u.email.toLowerCase()===email&&u.password===pw&&u.role===role);
      if(u){
        if(u.status==='suspended'){showToast('Account suspended. Contact admin.','error');return;}
        DB.setUser(u); DB.addLog(u.id,'login',`${u.name} (${u.role}) logged in.`);
        showToast('Login successful! Redirecting...','success');
        setTimeout(()=>{window.location.href={applicant:'applicant.html',hr:'hr.html',admin:'admin.html'}[u.role];},800);
      } else { showToast('Invalid credentials or role.','error'); }
    });
  }

  // SIGN UP
  if($('#signupFormContainer').length){
    let step=1, fd={};
    function circles(){
      [1,2,3].forEach(s=>{
        const c=$('#c'+s);c.removeClass('active completed inactive');
        if(s<step) c.addClass('completed').html('<i class="fas fa-check" style="font-size:.65rem"></i>');
        else if(s===step) c.addClass('active').text(s);
        else c.addClass('inactive').text(s);
        $('#l'+s+' .step-line').toggleClass('completed',s<step);
      });
      ['#lbl1','#lbl2','#lbl3'].forEach((id,i)=>{
        $(id).toggleClass('text-primary fw-semibold',i+1===step).toggleClass('text-muted',i+1!==step);
      });
    }
    function show(s){
      step=s; circles();
      const c=$('#signupFormContainer');
      if(s===1) c.html(step1Html());
      else if(s===2) c.html(step2Html());
      else c.html(step3Html());
    }
    function step1Html(){return `
      <h5 class="fw-bold text-center mb-1">Personal Information</h5>
      <p class="text-muted text-center small mb-4">Tell us about yourself.</p>
      <div class="row g-3">
        <div class="col-6"><label class="form-label small">First Name *</label><input class="form-control" id="fn" value="${fd.fn||''}" placeholder="Juan"></div>
        <div class="col-6"><label class="form-label small">Last Name *</label><input class="form-control" id="ln" value="${fd.ln||''}" placeholder="Dela Cruz"></div>
        <div class="col-6"><label class="form-label small">Date of Birth *</label><input type="date" class="form-control" id="dob" value="${fd.dob||''}"></div>
        <div class="col-6"><label class="form-label small">Gender *</label>
          <select class="form-select" id="gen"><option value="">Select</option>
            <option value="male" ${fd.gen==='male'?'selected':''}>Male</option>
            <option value="female" ${fd.gen==='female'?'selected':''}>Female</option>
            <option value="other" ${fd.gen==='other'?'selected':''}>Other</option></select></div>
        <div class="col-6"><label class="form-label small">Phone *</label><input class="form-control" id="ph" value="${fd.ph||''}" placeholder="+63 912 345 6789"></div>
        <div class="col-6"><label class="form-label small">Email *</label><input type="email" class="form-control" id="em" value="${fd.em||''}" placeholder="you@email.com"></div>
        <div class="col-12"><label class="form-label small">Address *</label><textarea class="form-control" id="addr" rows="2">${fd.addr||''}</textarea></div>
        <div class="col-12"><button class="btn btn-primary w-100" onclick="window._s1next()">Next <i class="fas fa-arrow-right ms-1"></i></button></div>
      </div>`;}
    function step2Html(){return `
      <h5 class="fw-bold text-center mb-1">Account Setup</h5>
      <p class="text-muted text-center small mb-4">Create your login credentials.</p>
      <div class="row g-3">
        <div class="col-12"><label class="form-label small">Email</label><input class="form-control" value="${fd.em}" disabled></div>
        <div class="col-12"><label class="form-label small">Password *</label>
          <div class="input-group"><input type="password" class="form-control" id="pw" value="${fd.pw||''}" placeholder="Min. 6 characters">
          <button class="btn btn-outline-secondary" type="button" onclick="const e=$('#pw');e.attr('type',e.attr('type')==='password'?'text':'password')"><i class="fas fa-eye"></i></button></div></div>
        <div class="col-12"><label class="form-label small">Confirm Password *</label>
          <div class="input-group"><input type="password" class="form-control" id="cpw" value="${fd.cpw||''}" placeholder="Re-enter password">
          <button class="btn btn-outline-secondary" type="button" onclick="const e=$('#cpw');e.attr('type',e.attr('type')==='password'?'text':'password')"><i class="fas fa-eye"></i></button></div></div>
        <div class="col-12"><div class="form-check"><input class="form-check-input" type="checkbox" id="terms" ${fd.terms?'checked':''}>
          <label class="form-check-label small" for="terms">I agree to the <a href="terms.html" target="_blank">Terms of Service</a> and <a href="privacy.html" target="_blank">Privacy Policy</a></label></div></div>
        <div class="col-12 d-flex gap-2">
          <button class="btn btn-outline-secondary flex-fill" onclick="window._show(1)"><i class="fas fa-arrow-left me-1"></i> Back</button>
          <button class="btn btn-primary flex-fill" onclick="window._s2next()">Next <i class="fas fa-arrow-right ms-1"></i></button></div>
      </div>`;}
    function step3Html(){const gm={male:'Male',female:'Female',other:'Other'};return `
      <h5 class="fw-bold text-center mb-1">Confirm Details</h5>
      <p class="text-muted text-center small mb-4">Review before submitting.</p>
      <div class="bg-light rounded-3 p-3 mb-3">
        <div class="row g-2 small">
          <div class="col-6"><div class="text-muted">Full Name</div><div class="fw-medium">${fd.fn} ${fd.ln}</div></div>
          <div class="col-6"><div class="text-muted">Date of Birth</div><div class="fw-medium">${fmtDate(fd.dob)}</div></div>
          <div class="col-6"><div class="text-muted">Gender</div><div class="fw-medium">${gm[fd.gen]||'—'}</div></div>
          <div class="col-6"><div class="text-muted">Phone</div><div class="fw-medium">${fd.ph}</div></div>
          <div class="col-12"><div class="text-muted">Email</div><div class="fw-medium">${fd.em}</div></div>
          <div class="col-12"><div class="text-muted">Address</div><div class="fw-medium">${fd.addr}</div></div>
        </div>
      </div>
      <div class="d-flex gap-2">
        <button class="btn btn-outline-secondary flex-fill" onclick="window._show(2)"><i class="fas fa-arrow-left me-1"></i> Back</button>
        <button class="btn btn-success flex-fill" onclick="window._submit()"><i class="fas fa-check me-1"></i> Create Account</button></div>`;}
    window._show=show;
    window._s1next=function(){
      const fn=$('#fn').val().trim(),ln=$('#ln').val().trim(),dob=$('#dob').val(),gen=$('#gen').val(),ph=$('#ph').val().trim(),em=$('#em').val().trim(),addr=$('#addr').val().trim();
      if(!fn||!ln||!dob||!gen||!ph||!em||!addr){showToast('Fill in all required fields.','warning');return;}
      if(!/\S+@\S+\.\S+/.test(em)){showToast('Invalid email.','warning');return;}
      if(DB.getUsers().find(u=>u.email.toLowerCase()===em.toLowerCase())){showToast('Email already registered.','error');return;}
      Object.assign(fd,{fn,ln,dob,gen,ph,em,addr}); show(2);
    };
    window._s2next=function(){
      const pw=$('#pw').val(),cpw=$('#cpw').val(),terms=$('#terms').is(':checked');
      if(!pw||pw.length<6){showToast('Password must be at least 6 characters.','warning');return;}
      if(pw!==cpw){showToast('Passwords do not match.','warning');return;}
      if(!terms){showToast('Please accept the Terms of Service.','warning');return;}
      Object.assign(fd,{pw,cpw,terms:true}); show(3);
    };
    window._submit=function(){
      const users=DB.getUsers();
      const nu={id:Date.now(),email:fd.em,password:fd.pw,role:'applicant',name:`${fd.fn} ${fd.ln}`,firstName:fd.fn,lastName:fd.ln,phone:fd.ph,address:fd.addr,dob:fd.dob,gender:fd.gen,status:'active',createdAt:new Date().toISOString()};
      users.push(nu); DB.setUsers(users);
      DB.addLog(nu.id,'account_created',`New applicant account: ${nu.name} (${nu.email})`);
      showToast('Account created! Redirecting to sign in...','success',2500);
      setTimeout(()=>window.location.href='signin.html',2500);
    };
    show(1);
  }
});
