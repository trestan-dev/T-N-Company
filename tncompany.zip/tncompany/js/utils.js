// T&N Shared Utils
function showToast(msg, type='info', ms=3000){
  let c=document.querySelector('.toast-container-custom');
  if(!c){c=document.createElement('div');c.className='toast-container-custom';document.body.appendChild(c);}
  const t=document.createElement('div');
  const ico={success:'fa-check-circle text-success',error:'fa-times-circle text-danger',warning:'fa-exclamation-circle text-warning',info:'fa-info-circle text-primary'};
  t.className=`toast-custom ${type}`;
  t.innerHTML=`<div class="d-flex align-items-center gap-2"><i class="fas ${ico[type]||ico.info}"></i><span>${msg}</span><button onclick="this.closest('.toast-custom').remove()" class="btn-close btn-close-sm ms-auto" style="font-size:0.6rem"></button></div>`;
  c.appendChild(t);
  setTimeout(()=>{t.style.animation='slideOut 0.3s forwards';setTimeout(()=>t.remove(),300);},ms);
}
const DB={
  getUsers:()=>JSON.parse(localStorage.getItem('tn_users')||'[]'),
  setUsers:u=>localStorage.setItem('tn_users',JSON.stringify(u)),
  getApps:()=>JSON.parse(localStorage.getItem('tn_applications')||'[]'),
  setApps:a=>localStorage.setItem('tn_applications',JSON.stringify(a)),
  getJobs:()=>JSON.parse(localStorage.getItem('tn_jobs')||'[]'),
  setJobs:j=>localStorage.setItem('tn_jobs',JSON.stringify(j)),
  getLogs:()=>JSON.parse(localStorage.getItem('tn_logs')||'[]'),
  addLog:(uid,action,desc)=>{const l=DB.getLogs();l.unshift({id:Date.now(),userId:uid,action,description:desc,ts:new Date().toISOString()});localStorage.setItem('tn_logs',JSON.stringify(l.slice(0,500)));},
  getUser:()=>JSON.parse(sessionStorage.getItem('tn_user')||'null'),
  setUser:u=>sessionStorage.setItem('tn_user',JSON.stringify(u)),
  clearUser:()=>sessionStorage.removeItem('tn_user')
};
function fmtDate(d){if(!d)return '—';try{return new Date(d).toLocaleDateString('en-PH',{year:'numeric',month:'short',day:'numeric'});}catch{return d;}}
function fmtTS(d){if(!d)return '—';try{return new Date(d).toLocaleString('en-PH');}catch{return d;}}
function genCode(){const a=DB.getApps();return 'APP-'+String(Math.floor(Math.random()*900)+100)+'-'+String(a.length+1).padStart(3,'0');}
function requireAuth(role){
  const u=DB.getUser();
  if(!u){window.location.href='signin.html';return null;}
  if(role&&u.role!==role){showToast('Access denied','error');setTimeout(()=>window.location.href='signin.html',1500);return null;}
  return u;
}
// Seed
(function seed(){
  if(!localStorage.getItem('tn_seeded')){
    DB.setUsers([
      {id:1,email:'applicant@test.com',password:'test123',role:'applicant',name:'John Doe',firstName:'John',lastName:'Doe',phone:'+63 912 345 6789',address:'Manila, Philippines',dob:'1995-06-15',gender:'male',status:'active',createdAt:'2025-01-10T08:00:00Z'},
      {id:2,email:'hr@test.com',password:'test123',role:'hr',name:'Maria Santos',firstName:'Maria',lastName:'Santos',phone:'+63 917 234 5678',department:'Human Resources',status:'active',createdAt:'2025-01-05T08:00:00Z'},
      {id:3,email:'admin@test.com',password:'admin123',role:'admin',name:'Administrator',firstName:'System',lastName:'Admin',status:'active',createdAt:'2025-01-01T08:00:00Z'}
    ]);
    DB.setJobs([
      {id:1,title:'Software Engineer',department:'Information Technology',description:'Develop and maintain web applications using modern frameworks.',requirements:'BS Computer Science or related. 2+ years experience. Proficient in JavaScript, PHP.',slots:3,status:'open',postedBy:'Maria Santos',createdAt:'2025-01-15T08:00:00Z'},
      {id:2,title:'Data Analyst',department:'Information Technology',description:'Analyze data sets to identify trends and business insights.',requirements:'BS Statistics, Math, or CS. Proficient in Excel, SQL, Python. Strong analytical skills.',slots:2,status:'open',postedBy:'Maria Santos',createdAt:'2025-01-20T08:00:00Z'},
      {id:3,title:'HR Officer',department:'Human Resources',description:'Handle recruitment, employee relations, and HR administration.',requirements:'BS Human Resource Management or Psychology. 1+ year HR experience.',slots:1,status:'open',postedBy:'Administrator',createdAt:'2025-02-01T08:00:00Z'},
      {id:4,title:'Accountant',department:'Finance',description:'Manage financial records, prepare reports, and ensure compliance.',requirements:'BS Accountancy. CPA preferred. Knowledge of QuickBooks or SAP.',slots:1,status:'open',postedBy:'Administrator',createdAt:'2025-02-10T08:00:00Z'},
      {id:5,title:'Teacher',department:'Education',description:'Deliver quality instruction and manage classroom activities.',requirements:'BS Education or relevant degree. LET passer preferred. 1+ year teaching experience.',slots:2,status:'closed',postedBy:'Administrator',createdAt:'2025-02-15T08:00:00Z'},
      {id:6,title:'Marketing Specialist',department:'Marketing',description:'Plan and execute marketing campaigns across digital and traditional channels.',requirements:'BS Marketing or Communications. Experience in social media marketing.',slots:1,status:'on_hold',postedBy:'Maria Santos',createdAt:'2025-03-01T08:00:00Z'}
    ]);
    DB.setApps([
      {id:'APP-220-001',applicantId:1,applicant:'John Doe',email:'applicant@test.com',phone:'+63 912 345 6789',jobId:1,position:'Software Engineer',department:'Information Technology',notes:'',resume:'',status:'approved',reviewedBy:'Maria Santos',reviewNotes:'Excellent candidate with strong technical background.',reviewedAt:'2025-02-20',submitted:'2025-02-15'},
      {id:'APP-220-002',applicantId:1,applicant:'John Doe',email:'applicant@test.com',phone:'+63 912 345 6789',jobId:2,position:'Data Analyst',department:'Information Technology',notes:'',resume:'',status:'pending',reviewedBy:null,reviewNotes:'',reviewedAt:null,submitted:'2025-03-02'},
      {id:'APP-220-003',applicantId:1,applicant:'John Doe',email:'applicant@test.com',phone:'+63 912 345 6789',jobId:3,position:'HR Officer',department:'Human Resources',notes:'I have 2 years of related experience.',resume:'',status:'review',reviewedBy:null,reviewNotes:'Reviewing documents.',reviewedAt:null,submitted:'2025-03-10'},
    ]);
    DB.addLog(3,'system_init','System initialized with default data.');
    localStorage.setItem('tn_seeded','1');
  }
})();
