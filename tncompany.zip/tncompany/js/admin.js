$(document).ready(function(){
  const user=requireAuth('admin'); if(!user) return;
  DB.addLog(user.id,'page_view','Admin viewed dashboard.');
  const SL={pending:'Pending',review:'Under Review',approved:'Approved',rejected:'Rejected'};
  let aSort='submitted',aDir='desc',jSort='createdAt',jDir='desc',uSort='createdAt',uDir='desc';

  function stats(){
    const a=DB.getApps(),u=DB.getUsers(),j=DB.getJobs();
    const c={total:a.length,pending:0,review:0,approved:0,rejected:0};
    a.forEach(x=>{if(c[x.status]!==undefined)c[x.status]++;});
    $('#as-total').text(c.total);$('#as-users').text(u.length);$('#as-approved').text(c.approved);$('#as-jobs').text(j.filter(x=>x.status==='open').length);
    $('#pie-app').text(c.approved);$('#pie-pend').text(c.pending);$('#pie-rev').text(c.review);$('#pie-rej').text(c.rejected);
    const tot=c.total||1;
    const go=(v)=>((v/tot)*100).toFixed(1);
    document.querySelector('.pie-chart').style.background=
      `conic-gradient(#16a34a ${go(c.approved)}%,#eab308 ${go(c.approved+c.pending)}%,#9333ea ${go(c.approved+c.pending+c.review)}%,#dc2626 100%)`;
    document.querySelector('.pie-chart-center').textContent=c.total;
    // Recent apps
    const rc=$('#recentApps');rc.html('');a.slice(-5).reverse().forEach(x=>{
      rc.append(`<div class="d-flex justify-content-between align-items-center py-2 border-bottom">
        <div><div class="fw-medium small">${x.applicant}</div><div class="text-muted" style="font-size:.72rem">${x.position}</div></div>
        <span class="status-badge status-${x.status}" style="font-size:.7rem">${SL[x.status]}</span>
      </div>`);
    });
  }

  // All applications
  function renderApps(search='',status='',sort=aSort,dir=aDir){
    aSort=sort;aDir=dir;
    let apps=DB.getApps();
    if(search) apps=apps.filter(a=>a.applicant.toLowerCase().includes(search)||a.position.toLowerCase().includes(search)||a.id.toLowerCase().includes(search));
    if(status) apps=apps.filter(a=>a.status===status);
    apps.sort((a,b)=>{let va=a[sort]||'',vb=b[sort]||'';return dir==='asc'?va.localeCompare(vb):vb.localeCompare(va);});
    const tb=$('#appsTable');tb.html('');$('#aCount').text(apps.length);
    if(!apps.length){tb.html('<tr><td colspan="7" class="text-center py-4 text-muted">No applications found.</td></tr>');return;}
    apps.forEach(a=>{
      tb.append(`<tr>
        <td class="ps-3 fw-medium small">${a.id}</td>
        <td>${a.applicant}</td>
        <td>${a.position}</td>
        <td><span class="badge bg-light text-dark">${a.department}</span></td>
        <td class="small">${fmtDate(a.submitted)}</td>
        <td><span class="status-badge status-${a.status}">${SL[a.status]}</span></td>
        <td class="pe-3">${a.resume?`<a href="${a.resume}" target="_blank" class="btn btn-sm btn-outline-primary py-0 px-2" style="font-size:.7rem"><i class="fas fa-file-pdf me-1"></i>Resume</a>`:'<span class="text-muted small">—</span>'}</td>
      </tr>`);
    });
  }

  // Jobs
  function renderJobs(search='',status='',sort=jSort,dir=jDir){
    jSort=sort;jDir=dir;
    let jobs=DB.getJobs();
    if(search) jobs=jobs.filter(j=>j.title.toLowerCase().includes(search)||j.department.toLowerCase().includes(search));
    if(status) jobs=jobs.filter(j=>j.status===status);
    jobs.sort((a,b)=>{let va=a[sort]||'',vb=b[sort]||'';return dir==='asc'?va.localeCompare(vb):vb.localeCompare(va);});
    const jSL={open:'<span class="status-badge status-approved">Open</span>',closed:'<span class="status-badge status-rejected">Closed</span>',on_hold:'<span class="status-badge status-review">On Hold</span>'};
    const tb=$('#jobsTable');tb.html('');$('#jCount').text(jobs.length);
    if(!jobs.length){tb.html('<tr><td colspan="7" class="text-center py-4 text-muted">No jobs found.</td></tr>');return;}
    jobs.forEach(j=>{
      tb.append(`<tr>
        <td class="fw-medium">${j.title}</td>
        <td><span class="badge bg-light text-dark">${j.department}</span></td>
        <td>${j.slots}</td>
        <td>${jSL[j.status]||j.status}</td>
        <td class="small text-muted">${j.postedBy||'—'}</td>
        <td class="small text-muted">${fmtDate(j.createdAt)}</td>
        <td>
          <button class="btn btn-sm btn-outline-secondary edit-job-btn me-1" data-id="${j.id}"><i class="fas fa-edit"></i></button>
          <button class="btn btn-sm btn-outline-danger del-job-btn" data-id="${j.id}"><i class="fas fa-trash"></i></button>
        </td>
      </tr>`);
    });
  }

  $('#postJobForm').on('submit',function(e){
    e.preventDefault();
    const title=$('#jt').val().trim(),dept=$('#jd').val(),desc=$('#jdesc').val().trim(),req=$('#jreq').val().trim(),slots=parseInt($('#jslots').val())||1,status=$('#jstatus').val();
    if(!title||!dept){showToast('Title and department required.','warning');return;}
    const editId=$('#jobEditId').val();const jobs=DB.getJobs();
    if(editId){
      const idx=jobs.findIndex(j=>j.id===parseInt(editId));
      if(idx>-1){Object.assign(jobs[idx],{title,department:dept,description:desc,requirements:req,slots,status,updatedAt:new Date().toISOString()});DB.setJobs(jobs);DB.addLog(user.id,'job_update',`Job "${title}" updated by admin.`);showToast('Job updated!','success');}
    } else {
      const nj={id:Date.now(),title,department:dept,description:desc,requirements:req,slots,status,postedBy:user.name,createdAt:new Date().toISOString()};
      jobs.push(nj);DB.setJobs(jobs);DB.addLog(user.id,'job_post',`New job "${title}" posted by admin.`);showToast('Job posted!','success');
    }
    this.reset();$('#jobEditId').val('');$('#jstatus').val('open');$('#postJobBtn').text('Post Job');
    renderJobs();stats();
  });

  $(document).on('click','.edit-job-btn',function(){
    const j=DB.getJobs().find(x=>x.id===parseInt($(this).data('id'))); if(!j) return;
    $('#jobEditId').val(j.id);$('#jt').val(j.title);$('#jd').val(j.department);$('#jdesc').val(j.description);$('#jreq').val(j.requirements);$('#jslots').val(j.slots);$('#jstatus').val(j.status);
    $('#postJobBtn').text('Update Job');showSec('sec-jobs',$('#nav-jobs')[0]);
    $('html,body').animate({scrollTop:$('#postJobForm').offset().top-80},400);
  });

  $(document).on('click','.del-job-btn',function(){
    if(!confirm('Delete this job?')) return;
    const id=parseInt($(this).data('id'));const j=DB.getJobs().find(x=>x.id===id);
    DB.setJobs(DB.getJobs().filter(x=>x.id!==id));
    DB.addLog(user.id,'job_delete',`Job "${j?.title}" deleted by admin.`);
    renderJobs();stats();showToast('Job deleted.','warning');
  });

  // HR Accounts
  function renderHR(search=''){
    let users=DB.getUsers().filter(u=>u.role==='hr');
    if(search) users=users.filter(u=>u.name.toLowerCase().includes(search)||u.email.toLowerCase().includes(search));
    const tb=$('#hrTable');tb.html('');$('#hrCount').text(users.length);
    if(!users.length){tb.html('<tr><td colspan="5" class="text-center py-4 text-muted">No HR accounts found.</td></tr>');return;}
    users.forEach(u=>{
      tb.append(`<tr>
        <td class="ps-3 fw-medium">${u.name}</td>
        <td>${u.email}</td>
        <td>${u.department||'—'}</td>
        <td><span class="status-badge status-${u.status==='active'?'approved':'rejected'}">${u.status==='active'?'Active':u.status}</span></td>
        <td class="pe-3">
          <button class="btn btn-sm btn-outline-warning me-1 tog-hr" data-id="${u.id}" data-status="${u.status}"><i class="fas fa-${u.status==='active'?'ban':'check'}"></i></button>
          <button class="btn btn-sm btn-outline-danger del-hr" data-id="${u.id}"><i class="fas fa-trash"></i></button>
        </td>
      </tr>`);
    });
  }

  $('#createHRForm').on('submit',function(e){
    e.preventDefault();
    const name=$('#hr-name').val().trim(),email=$('#hr-email').val().trim().toLowerCase(),pw=$('#hr-pw').val(),dept=$('#hr-dept').val();
    if(!name||!email||!pw||!dept){showToast('Fill all fields.','warning');return;}
    if(DB.getUsers().find(u=>u.email.toLowerCase()===email)){showToast('Email already exists.','error');return;}
    if(pw.length<6){showToast('Password must be at least 6 characters.','warning');return;}
    const users=DB.getUsers();
    const nu={id:Date.now(),email,password:pw,role:'hr',name,firstName:name.split(' ')[0],lastName:name.split(' ').slice(1).join(' '),department:dept,status:'active',createdAt:new Date().toISOString()};
    users.push(nu);DB.setUsers(users);DB.addLog(user.id,'account_created',`Admin created HR account: ${name} (${email})`);
    this.reset();renderHR();stats();showToast(`HR account for ${name} created!`,'success');
  });

  $(document).on('click','.tog-hr',function(){
    const id=parseInt($(this).data('id')),st=$(this).data('status');
    const users=DB.getUsers(),idx=users.findIndex(u=>u.id===id);
    if(idx>-1){users[idx].status=st==='active'?'suspended':'active';DB.setUsers(users);DB.addLog(user.id,'account_update',`HR ${users[idx].name} status: ${users[idx].status}.`);renderHR();showToast(`Account ${users[idx].status}.`,users[idx].status==='active'?'success':'warning');}
  });

  $(document).on('click','.del-hr',function(){
    if(!confirm('Delete this HR account?')) return;
    const id=parseInt($(this).data('id'));const u=DB.getUsers().find(x=>x.id===id);
    DB.setUsers(DB.getUsers().filter(x=>x.id!==id));DB.addLog(user.id,'account_delete',`HR account ${u?.name} deleted.`);
    renderHR();stats();showToast('HR account deleted.','warning');
  });

  // Users overview
  function renderUsers(search='',role=''){
    let users=DB.getUsers();
    if(search) users=users.filter(u=>u.name.toLowerCase().includes(search)||u.email.toLowerCase().includes(search));
    if(role) users=users.filter(u=>u.role===role);
    users.sort((a,b)=>new Date(b.createdAt||0)-new Date(a.createdAt||0));
    const tb=$('#usersTable');tb.html('');$('#uCount').text(users.length);
    users.forEach(u=>{
      const rc={applicant:'bg-primary',hr:'bg-success',admin:'bg-warning text-dark'};
      tb.append(`<tr>
        <td class="ps-3 fw-medium">${u.name}</td>
        <td>${u.email}</td>
        <td><span class="badge ${rc[u.role]||'bg-secondary'}">${u.role}</span></td>
        <td><span class="status-badge status-${u.status==='active'?'approved':'rejected'}">${u.status}</span></td>
        <td class="pe-3 small text-muted">${fmtDate(u.createdAt)}</td>
      </tr>`);
    });
  }

  // Audit
  function renderAudit(search='',action=''){
    let logs=DB.getLogs();
    if(search) logs=logs.filter(l=>l.description.toLowerCase().includes(search));
    if(action) logs=logs.filter(l=>l.action===action);
    const c=$('#auditList');c.html('');$('#logCount').text(logs.length);
    const ac={login:'success',logout:'secondary',application_create:'primary',status_update:'warning',profile_update:'info',job_post:'success',job_update:'info',job_delete:'danger',account_created:'success',account_delete:'danger',account_update:'warning'};
    if(!logs.length){c.html('<p class="text-muted text-center py-4">No logs found.</p>');return;}
    logs.forEach(l=>{
      const col=ac[l.action]||'secondary';const u=DB.getUsers().find(x=>x.id===l.userId);
      c.append(`<div class="audit-item">
        <div class="audit-dot" style="background:var(--bs-${col})"></div>
        <div class="flex-grow-1">
          <div class="small fw-medium">${l.description}</div>
          <div class="text-muted" style="font-size:.72rem">${u?`${u.name} •`:''} ${fmtTS(l.ts)}</div>
        </div>
        <span class="badge bg-${col} ${col==='warning'?'text-dark':'text-white'}" style="font-size:.65rem;white-space:nowrap;align-self:start">${l.action.replace(/_/g,' ')}</span>
      </div>`);
    });
  }

  // Search/filter events
  $('#aSearch,#aStF').on('input change',()=>renderApps($('#aSearch').val().trim().toLowerCase(),$('#aStF').val()));
  $('#jSearch,#jStF').on('input change',()=>renderJobs($('#jSearch').val().trim().toLowerCase(),$('#jStF').val()));
  $('#hrSearch').on('input',()=>renderHR($('#hrSearch').val().trim().toLowerCase()));
  $('#uSearch,#uRoleF').on('input change',()=>renderUsers($('#uSearch').val().trim().toLowerCase(),$('#uRoleF').val()));
  $('#auditSearch,#auditActF').on('input change',()=>renderAudit($('#auditSearch').val().trim().toLowerCase(),$('#auditActF').val()));

  // Sidebar
  function showSec(id,el){$('.dsec').removeClass('active');$('#'+id).addClass('active');$('.sidebar-item').removeClass('active');$(el).addClass('active');}
  $('#nav-dash').on('click',function(){showSec('sec-dash',this);stats();});
  $('#nav-apps').on('click',function(){showSec('sec-apps',this);renderApps();});
  $('#nav-jobs').on('click',function(){showSec('sec-jobs',this);renderJobs();});
  $('#nav-hr').on('click',function(){showSec('sec-hr',this);renderHR();});
  $('#nav-users').on('click',function(){showSec('sec-users',this);renderUsers();});
  $('#nav-audit').on('click',function(){showSec('sec-audit',this);renderAudit();});
  $('#logoutBtn').on('click',()=>{DB.addLog(user.id,'logout',`Admin ${user.name} logged out.`);DB.clearUser();window.location.href='signin.html';});
  $('#mobileToggle').on('click',()=>{$('.sidebar').toggleClass('open');$('.sb-overlay').toggleClass('show');});
  $('.sb-overlay').on('click',()=>{$('.sidebar').removeClass('open');$('.sb-overlay').removeClass('show');});

  stats();
});
