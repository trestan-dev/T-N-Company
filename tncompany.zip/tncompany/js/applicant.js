$(document).ready(function(){
  const user=requireAuth('applicant'); if(!user) return;
  DB.addLog(user.id,'page_view','Applicant viewed dashboard.');
  $('.welcome-name').text('Welcome back, '+user.name);
  $('.user-initials').text(user.name.split(' ').map(n=>n[0]).join('').toUpperCase().slice(0,2));

  function myApps(){return DB.getApps().filter(a=>a.applicantId===user.id);}
  function openJobs(){return DB.getJobs().filter(j=>j.status==='open');}

  // Stats
  function renderStats(){
    const a=myApps(),c={total:a.length,pending:0,review:0,approved:0,rejected:0};
    a.forEach(x=>{if(c[x.status]!==undefined)c[x.status]++;});
    $('#st-total').text(c.total);$('#st-pending').text(c.pending);$('#st-review').text(c.review);$('#st-approved').text(c.approved);
  }

  // Table renderer
  function renderTable(search='',status='',sortCol='submitted',sortDir='desc'){
    let apps=myApps();
    if(search) apps=apps.filter(a=>a.position.toLowerCase().includes(search)||a.id.toLowerCase().includes(search)||a.department.toLowerCase().includes(search));
    if(status) apps=apps.filter(a=>a.status===status);
    apps.sort((a,b)=>{
      let va=a[sortCol]||'',vb=b[sortCol]||'';
      return sortDir==='asc'?va.localeCompare(vb):vb.localeCompare(va);
    });
    const lbl={pending:'Pending',review:'Under Review',approved:'Approved',rejected:'Rejected'};
    const tbody=$('#appTable');tbody.html('');
    if(!apps.length){tbody.html('<tr><td colspan="6" class="text-center py-5 text-muted"><i class="fas fa-inbox fa-2x d-block mb-2"></i>No applications found.</td></tr>');return;}
    apps.forEach(a=>{
      tbody.append(`<tr>
        <td class="ps-3 fw-medium small">${a.id}</td>
        <td>${a.position}</td>
        <td><span class="badge bg-light text-dark">${a.department}</span></td>
        <td class="small">${fmtDate(a.submitted)}</td>
        <td><span class="status-badge status-${a.status}">${lbl[a.status]}</span></td>
        <td class="pe-3"><button class="btn btn-sm btn-outline-secondary view-btn" data-id="${a.id}"><i class="fas fa-eye me-1"></i>View</button></td>
      </tr>`);
    });
  }

  // Populate job modal
  function populateJobSelect(){
    const jobs=openJobs();
    const applied=myApps().map(a=>a.jobId);
    const sel=$('#newJobId');sel.html('<option value="">Select an open position...</option>');
    jobs.forEach(j=>{
      const alreadyApplied=applied.includes(j.id);
      sel.append(`<option value="${j.id}" data-dept="${j.department}" ${alreadyApplied?'disabled':''}>
        ${j.title} — ${j.department}${alreadyApplied?' (Already Applied)':''}</option>`);
    });
    if(!jobs.length) sel.html('<option value="">No open positions available</option>');
  }

  // Auto-fill department on job select
  $(document).on('change','#newJobId',function(){
    const opt=$('option:selected',this);
    $('#newDept').val(opt.data('dept')||'');
  });

  // Submit application
  window.submitApplication=function(){
    const jobId=parseInt($('#newJobId').val());
    const dept=$('#newDept').val();
    const notes=$('#newNotes').val();
    if(!jobId){showToast('Please select a job position.','warning');return;}
    const job=openJobs().find(j=>j.id===jobId);
    if(!job){showToast('Selected position is no longer available.','error');return;}
    // Check duplicate
    if(myApps().find(a=>a.jobId===jobId)){showToast('You have already applied for this position.','warning');return;}
    // Resume
    const fileInput=$('#newResume')[0];
    let resumeData='';
    const saveApp=(resume)=>{
      const apps=DB.getApps();
      const na={id:genCode(),applicantId:user.id,applicant:user.name,email:user.email,phone:user.phone||'',
        jobId,position:job.title,department:job.department,notes,resume,
        status:'pending',reviewedBy:null,reviewNotes:'',reviewedAt:null,submitted:new Date().toISOString().split('T')[0]};
      apps.push(na); DB.setApps(apps);
      DB.addLog(user.id,'application_create',`Application ${na.id} submitted for ${job.title}.`);
      bootstrap.Modal.getInstance($('#newAppModal')[0]).hide();
      $('#newJobId').val('');$('#newDept').val('');$('#newNotes').val('');$('#newResume').val('');
      renderStats(); renderTable($('#search').val().trim().toLowerCase(),$('#statusF').val(),currentSort,currentDir);
      showToast(`Application ${na.id} submitted!`,'success');
    };
    if(fileInput.files&&fileInput.files[0]){
      const r=new FileReader();
      r.onload=e=>saveApp(e.target.result);
      r.readAsDataURL(fileInput.files[0]);
    } else { saveApp(''); }
  };

  // View modal
  $(document).on('click','.view-btn',function(){
    const a=DB.getApps().find(x=>x.id===$(this).data('id')); if(!a) return;
    const lbl={pending:'Pending',review:'Under Review',approved:'Approved',rejected:'Rejected'};
    $('#viewBody').html(`
      <div class="d-flex justify-content-between align-items-start mb-3">
        <div><h5 class="fw-bold mb-0">${a.position}</h5><small class="text-muted">${a.department}</small></div>
        <span class="status-badge status-${a.status}">${lbl[a.status]}</span>
      </div>
      <div class="app-detail-row"><span class="text-muted">Application ID</span><strong>${a.id}</strong></div>
      <div class="app-detail-row"><span class="text-muted">Submitted</span><span>${fmtDate(a.submitted)}</span></div>
      <div class="app-detail-row"><span class="text-muted">Status</span><span class="status-badge status-${a.status}">${lbl[a.status]}</span></div>
      ${a.notes?`<div class="app-detail-row"><span class="text-muted">Your Notes</span><span>${a.notes}</span></div>`:''}
      ${a.reviewNotes?`<div class="app-detail-row"><span class="text-muted">HR Notes</span><span>${a.reviewNotes}</span></div>`:''}
      ${a.reviewedBy?`<div class="app-detail-row"><span class="text-muted">Reviewed By</span><span>${a.reviewedBy}</span></div>`:''}
      ${a.reviewedAt?`<div class="app-detail-row"><span class="text-muted">Review Date</span><span>${fmtDate(a.reviewedAt)}</span></div>`:''}
      ${a.resume?`<div class="mt-3"><a href="${a.resume}" target="_blank" class="btn btn-sm btn-outline-primary"><i class="fas fa-file-pdf me-1"></i>View Uploaded Resume</a></div>`:'<div class="mt-2 small text-muted"><i class="fas fa-info-circle me-1"></i>No resume uploaded.</div>'}
    `);
    new bootstrap.Modal($('#viewModal')[0]).show();
  });

  // Sorting
  let currentSort='submitted',currentDir='desc';
  $(document).on('click','[data-sort]',function(){
    const col=$(this).data('sort');
    if(currentSort===col) currentDir=currentDir==='asc'?'desc':'asc';
    else{currentSort=col;currentDir='asc';}
    $('[data-sort]').find('i').removeClass('fa-sort-up fa-sort-down').addClass('fa-sort');
    $(this).find('i').removeClass('fa-sort').addClass(currentDir==='asc'?'fa-sort-up':'fa-sort-down');
    renderTable($('#search').val().trim().toLowerCase(),$('#statusF').val(),currentSort,currentDir);
  });

  // Search/filter
  $('#search').on('input',()=>renderTable($('#search').val().trim().toLowerCase(),$('#statusF').val(),currentSort,currentDir));
  $('#statusF').on('change',()=>renderTable($('#search').val().trim().toLowerCase(),$('#statusF').val(),currentSort,currentDir));

  // Sidebar nav
  function showSec(id,el){$('.dsec').removeClass('active');$('#'+id).addClass('active');$('.sidebar-item').removeClass('active');$(el).addClass('active');}
  $('#nav-dash').on('click',function(){showSec('sec-dash',this);});
  $('#nav-apps').on('click',function(){showSec('sec-apps',this);renderTable();});
  $('#nav-jobs').on('click',function(){showSec('sec-jobs',this);renderJobsList();});
  $('#nav-profile').on('click',function(){showSec('sec-profile',this);renderProfile();});

  // Job listings for browsing
  function renderJobsList(search='',dept=''){
    let jobs=DB.getJobs().filter(j=>j.status==='open');
    if(search) jobs=jobs.filter(j=>j.title.toLowerCase().includes(search)||j.department.toLowerCase().includes(search));
    if(dept) jobs=jobs.filter(j=>j.department===dept);
    const c=$('#jobsList');c.html('');
    if(!jobs.length){c.html('<div class="text-center py-5 text-muted"><i class="fas fa-briefcase fa-2x d-block mb-2"></i>No open positions found.</div>');return;}
    const applied=myApps().map(a=>a.jobId);
    jobs.forEach(j=>{
      const isApplied=applied.includes(j.id);
      c.append(`<div class="card mb-3">
        <div class="card-body">
          <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
            <div>
              <h5 class="fw-bold mb-1">${j.title}</h5>
              <span class="dept-badge me-2">${j.department}</span>
              <span class="badge bg-success bg-opacity-10 text-success">Open</span>
            </div>
            ${isApplied
              ?'<span class="badge bg-primary py-2 px-3">Already Applied</span>'
              :`<button class="btn btn-primary btn-sm apply-job-btn" data-id="${j.id}"><i class="fas fa-paper-plane me-1"></i>Apply Now</button>`
            }
          </div>
          <p class="text-muted small mt-2 mb-2">${j.description||''}</p>
          <div class="small"><strong>Requirements:</strong> ${j.requirements||'—'}</div>
          <div class="small text-muted mt-1"><i class="fas fa-users me-1"></i>${j.slots} slot(s) available • Posted ${fmtDate(j.createdAt)}</div>
        </div></div>`);
    });
  }

  $(document).on('click','.apply-job-btn',function(){
    const jid=parseInt($(this).data('id'));
    $('#newJobId').val(jid).trigger('change');
    new bootstrap.Modal($('#newAppModal')[0]).show();
  });

  $('#jobSearch').on('input',()=>renderJobsList($('#jobSearch').val().trim().toLowerCase(),$('#jobDeptF').val()));
  $('#jobDeptF').on('change',()=>renderJobsList($('#jobSearch').val().trim().toLowerCase(),$('#jobDeptF').val()));

  // Profile
  function renderProfile(){
    const u=DB.getUser();
    $('.user-initials').text(u.name.split(' ').map(n=>n[0]).join('').toUpperCase().slice(0,2));
    $('#pr-name').text(u.name);$('#pr-email').text(u.email);
    $('#pr-phone').val(u.phone||'');$('#pr-addr').val(u.address||'');
    $('#pr-dob').text(fmtDate(u.dob));$('#pr-gender').text(u.gender?u.gender.charAt(0).toUpperCase()+u.gender.slice(1):'—');
    const a=myApps();$('#pr-total').text(a.length);$('#pr-approved').text(a.filter(x=>x.status==='approved').length);
  }
  $('#saveProfile').on('click',function(){
    const users=DB.getUsers(),idx=users.findIndex(u=>u.id===user.id);
    if(idx>-1){users[idx].phone=$('#pr-phone').val();users[idx].address=$('#pr-addr').val();DB.setUsers(users);DB.setUser(users[idx]);DB.addLog(user.id,'profile_update','Profile updated.');showToast('Profile saved!','success');}
  });

  $('#logoutBtn').on('click',()=>{DB.addLog(user.id,'logout',`${user.name} logged out.`);DB.clearUser();window.location.href='signin.html';});
  $('#mobileToggle').on('click',()=>{$('.sidebar').toggleClass('open');$('.sb-overlay').toggleClass('show');});
  $('.sb-overlay').on('click',()=>{$('.sidebar').removeClass('open');$('.sb-overlay').removeClass('show');});
  $('#newAppModal').on('show.bs.modal',populateJobSelect);

  renderStats(); renderTable();
});
