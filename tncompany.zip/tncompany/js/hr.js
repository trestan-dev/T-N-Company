$(document).ready(function(){
  const user=requireAuth('hr'); if(!user) return;
  DB.addLog(user.id,'page_view','HR viewed dashboard.');
  $('.hr-name').text(user.name);

  const SL={pending:'Pending',review:'Under Review',approved:'Approved',rejected:'Rejected'};
  let curSort='submitted',curDir='desc',curSort2='createdAt',curDir2='desc';

  function stats(){
    const a=DB.getApps(),c={total:a.length,pending:0,review:0,approved:0,rejected:0};
    a.forEach(x=>{if(c[x.status]!==undefined)c[x.status]++;});
    $('#hs-total').text(c.total);$('#hs-pend').text(c.pending);$('#hs-rev').text(c.review);$('#hs-app').text(c.approved);$('#hs-rej').text(c.rejected);
  }

  function renderApps(search='',status='',sort=curSort,dir=curDir){
    curSort=sort;curDir=dir;
    let apps=DB.getApps();
    if(search) apps=apps.filter(a=>a.applicant.toLowerCase().includes(search)||a.position.toLowerCase().includes(search)||a.id.toLowerCase().includes(search));
    if(status) apps=apps.filter(a=>a.status===status);
    apps.sort((a,b)=>{let va=a[sort]||'',vb=b[sort]||'';return dir==='asc'?va.localeCompare(vb):vb.localeCompare(va);});
    const c=$('#appsList');c.html('');$('#appCount').text(apps.length);
    if(!apps.length){c.html('<div class="text-center py-5 text-muted"><i class="fas fa-inbox fa-2x d-block mb-2"></i>No applications found.</div>');return;}
    apps.forEach(a=>{
      const ini=a.applicant.split(' ').map(n=>n[0]).join('').toUpperCase().slice(0,2);
      const clrs=['bg-primary','bg-success','bg-warning','bg-info','bg-danger'];
      const cl=clrs[a.id.charCodeAt(a.id.length-1)%clrs.length];
      c.append(`<div class="card mb-3"><div class="card-body">
        <div class="d-flex gap-3">
          <div class="rounded-circle ${cl} text-white d-flex align-items-center justify-content-center flex-shrink-0 fw-bold" style="width:42px;height:42px;font-size:.8rem">${ini}</div>
          <div class="flex-grow-1">
            <div class="d-flex justify-content-between flex-wrap gap-2">
              <div>
                <h6 class="fw-bold mb-0">${a.applicant}</h6>
                <p class="text-muted small mb-1">${a.position} • <span class="badge bg-light text-dark">${a.department}</span></p>
                <div class="small text-muted"><i class="fas fa-envelope me-1"></i>${a.email||'—'} &nbsp;<i class="fas fa-calendar me-1"></i>${fmtDate(a.submitted)}</div>
                ${a.resume?`<a href="${a.resume}" target="_blank" class="btn btn-xs btn-outline-primary btn-sm mt-1 py-0 px-2" style="font-size:.7rem"><i class="fas fa-file-pdf me-1"></i>View Resume</a>`:''}
              </div>
              <div class="d-flex flex-column align-items-end gap-1">
                <span class="status-badge status-${a.status}">${SL[a.status]}</span>
                <button class="btn btn-sm btn-primary review-btn" data-id="${a.id}"><i class="fas fa-search me-1"></i>Review</button>
              </div>
            </div>
          </div>
        </div>
      </div></div>`);
    });
  }

  // Sorting for app list
  $(document).on('click','[data-sort]',function(){
    const col=$(this).data('sort');
    if(curSort===col) curDir=curDir==='asc'?'desc':'asc'; else{curSort=col;curDir='asc';}
    $('[data-sort] i').removeClass('fa-sort-up fa-sort-down').addClass('fa-sort');
    $(this).find('i').removeClass('fa-sort').addClass(curDir==='asc'?'fa-sort-up':'fa-sort-down');
    renderApps($('#srch').val().trim().toLowerCase(),$('#stF').val(),curSort,curDir);
  });

  // Review modal
  $(document).on('click','.review-btn',function(){
    const a=DB.getApps().find(x=>x.id===$(this).data('id')); if(!a) return;
    $('#rv-id').val(a.id);$('#rv-title').text(a.position);$('#rv-sub').text(a.department+' • '+a.applicant);
    $('#rv-name').text(a.applicant);$('#rv-email').text(a.email||'—');$('#rv-phone').text(a.phone||'—');
    $('#rv-pos').text(a.position);$('#rv-dept').text(a.department);$('#rv-sub-date').text(fmtDate(a.submitted));
    $('#rv-status').html(`<span class="status-badge status-${a.status}">${SL[a.status]}</span>`);
    $('#rv-notes').val(a.reviewNotes||'');$('#rv-statusSel').val(a.status);
    const resumeArea=$('#rv-resume');
    resumeArea.html(a.resume?`<a href="${a.resume}" target="_blank" class="btn btn-sm btn-outline-primary"><i class="fas fa-file-pdf me-1"></i>View Applicant Resume</a>`:'<span class="text-muted small">No resume uploaded.</span>');
    new bootstrap.Modal($('#reviewModal')[0]).show();
  });

  $('#saveReview').on('click',function(){
    const id=$('#rv-id').val(),ns=$('#rv-statusSel').val(),notes=$('#rv-notes').val();
    const apps=DB.getApps(),idx=apps.findIndex(a=>a.id===id);
    if(idx>-1){
      const old=apps[idx].status;
      apps[idx].status=ns;apps[idx].reviewNotes=notes;apps[idx].reviewedBy=user.name;apps[idx].reviewedAt=new Date().toISOString().split('T')[0];
      DB.setApps(apps); DB.addLog(user.id,'status_update',`App ${id} changed from ${old} to ${ns} by ${user.name}.`);
      bootstrap.Modal.getInstance($('#reviewModal')[0]).hide();
      stats(); renderApps($('#srch').val().trim().toLowerCase(),$('#stF').val());
      showToast(`Application ${id} updated to "${ns}".`,'success');
    }
  });

  // Jobs management
  function renderJobs(search='',status='',sort=curSort2,dir=curDir2){
    curSort2=sort;curDir2=dir;
    let jobs=DB.getJobs();
    if(search) jobs=jobs.filter(j=>j.title.toLowerCase().includes(search)||j.department.toLowerCase().includes(search));
    if(status) jobs=jobs.filter(j=>j.status===status);
    jobs.sort((a,b)=>{let va=a[sort]||'',vb=b[sort]||'';return dir==='asc'?va.localeCompare(vb):vb.localeCompare(va);});
    const jSL={open:'<span class="status-badge status-approved">Open</span>',closed:'<span class="status-badge status-rejected">Closed</span>',on_hold:'<span class="status-badge status-review">On Hold</span>'};
    const tb=$('#jobsTable');tb.html('');$('#jobCount').text(jobs.length);
    if(!jobs.length){tb.html('<tr><td colspan="6" class="text-center py-4 text-muted">No jobs found.</td></tr>');return;}
    jobs.forEach(j=>{
      tb.append(`<tr>
        <td class="fw-medium">${j.title}</td>
        <td><span class="badge bg-light text-dark">${j.department}</span></td>
        <td>${j.slots}</td>
        <td>${jSL[j.status]||j.status}</td>
        <td class="small text-muted">${fmtDate(j.createdAt)}</td>
        <td>
          <button class="btn btn-sm btn-outline-secondary edit-job-btn me-1" data-id="${j.id}"><i class="fas fa-edit"></i></button>
          <button class="btn btn-sm btn-outline-danger del-job-btn" data-id="${j.id}"><i class="fas fa-trash"></i></button>
        </td>
      </tr>`);
    });
  }

  $('#postJobForm').on('submit',function(e){
    e.preventDefault();
    const title=$('#jt').val().trim(),dept=$('#jd').val(),desc=$('#jdesc').val().trim(),req=$('#jreq').val().trim(),slots=parseInt($('#jslots').val())||1;
    if(!title||!dept){showToast('Title and department are required.','warning');return;}
    const editId=$('#jobEditId').val();
    const jobs=DB.getJobs();
    if(editId){
      const idx=jobs.findIndex(j=>j.id===parseInt(editId));
      if(idx>-1){Object.assign(jobs[idx],{title,department:dept,description:desc,requirements:req,slots,updatedAt:new Date().toISOString()});DB.setJobs(jobs);DB.addLog(user.id,'job_update',`Job "${title}" updated by ${user.name}.`);showToast('Job updated!','success');}
    } else {
      const nj={id:Date.now(),title,department:dept,description:desc,requirements:req,slots,status:'open',postedBy:user.name,createdAt:new Date().toISOString()};
      jobs.push(nj);DB.setJobs(jobs);DB.addLog(user.id,'job_post',`New job "${title}" posted by ${user.name}.`);showToast('Job posted!','success');
    }
    this.reset();$('#jobEditId').val('');$('#postJobBtn').text('Post Job');
    renderJobs($('#jobSearch').val().trim().toLowerCase(),$('#jobStF').val());
  });

  $(document).on('click','.edit-job-btn',function(){
    const j=DB.getJobs().find(x=>x.id===parseInt($(this).data('id'))); if(!j) return;
    $('#jobEditId').val(j.id);$('#jt').val(j.title);$('#jd').val(j.department);$('#jdesc').val(j.description);$('#jreq').val(j.requirements);$('#jslots').val(j.slots);
    $('#postJobBtn').text('Update Job');
    showSec('sec-jobs',$('#nav-jobs')[0]);
    $('html,body').animate({scrollTop:$('#postJobForm').offset().top-80},400);
  });

  $(document).on('click','.del-job-btn',function(){
    if(!confirm('Delete this job posting?')) return;
    const id=parseInt($(this).data('id'));
    const j=DB.getJobs().find(x=>x.id===id);
    DB.setJobs(DB.getJobs().filter(x=>x.id!==id));
    DB.addLog(user.id,'job_delete',`Job "${j?.title}" deleted by ${user.name}.`);
    renderJobs();showToast('Job deleted.','warning');
  });

  // Audit
  function renderAudit(){
    const logs=DB.getLogs().slice(0,100);const c=$('#auditList');c.html('');
    const ac={login:'success',logout:'secondary',application_create:'primary',status_update:'warning',profile_update:'info',job_post:'success',job_update:'info',job_delete:'danger'};
    if(!logs.length){c.html('<p class="text-muted text-center py-4">No logs found.</p>');return;}
    logs.forEach(l=>{
      const col=ac[l.action]||'secondary';
      c.append(`<div class="audit-item">
        <div class="audit-dot" style="background:var(--bs-${col})"></div>
        <div class="flex-grow-1"><div class="small fw-medium">${l.description}</div><div class="text-muted" style="font-size:.72rem">${fmtTS(l.ts)}</div></div>
        <span class="badge bg-${col} ${col==='warning'?'text-dark':'text-white'}" style="font-size:.65rem;white-space:nowrap;align-self:start">${l.action.replace(/_/g,' ')}</span>
      </div>`);
    });
  }

  // Search/filter events
  $('#srch,#stF').on('input change',()=>renderApps($('#srch').val().trim().toLowerCase(),$('#stF').val()));
  $('#jobSearch,#jobStF').on('input change',()=>renderJobs($('#jobSearch').val().trim().toLowerCase(),$('#jobStF').val()));

  function showSec(id,el){$('.dsec').removeClass('active');$('#'+id).addClass('active');$('.sidebar-item').removeClass('active');$(el).addClass('active');}
  $('#nav-dash').on('click',function(){showSec('sec-dash',this);});
  $('#nav-apps').on('click',function(){showSec('sec-apps',this);renderApps();});
  $('#nav-jobs').on('click',function(){showSec('sec-jobs',this);renderJobs();});
  $('#nav-audit').on('click',function(){showSec('sec-audit',this);renderAudit();});
  $('#logoutBtn').on('click',()=>{DB.addLog(user.id,'logout',`${user.name} logged out.`);DB.clearUser();window.location.href='signin.html';});
  $('#mobileToggle').on('click',()=>{$('.sidebar').toggleClass('open');$('.sb-overlay').toggleClass('show');});
  $('.sb-overlay').on('click',()=>{$('.sidebar').removeClass('open');$('.sb-overlay').removeClass('show');});

  stats(); renderApps();
});
