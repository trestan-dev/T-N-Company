$(document).ready(function() {
    console.log('T&N Registration System Loaded');
    // Smooth scroll for nav links
    $('a[href^="#"]').on('click', function(e) {
        const target = $($(this).attr('href'));
        if (target.length) {
            e.preventDefault();
            $('html, body').animate({ scrollTop: target.offset().top - 70 }, 500);
        }
    });
});
