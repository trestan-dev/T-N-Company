/* ═══════════════════════════════════════════════
   validation.js — jQuery Dynamic Form Validation
   RegisTrack · Famini & Pacalioga · BSIT-2C
═══════════════════════════════════════════════ */

const Validate = (() => {

  /* ── Rules ── */
  const rules = {
    required:   (v) => v.trim() !== '',
    email:      (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.trim()),
    minLen:     (v, n) => v.trim().length >= n,
    maxLen:     (v, n) => v.trim().length <= n,
    phone:      (v) => /^[0-9+\-\s()]{7,20}$/.test(v.trim()),
    noSpecial:  (v) => /^[A-Za-z\s'-]+$/.test(v.trim()),
    pwStrength: (v) => /^(?=.*[A-Za-z])(?=.*\d).{8,}$/.test(v),
    match:      (v, other) => v === $(other).val(),
  };

  /* ── Show/hide field error ── */
  function setError($input, msg) {
    $input.addClass('is-invalid').removeClass('is-valid');
    let $err = $input.siblings('.rt-field-error');
    if (!$err.length) {
      $err = $('<span class="rt-field-error"></span>');
      $input.after($err);
    }
    $err.text(msg).addClass('visible');
  }

  function clearError($input) {
    $input.removeClass('is-invalid').addClass('is-valid');
    $input.siblings('.rt-field-error').removeClass('visible').text('');
  }

  function clearAll($form) {
    $form.find('.rt-input').removeClass('is-invalid is-valid');
    $form.find('.rt-field-error').removeClass('visible').text('');
  }

  /* ── Validate single field ── */
  function validateField($input) {
    const val  = $input.val();
    const req  = $input.data('required');
    const type = $input.data('type');
    const min  = parseInt($input.data('min'));
    const max  = parseInt($input.data('max'));
    const matchSel = $input.data('match');

    if (req && !rules.required(val)) {
      setError($input, $input.data('label') + ' is required.');
      return false;
    }
    if (val.trim() === '') { clearError($input); return true; }

    if (type === 'email' && !rules.email(val)) {
      setError($input, 'Please enter a valid email address.');
      return false;
    }
    if (type === 'phone' && !rules.phone(val)) {
      setError($input, 'Please enter a valid phone number.');
      return false;
    }
    if (type === 'name' && !rules.noSpecial(val)) {
      setError($input, 'Only letters, spaces, hyphens and apostrophes allowed.');
      return false;
    }
    if (type === 'password' && !rules.pwStrength(val)) {
      setError($input, 'Password must be 8+ characters and include letters and numbers.');
      return false;
    }
    if (!isNaN(min) && !rules.minLen(val, min)) {
      setError($input, `Minimum ${min} characters required.`);
      return false;
    }
    if (!isNaN(max) && !rules.maxLen(val, max)) {
      setError($input, `Maximum ${max} characters allowed.`);
      return false;
    }
    if (matchSel) {
      if (!rules.match(val, matchSel)) {
        setError($input, 'Passwords do not match.');
        return false;
      }
    }
    clearError($input);
    return true;
  }

  /* ── Validate full form ── */
  function validateForm($form) {
    let valid = true;
    $form.find('.rt-input[data-required]').each(function () {
      if (!validateField($(this))) valid = false;
    });
    return valid;
  }

  /* ── Password strength meter ── */
  function initPasswordStrength(inputId, barId, labelId) {
    $(`#${inputId}`).on('input', function () {
      const pw = $(this).val();
      let score = 0;
      if (pw.length >= 8)           score++;
      if (/[A-Z]/.test(pw))         score++;
      if (/[0-9]/.test(pw))         score++;
      if (/[^A-Za-z0-9]/.test(pw))  score++;

      const map = [
        { label: 'Weak',   color: '#dc2626', w: '25%' },
        { label: 'Fair',   color: '#d97706', w: '50%' },
        { label: 'Good',   color: '#2563eb', w: '75%' },
        { label: 'Strong', color: '#16a34a', w: '100%' },
      ];

      if (!pw.length) { $(`#${barId}`).closest('.rt-pw-strength').hide(); return; }
      $(`#${barId}`).closest('.rt-pw-strength').show();
      const lvl = map[Math.max(0, score - 1)];
      $(`#${barId}`).css({ width: lvl.w, background: lvl.color });
      $(`#${labelId}`).text(lvl.label).css('color', lvl.color);
    });
  }

  /* ── Live validation binding ── */
  function bindLive($form) {
    $form.find('.rt-input[data-required]').on('blur input', function () {
      validateField($(this));
    });
  }

  /* ── Toast helper ── */
  function toast(msg, type = 'success') {
    const $t = $('<div></div>').addClass('rt-toast rt-toast--' + type).text(msg);
    $('body').append($t);
    setTimeout(() => $t.remove(), 3200);
  }

  /* ── Alert helper ── */
  function showAlert(id, msg, type) {
    const icon = type === 'error'
      ? '<i class="fas fa-exclamation-circle me-2"></i>'
      : '<i class="fas fa-check-circle me-2"></i>';
    $(`#${id}`).attr('class', 'rt-alert rt-alert-' + type + ' show').html(icon + msg);
  }

  function hideAlert(id) { $(`#${id}`).removeClass('show').text(''); }

  return { validateField, validateForm, clearAll, setError, clearError, initPasswordStrength, bindLive, toast, showAlert, hideAlert };
})();
