/* ═══════════════════════════════════════════════
   dashboard.js — UI Helpers Only (CI4 Migration)
   T&N Company · RegisTrack Hiring Portal
   Famini & Pacalioga · BSIT-2C

   MIGRATION NOTES:
   ─────────────────────────────────────────────
   ✅ KEPT:   APP_STATUSES, STATUS_META, TERMINAL_STATUSES,
             STATUS_PIPELINE_STEPS  — used for UI badge/pipeline rendering
   ✅ KEPT:   statusBadgeHTML(), scoreBarHTML()  — UI helpers
   ✅ KEPT:   buildFilterBar(), getFilterBarValues(), resetFilterBar()
   ✅ KEPT:   buildViewToggle(), setView()
   ✅ KEPT:   initTopbar(), renderPipelineSteps()

   ❌ REMOVED: JobDB  → replaced by JobController + JobModel (MySQL)
   ❌ REMOVED: AppDB  → replaced by ApplicationController + ApplicationModel
   ❌ REMOVED: EmployeeDB → replaced by EmployeeModel
   ❌ REMOVED: Auth.* references → replaced by AuthController + PHP session
   ❌ REMOVED: All localStorage reads/writes
   ❌ REMOVED: exportApplicationsCSV() → replaced by GET /admin/export/csv endpoint
   ❌ REMOVED: seedDemoJobs() / migrate()

   Data is now fetched from CI4 API endpoints via fetch().
   See each dashboard view for the fetch() calls.
═══════════════════════════════════════════════ */


/* ════════════════════════════════════
   APPLICATION STATUS PIPELINE
   (kept — used for UI rendering)
════════════════════════════════════ */

const APP_STATUSES = [
  'Submitted',
  'Under Review',
  'Phone Screen',
  'Interview Scheduled',
  'Final Interview',
  'Job Offer',
  'Hired',
  'Rejected',
  'Withdrawn',
];

const STATUS_META = {
  'Submitted':           { cls: 'rt-badge-submitted',    color: '#0369a1', icon: 'fa-paper-plane',        label: 'Submitted' },
  'Under Review':        { cls: 'rt-badge-under-review', color: '#2563eb', icon: 'fa-magnifying-glass',   label: 'Under Review' },
  'Phone Screen':        { cls: 'rt-badge-phone',        color: '#7c3aed', icon: 'fa-phone',              label: 'Phone Screen' },
  'Interview Scheduled': { cls: 'rt-badge-interview',    color: '#d97706', icon: 'fa-calendar-check',     label: 'Interview Scheduled' },
  'Final Interview':     { cls: 'rt-badge-final',        color: '#ea580c', icon: 'fa-people-arrows',      label: 'Final Interview' },
  'Job Offer':           { cls: 'rt-badge-offer',        color: '#0891b2', icon: 'fa-envelope-open-text', label: 'Job Offer' },
  'Hired':               { cls: 'rt-badge-hired',        color: '#16a34a', icon: 'fa-user-check',         label: 'Hired' },
  'Rejected':            { cls: 'rt-badge-rejected',     color: '#dc2626', icon: 'fa-circle-xmark',       label: 'Rejected' },
  'Withdrawn':           { cls: 'rt-badge-withdrawn',    color: '#64748b', icon: 'fa-ban',                label: 'Withdrawn' },
  'Offer Accepted':      { cls: 'rt-badge-hired',        color: '#16a34a', icon: 'fa-handshake',          label: 'Offer Accepted' },
  'Declined Offer':      { cls: 'rt-badge-withdrawn',    color: '#64748b', icon: 'fa-ban',                label: 'Declined Offer' },
};

const TERMINAL_STATUSES = ['Hired', 'Rejected', 'Withdrawn', 'Declined Offer'];

/* Ordered pipeline steps for applicant progress display */
const STATUS_PIPELINE_STEPS = [
  { status: 'Submitted',           label: 'Application Received',  icon: 'fa-paper-plane' },
  { status: 'Under Review',        label: 'Document Review',        icon: 'fa-magnifying-glass' },
  { status: 'Phone Screen',        label: 'Phone Screen',           icon: 'fa-phone' },
  { status: 'Interview Scheduled', label: 'Interview Scheduled',    icon: 'fa-calendar-check' },
  { status: 'Final Interview',     label: 'Final Interview',        icon: 'fa-people-arrows' },
  { status: 'Job Offer',           label: 'Job Offer Extended',     icon: 'fa-envelope-open-text' },
  { status: 'Hired',               label: 'Hired',                  icon: 'fa-user-check' },
];


/* ════════════════════════════════════
   SHARED UI HELPERS
   (all kept — pure rendering, no data)
════════════════════════════════════ */

/**
 * Render a coloured status badge pill.
 * @param {string} status
 * @returns {string} HTML string
 */
function statusBadgeHTML(status) {
  const m = STATUS_META[status] || { cls: 'rt-badge-submitted', icon: 'fa-circle', label: status };
  return `<span class="rt-badge ${m.cls}"><i class="fas ${m.icon} me-1"></i>${status}</span>`;
}

/**
 * Render a horizontal score bar with numeric label.
 * @param {number} score  0–100
 * @returns {string} HTML string
 */
function scoreBarHTML(score) {
  const s     = parseInt(score) || 0;
  const color = s >= 80 ? 'var(--green)' : s >= 65 ? 'var(--accent)' : 'var(--yellow)';
  return `<div class="rt-score-wrap">
    <div class="rt-score-bar">
      <div class="rt-score-fill" style="width:${s}%;background:${color};"></div>
    </div>
    <span class="rt-score-num">${s}/100</span>
  </div>`;
}

/**
 * Render the applicant pipeline step progress bar.
 * Shows each step in STATUS_PIPELINE_STEPS, highlighting completed and current.
 * @param {string} currentStatus
 * @returns {string} HTML string
 */
function renderPipelineSteps(currentStatus) {
  const currentIdx = STATUS_PIPELINE_STEPS.findIndex(s => s.status === currentStatus);
  const isTerminal = TERMINAL_STATUSES.includes(currentStatus);

  if (currentStatus === 'Rejected' || currentStatus === 'Withdrawn' || currentStatus === 'Declined Offer') {
    const m = STATUS_META[currentStatus] || { color: '#64748b', icon: 'fa-ban' };
    return `<div style="text-align:center;padding:20px;">
      <div style="width:52px;height:52px;background:#fef2f2;border-radius:12px;display:inline-flex;align-items:center;justify-content:center;margin-bottom:12px;">
        <i class="fas ${m.icon}" style="font-size:1.4rem;color:${m.color};"></i>
      </div>
      <div style="font-weight:700;font-size:.95rem;">${currentStatus}</div>
      <div style="font-size:.82rem;color:var(--mid);margin-top:4px;">This application has been closed.</div>
    </div>`;
  }

  return STATUS_PIPELINE_STEPS.map((step, i) => {
    const isDone    = i < currentIdx;
    const isCurrent = i === currentIdx;
    const m         = STATUS_META[step.status] || { color: '#64748b', icon: 'fa-circle' };
    const dotColor  = isDone ? 'var(--green)' : isCurrent ? m.color : 'var(--border)';
    const textColor = isDone ? 'var(--green)' : isCurrent ? m.color : 'var(--mid)';
    const iconClass = isDone ? 'fa-check' : step.icon;

    return `<div class="rt-pipeline-step ${isDone ? 'done' : ''} ${isCurrent ? 'current' : ''}">
      <div class="rt-pipeline-dot" style="background:${dotColor};border-color:${dotColor};">
        <i class="fas ${iconClass}" style="color:#fff;font-size:.6rem;"></i>
      </div>
      <div class="rt-pipeline-label" style="color:${textColor};">${step.label}</div>
    </div>`;
  }).join('<div class="rt-pipeline-line"></div>');
}


/* ════════════════════════════════════
   FILTER BAR BUILDER
   (kept — pure UI, wires to fetch() now)
════════════════════════════════════ */

/**
 * Build a reusable filter/sort bar HTML string.
 *
 * @param {string} containerId  Unique prefix for all element IDs in this bar
 * @param {object} options
 *   searchPlaceholder {string}
 *   filters  {Array<{ id, placeholder, width, options }>}
 *   sorts    {Array<{ value: 'field|dir', label }>}
 *   onChangeFn {string}  Name of the async function to call on every change
 * @returns {string} HTML string
 */
function buildFilterBar(containerId, { searchPlaceholder = 'Search…', filters = [], sorts = [], onChangeFn }) {
  const call      = onChangeFn + '()';
  const sortOpts  = sorts.map(s => `<option value="${s.value}">${s.label}</option>`).join('');
  const filterHTML = filters.map(f => `
    <select class="rt-input rt-select rt-fb-select" id="${f.id}" style="min-width:${f.width || '140px'};" onchange="${call}">
      <option value="">${f.placeholder}</option>
      ${f.options.map(o => `<option value="${typeof o === 'object' ? o.value : o}">${typeof o === 'object' ? o.label : o}</option>`).join('')}
    </select>`).join('');

  return `<div class="rt-filter-bar-wrap" id="${containerId}_bar">
    <div class="rt-search-bar rt-fb-search" style="flex:1;min-width:200px;max-width:320px;">
      <i class="fas fa-magnifying-glass"></i>
      <input type="text" id="${containerId}_search" placeholder="${searchPlaceholder}" oninput="${call}" />
    </div>
    ${filterHTML}
    ${sorts.length ? `<select class="rt-input rt-select rt-fb-select" id="${containerId}_sort" style="min-width:180px;" onchange="${call}">
      <option value="">Sort by…</option>${sortOpts}
    </select>` : ''}
    <button class="rt-btn rt-btn-outline rt-btn-sm" onclick="resetFilterBar('${containerId}','${onChangeFn}')" title="Reset filters">
      <i class="fas fa-rotate-left"></i>
    </button>
  </div>`;
}

function resetFilterBar(containerId, onChangeFn) {
  const bar = document.getElementById(containerId + '_bar');
  if (!bar) return;
  bar.querySelectorAll('input').forEach(i => i.value = '');
  bar.querySelectorAll('select').forEach(s => s.value = '');
  try { window[onChangeFn](); } catch (e) {}
}

function getFilterBarValues(containerId) {
  const search  = (document.getElementById(containerId + '_search') || {}).value || '';
  const sortEl  = document.getElementById(containerId + '_sort');
  const sortVal = sortEl ? sortEl.value : '';
  const [sortBy, sortDir] = sortVal ? sortVal.split('|') : ['', ''];
  const filters = {};
  const bar = document.getElementById(containerId + '_bar');
  if (bar) bar.querySelectorAll('.rt-fb-select').forEach(s => {
    if (s.id && s.id !== containerId + '_sort') filters[s.id] = s.value;
  });
  return { search, sortBy: sortBy || null, sortDir: sortDir || 'desc', filters };
}


/* ════════════════════════════════════
   VIEW TOGGLE (cards ↔ list)
════════════════════════════════════ */

function buildViewToggle(containerId, onChangeFn) {
  return `<div class="rt-view-toggle" id="${containerId}_vtoggle">
    <button class="rt-vt-btn active" data-view="cards" onclick="setView('${containerId}','cards','${onChangeFn}',this)" title="Card view">
      <i class="fas fa-grip"></i>
    </button>
    <button class="rt-vt-btn" data-view="list" onclick="setView('${containerId}','list','${onChangeFn}',this)" title="List view">
      <i class="fas fa-list"></i>
    </button>
  </div>`;
}

function setView(containerId, view, onChangeFn, btn) {
  document.querySelectorAll(`#${containerId}_vtoggle .rt-vt-btn`).forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  document.getElementById(containerId + '_viewmode').value = view;
  try { window[onChangeFn](); } catch (e) {}
}


/* ════════════════════════════════════
   TOP NAV BAR
   Updated: logout now hits CI4 /logout
   route instead of Auth.logout()
════════════════════════════════════ */

/**
 * Render the top navigation bar.
 * USER is injected from PHP: const USER = <?= json_encode($user) ?>;
 *
 * @param {object} user   { id, role, first, last, email }
 * @param {string} variant  Optional: 'admin' adds a dark variant class
 * @returns {string} HTML string
 */
function initTopbar(user, variant = '') {
  const varClass  = variant ? ` rt-topbar--${variant}` : '';
  const nameClass = variant ? 'rt-topbar-name--light' : '';
  const btnClass  = variant ? 'rt-btn-light' : 'rt-btn-outline rt-btn-sm';
  const roleLabel = { admin: 'Administrator', hr: 'HR Staff', applicant: 'Applicant' }[user.role] || user.role;

  // Logout hits CI4 AuthController::logout() — no more Auth.logout()
  return `<nav class="rt-topbar${varClass}">
    <div class="container d-flex align-items-center justify-content-between">
      <div class="d-flex align-items-center gap-2">
        <div class="rt-brand"><span class="rt-brand-accent">T&amp;N</span> Careers</div>
        <span class="rt-topbar-divider"></span>
        <span class="rt-topbar-system">Hiring Portal</span>
      </div>
      <div class="d-flex align-items-center gap-3">
        <span class="rt-topbar-name ${nameClass}">${user.first} ${user.last} · ${roleLabel}</span>
        <a href="${BASE_URL}logout" class="rt-btn ${btnClass}">
          <i class="fas fa-right-from-bracket me-1"></i>Logout
        </a>
      </div>
    </div>
  </nav>`;
}
