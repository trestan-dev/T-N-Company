<?php
// app/Controllers/HomeController.php
namespace App\Controllers;

class HomeController extends BaseController
{
    public function index()
    {
        // If logged in, redirect to their dashboard
        $user = session()->get('user');
        if ($user) {
            $map = [
                'admin'     => '/admin/dashboard',
                'hr'        => '/hr/dashboard',
                'applicant' => '/applicant/dashboard',
            ];
            return redirect()->to($map[$user['role']] ?? '/login');
        }
        return view('home');
    }
}
