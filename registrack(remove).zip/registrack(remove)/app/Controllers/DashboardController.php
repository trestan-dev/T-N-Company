<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;

class DashboardController extends BaseController
{
    public function applicant()
    {
        $user = session()->get('user');
        return view('applicant/dashboard', ['user' => $user]);
    }

    public function hr()
    {
        $user = session()->get('user');
        return view('hr/dashboard', ['user' => $user]);
    }

    public function admin()
    {
        $user = session()->get('user');
        return view('admin/dashboard', ['user' => $user]);
    }
}
