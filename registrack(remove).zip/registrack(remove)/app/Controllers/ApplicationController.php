<?php
// app/Controllers/ApplicationController.php
namespace App\Controllers;

use App\Models\ApplicationModel;
use App\Models\JobModel;
use App\Models\StatusHistoryModel;
use App\Models\AuditModel;
use App\Models\EmployeeModel;

class ApplicationController extends BaseController
{
    // ── Submit application (POST /applicant/apply/{jobId}) ─
    public function apply(int $jobId)
    {
        $user = session()->get('user');
        $appM = new ApplicationModel();
        $jobM = new JobModel();

        $job = $jobM->find($jobId);
        if (!$job || !$job['is_active']) {
            return redirect()->back()->with('error', 'Job not found or no longer active.');
        }
        if ($appM->hasApplied($user['id'], $jobId)) {
            return redirect()->back()->with('error', 'You have already applied for this position.');
        }
        if ($appM->hasActiveApplication($user['id'])) {
            return redirect()->back()->with('error', 'You already have an active application in progress.');
        }

        // ── Resume upload ──────────────────────────────────
        $resume     = $this->request->getFile('resume');
        $resumeName = $resumePath = '';

        if ($resume && $resume->isValid() && !$resume->hasMoved()) {
            if (strtolower($resume->getExtension()) !== 'pdf') {
                return redirect()->back()->with('error', 'Only PDF resumes are accepted.');
            }
            if ($resume->getSizeByUnit('mb') > 5) {
                return redirect()->back()->with('error', 'Resume must be under 5 MB.');
            }
            $newName    = $resume->getRandomName();
            $resume->move(WRITEPATH . 'uploads/resumes', $newName);
            $resumeName = $resume->getClientName();
            $resumePath = 'resumes/' . $newName;
        }

        $code = $appM->generateCode();
        $id   = $appM->insert([
            'app_code'        => $code,
            'applicant_id'    => $user['id'],
            'job_id'          => $jobId,
            'position'        => $job['title'],
            'department'      => $job['department'],
            'employment_type' => $job['employment_type'],
            'arrangement'     => $job['arrangement'],
            'cover_letter'    => $this->request->getPost('cover_letter') ?? '',
            'resume_name'     => $resumeName,
            'resume_path'     => $resumePath,
            'resume_score'    => rand(60, 90),
            'status'          => 'Submitted',
            'submitted_at'    => date('Y-m-d'),
        ]);

        (new StatusHistoryModel())->insert([
            'application_id' => $id,
            'status'         => 'Submitted',
            'notes'          => 'Application received.',
            'changed_by'     => $user['id'],
        ]);

        (new AuditModel())->log(
            $user['id'],
            $user['first'] . ' ' . $user['last'],
            'applicant',
            'APP_SUBMITTED',
            "Application {$code} submitted.",
            $this->request->getIPAddress()
        );

        return redirect()->to('/applicant/applications')->with('success', "Application {$code} submitted successfully!");
    }

    // ── My applications (applicant view) ─────────────────
    public function myApplications()
    {
        $user = session()->get('user');
        $apps = (new ApplicationModel())->getFiltered(['applicant_id' => $user['id']]);
        return view('applicant/dashboard', ['user' => $user, 'applications' => $apps]);
    }

    // ── Application detail ───────────────────────────────
    public function detail(int $id)
    {
        $user = session()->get('user');
        $appM = new ApplicationModel();
        $app  = $appM->find($id);

        // Applicants can only see their own
        if (!$app || ($user['role'] === 'applicant' && $app['applicant_id'] != $user['id'])) {
            return redirect()->back()->with('error', 'Application not found.');
        }

        $history = (new StatusHistoryModel())->where('application_id', $id)->orderBy('changed_at', 'ASC')->findAll();
        return view('applicant/application_detail', ['user' => $user, 'app' => $app, 'history' => $history]);
    }

    // ── Respond to offer ─────────────────────────────────
    public function respondToOffer()
    {
        $user     = session()->get('user');
        $response = $this->request->getPost('response'); // 'accept' or 'decline'

        // Find application ID from users active Job Offer
        $appM = new ApplicationModel();
        $app  = $appM->where('applicant_id', $user['id'])->where('status', 'Job Offer')->first();

        if (!$app || $app['status'] !== 'Job Offer') {
            return $this->response->setJSON(['ok' => false, 'msg' => 'Invalid offer.']);
        }

        // ✅ FIX: Set to Offer Accepted, NOT directly to Hired (HR will do final step)
        $newStatus = ($response === 'accept') ? 'Offer Accepted' : 'Declined Offer';
        $appM->update($app['id'], ['status' => $newStatus]);

        (new StatusHistoryModel())->insert([
            'application_id' => $app['id'],
            'status'         => $newStatus,
            'notes'          => $response === 'accept' ? 'Applicant accepted the offer.' : 'Applicant declined the offer.',
            'changed_by'     => $user['id'],
        ]);

        (new AuditModel())->log(
            $user['id'],
            $user['first'] . ' ' . $user['last'],
            'applicant',
            'OFFER_RESPONSE',
            "Offer for {$app['app_code']} — {$newStatus}.",
            $this->request->getIPAddress()
        );

        // ✅ FIX: Return JSON response for javascript fetch() call
        return $this->response->setJSON(['ok' => true]);
    }

    // ── Update status — called by HR and Admin ───────────
    public function updateStatus(int $appId)
    {
        $user   = session()->get('user');
        $appM   = new ApplicationModel();
        $app    = $appM->find($appId);

        if (!$app) {
            return $this->response->setJSON(['ok' => false, 'msg' => 'Application not found.']);
        }

        $status = $this->request->getPost('status');
        $notes  = $this->request->getPost('notes') ?? '';

        $appM->update($appId, [
            'status'         => $status,
            'reviewer_notes' => $notes,
            'reviewed_by'    => $user['id'],
            'interview_date' => $this->request->getPost('interview_date') ?: null,
            'offer_date'     => $this->request->getPost('offer_date') ?: null,
        ]);

        (new StatusHistoryModel())->insert([
            'application_id' => $appId,
            'status'         => $status,
            'notes'          => $notes,
            'changed_by'     => $user['id'],
        ]);

        // Auto-create employee record when status reaches 'Hired'
        if ($status === 'Hired') {
            (new EmployeeModel())->addFromApplication($app, $user);
        }

        (new AuditModel())->log(
            $user['id'],
            $user['first'] . ' ' . $user['last'],
            $user['role'],
            'STATUS_UPDATED',
            "App {$app['app_code']} → \"{$status}\".",
            $this->request->getIPAddress()
        );

        return $this->response->setJSON(['ok' => true]);
    }

    // ── Serve resume PDF securely (not from public/) ─────
    public function serveResume(string $appCode)
    {
        $user = session()->get('user');
        $appM = new ApplicationModel();
        $app  = $appM->where('app_code', $appCode)->first();

        if (!$app) return $this->response->setStatusCode(404);

        // Applicants can only download their own resume
        if ($user['role'] === 'applicant' && $app['applicant_id'] !== $user['id']) {
            return $this->response->setStatusCode(403);
        }

        $path = WRITEPATH . 'uploads/' . $app['resume_path'];
        if (!file_exists($path)) return $this->response->setStatusCode(404);

        return $this->response
            ->setHeader('Content-Type', 'application/pdf')
            ->setHeader('Content-Disposition', 'inline; filename="' . $app['resume_name'] . '"')
            ->setBody(file_get_contents($path));
    }

    // ── API: stats JSON (for dashboard charts) ───────────
    public function apiStats()
    {
        $user  = session()->get('user');
        $appM  = new ApplicationModel();
        $stats = $appM->getStats($user['role'] === 'applicant' ? $user['id'] : null);
        return $this->response->setJSON($stats);
    }

    // ── API: filtered applications JSON ──────────────────
    public function apiList()
    {
        $user   = session()->get('user');
        $appM   = new ApplicationModel();
        $params = $this->request->getGet();

        // Applicants can only see their own applications
        if ($user['role'] === 'applicant') {
            $params['applicant_id'] = $user['id'];
        }

        $apps = $appM->getFiltered($params);
        return $this->response->setJSON($apps);
    }
}
