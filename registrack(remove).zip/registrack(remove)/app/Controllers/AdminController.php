<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;

use App\Models\UserModel;
use App\Models\JobModel;
use App\Models\ApplicationModel;
use App\Models\EmployeeModel;
use App\Models\AuditModel;
use App\Models\StatusHistoryModel;

class AdminController extends BaseController
{
    // ── Admin Dashboard ──────────────────────────────────
    public function dashboard()
    {
        $user = session()->get('user');
        return view('admin/dashboard', ['user' => $user]);
    }

    // ── Applications list (JSON) ─────────────────────────
    public function applications()
    {
        $apps = (new ApplicationModel())->getFiltered($this->request->getGet());
        return $this->response->setJSON($apps);
    }

    public function updateStatus(int $appId)
    {
        // Delegate to ApplicationController
        return (new ApplicationController())->updateStatus($appId);
    }

    // ── Job management ───────────────────────────────────
    public function jobs()
    {
        $jobs = (new JobModel())->orderBy('created_at', 'DESC')->findAll();
        return $this->response->setJSON($jobs);
    }

    public function createJob()
    {
        $user  = session()->get('user');
        $jobM  = new JobModel();

        $imagePath = $this->_handleJobImage();

        $last    = $jobM->orderBy('id', 'DESC')->first();
        $nextNum = $last ? ($last['id'] + 1) : 1;
        $code    = 'JOB-' . str_pad($nextNum, 3, '0', STR_PAD_LEFT);

        $jobM->insert([
            'job_code'        => $code,
            'title'           => $this->request->getPost('title'),
            'department'      => $this->request->getPost('department'),
            'employment_type' => $this->request->getPost('employment_type'),
            'arrangement'     => $this->request->getPost('arrangement'),
            'description'     => $this->request->getPost('description') ?? '',
            'requirements'    => $this->request->getPost('requirements') ?? '',
            'salary_range'    => $this->request->getPost('salary_range') ?? '',
            'image_path'      => $imagePath,
            'is_active'       => 1,
            'posted_by'       => $user['id'],
        ]);

        (new AuditModel())->log(
            $user['id'], $user['first'] . ' ' . $user['last'], 'admin',
            'JOB_CREATED', "Job {$code} posted.", $this->request->getIPAddress()
        );

        return $this->response->setJSON(['ok' => true, 'code' => $code]);
    }

    public function updateJob(int $id)
    {
        $user = session()->get('user');
        $jobM = new JobModel();

        $data = [
            'title'           => $this->request->getPost('title'),
            'department'      => $this->request->getPost('department'),
            'employment_type' => $this->request->getPost('employment_type'),
            'arrangement'     => $this->request->getPost('arrangement'),
            'description'     => $this->request->getPost('description') ?? '',
            'requirements'    => $this->request->getPost('requirements') ?? '',
            'salary_range'    => $this->request->getPost('salary_range') ?? '',
        ];

        $imagePath = $this->_handleJobImage();
        if ($imagePath) {
            $data['image_path'] = $imagePath;
        }

        $jobM->update($id, $data);

        (new AuditModel())->log(
            $user['id'], $user['first'] . ' ' . $user['last'], 'admin',
            'JOB_UPDATED', "Job ID {$id} updated.", $this->request->getIPAddress()
        );

        return $this->response->setJSON(['ok' => true]);
    }

    public function toggleJob(int $id)
    {
        $user = session()->get('user');
        $jobM = new JobModel();
        $job  = $jobM->find($id);
        if (!$job) {
            return $this->response->setJSON(['ok' => false, 'msg' => 'Job not found.']);
        }

        $newState = $job['is_active'] ? 0 : 1;
        $jobM->update($id, ['is_active' => $newState]);

        (new AuditModel())->log(
            $user['id'], $user['first'] . ' ' . $user['last'], 'admin',
            'JOB_TOGGLED', "Job ID {$id} " . ($newState ? 'activated' : 'deactivated') . ".",
            $this->request->getIPAddress()
        );

        return $this->response->setJSON(['ok' => true, 'is_active' => $newState]);
    }

    public function deleteJob(int $id)
    {
        $user = session()->get('user');
        $jobM = new JobModel();
        $job  = $jobM->find($id);
        if ($job) {
            $jobM->delete($id);
            (new AuditModel())->log(
                $user['id'], $user['first'] . ' ' . $user['last'], 'admin',
                'JOB_DELETED', "Job ID {$id} deleted.", $this->request->getIPAddress()
            );
        }
        return $this->response->setJSON(['ok' => true]);
    }

    // ── Audit log pages ──────────────────────────────────
    public function audit()
    {
        $user = session()->get('user');
        return view('admin/dashboard', ['user' => $user]);
    }

    // FIX: apiAudit now supports search (by user_name, action, description, role)
    // and full sort (field + direction). Previously it always returned everything
    // newest-first with no filtering, making the audit log hard to use at scale.
    public function apiAudit()
    {
        $params  = $this->request->getGet();
        $builder = $this->db->table('audit_log');

        // Search
        if (!empty($params['search'])) {
            $s = $params['search'];
            $builder->groupStart()
                ->like('user_name', $s)
                ->orLike('action', $s)
                ->orLike('description', $s)
                ->orLike('role', $s)
                ->orLike('ip_address', $s)
            ->groupEnd();
        }

        // Filter by role
        if (!empty($params['role'])) {
            $builder->where('role', $params['role']);
        }

        // Filter by action type
        if (!empty($params['action'])) {
            $builder->where('action', $params['action']);
        }

        // Sort
        $allowedSorts = ['created_at', 'user_name', 'action', 'role'];
        $sort = in_array($params['sort'] ?? '', $allowedSorts) ? $params['sort'] : 'created_at';
        $dir  = strtolower($params['dir'] ?? 'desc') === 'asc' ? 'ASC' : 'DESC';
        $builder->orderBy($sort, $dir);

        $log = $builder->get()->getResultArray();
        return $this->response->setJSON($log);
    }

    // ── HR Staff management ──────────────────────────────
    public function hrStaff()
    {
        $user = session()->get('user');
        return view('admin/dashboard', ['user' => $user]);
    }

    public function apiStaff()
    {
        $staff = (new UserModel())->where('role', 'hr')->findAll();
        foreach ($staff as &$s) unset($s['password']);
        return $this->response->setJSON($staff);
    }

    public function createHR()
    {
        $user      = session()->get('user');
        $userModel = new UserModel();
        $email     = $this->request->getPost('email');

        if ($userModel->where('email', $email)->countAllResults() > 0) {
            return $this->response->setJSON(['ok' => false, 'msg' => 'Email already in use.']);
        }

        $first = $this->request->getPost('first');
        $last  = $this->request->getPost('last');

        $userModel->insert([
            'first_name' => $first,
            'last_name'  => $last,
            'email'      => $email,
            'password'   => password_hash($this->request->getPost('password'), PASSWORD_BCRYPT),
            'role'       => 'hr',
        ]);

        (new AuditModel())->log(
            $user['id'], $user['first'] . ' ' . $user['last'], 'admin',
            'HR_CREATED', "HR account created for: {$email}.",
            $this->request->getIPAddress()
        );

        return $this->response->setJSON(['ok' => true]);
    }

    public function deactivateHR(int $id)
    {
        $this->_deactivateUser($id, 'HR_DEACTIVATED');
        return $this->response->setJSON(['ok' => true]);
    }

    public function reactivateHR(int $id)
    {
        $this->_reactivateUser($id, 'HR_REACTIVATED');
        return $this->response->setJSON(['ok' => true]);
    }

    // ── Applicant management ─────────────────────────────
    public function applicants()
    {
        $user = session()->get('user');
        return view('admin/dashboard', ['user' => $user]);
    }

    public function apiApplicants()
    {
        $users = (new UserModel())->where('role', 'applicant')->findAll();
        foreach ($users as &$u) unset($u['password']);
        return $this->response->setJSON($users);
    }

    public function deactivateUser(int $id)
    {
        $this->_deactivateUser($id, 'USER_DEACTIVATED');
        return $this->response->setJSON(['ok' => true]);
    }

    public function reactivateUser(int $id)
    {
        $this->_reactivateUser($id, 'USER_REACTIVATED');
        return $this->response->setJSON(['ok' => true]);
    }

    // ── Employees ────────────────────────────────────────
    public function employees()
    {
        $user = session()->get('user');
        return view('admin/dashboard', ['user' => $user]);
    }

    public function apiEmployees()
    {
        $emps = (new EmployeeModel())->getWithNames();
        return $this->response->setJSON($emps);
    }

    public function deactivateEmployee(int $id)
    {
        $user = session()->get('user');
        (new EmployeeModel())->update($id, ['is_active' => 0]);
        (new AuditModel())->log(
            $user['id'], $user['first'] . ' ' . $user['last'], 'admin',
            'EMPLOYEE_DEACTIVATED', "Employee ID {$id} deactivated.",
            $this->request->getIPAddress()
        );
        return $this->response->setJSON(['ok' => true]);
    }

    public function reactivateEmployee(int $id)
    {
        $user = session()->get('user');
        (new EmployeeModel())->update($id, ['is_active' => 1]);
        (new AuditModel())->log(
            $user['id'], $user['first'] . ' ' . $user['last'], 'admin',
            'EMPLOYEE_REACTIVATED', "Employee ID {$id} reactivated.",
            $this->request->getIPAddress()
        );
        return $this->response->setJSON(['ok' => true]);
    }

    // ── Dashboard chart data ─────────────────────────────
    // FIX: The admin dashboard was trying to render two charts
    // (applications by department, application volume over time) but had no
    // API endpoints to feed them. These two new methods provide that data.

    /**
     * GET api/charts/by-department
     * Returns application count grouped by department for the pie/bar chart.
     */
    public function apiChartByDept()
    {
        $rows = $this->db->table('applications')
            ->select('department, COUNT(*) AS total')
            ->groupBy('department')
            ->orderBy('total', 'DESC')
            ->get()->getResultArray();

        return $this->response->setJSON($rows);
    }

    /**
     * GET api/charts/volume
     * Returns daily application counts for the last 30 days for the line chart.
     */
    public function apiChartVolume()
    {
        $rows = $this->db->table('applications')
            ->select('DATE(submitted_at) AS date, COUNT(*) AS total')
            ->where('submitted_at >=', date('Y-m-d', strtotime('-30 days')))
            ->groupBy('DATE(submitted_at)')
            ->orderBy('date', 'ASC')
            ->get()->getResultArray();

        return $this->response->setJSON($rows);
    }

    // ── CSV export ───────────────────────────────────────
    public function exportCSV()
    {
        $apps = (new ApplicationModel())->getFiltered([]);

        $headers = ['App Code','Applicant','Email','Position','Department','Type','Arrangement','Status','Score','Submitted'];
        $rows    = [];
        foreach ($apps as $a) {
            $rows[] = [
                $a['app_code'],
                ($a['first_name'] ?? '') . ' ' . ($a['last_name'] ?? ''),
                $a['email'] ?? '',
                $a['position'],
                $a['department'],
                $a['employment_type'],
                $a['arrangement'],
                $a['status'],
                $a['resume_score'] ?? '',
                $a['submitted_at'],
            ];
        }

        $csv = implode(',', $headers) . "\n";
        foreach ($rows as $row) {
            $csv .= implode(',', array_map(fn($v) => '"' . str_replace('"', '""', $v) . '"', $row)) . "\n";
        }

        return $this->response
            ->setHeader('Content-Type', 'text/csv')
            ->setHeader('Content-Disposition', 'attachment; filename="applications_' . date('Ymd') . '.csv"')
            ->setBody($csv);
    }

    // ── Private helpers ──────────────────────────────────
    private function _handleJobImage(): string
    {
        $img = $this->request->getFile('image');
        if ($img && $img->isValid() && !$img->hasMoved()) {
            $allowed = ['jpg','jpeg','png','webp','gif'];
            if (!in_array(strtolower($img->getExtension()), $allowed)) {
                return '';
            }
            if ($img->getSizeByUnit('mb') > 3) {
                return '';
            }
            $newName = $img->getRandomName();
            $img->move(WRITEPATH . 'uploads/job-images', $newName);
            return 'job-images/' . $newName;
        }
        return '';
    }

    private function _deactivateUser(int $id, string $action): void
    {
        $user = session()->get('user');
        (new UserModel())->update($id, ['is_active' => 0]);
        (new AuditModel())->log(
            $user['id'], $user['first'] . ' ' . $user['last'], 'admin',
            $action, "User ID {$id} deactivated.", $this->request->getIPAddress()
        );
    }

    private function _reactivateUser(int $id, string $action): void
    {
        $user = session()->get('user');
        (new UserModel())->update($id, ['is_active' => 1]);
        (new AuditModel())->log(
            $user['id'], $user['first'] . ' ' . $user['last'], 'admin',
            $action, "User ID {$id} reactivated.", $this->request->getIPAddress()
        );
    }
}