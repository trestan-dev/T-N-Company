<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;

use App\Models\JobModel;
use App\Models\ApplicationModel;
use App\Models\StatusHistoryModel;
use App\Models\EmployeeModel;
use App\Models\AuditModel;

class HRController extends BaseController
{
    // ── HR Dashboard ─────────────────────────────────────
    public function dashboard()
    {
        $user = session()->get('user');
        return view('hr/dashboard', ['user' => $user]);
    }

    // ── All applications (HR view) ───────────────────────
    public function applications()
    {
        $user = session()->get('user');
        $apps = (new ApplicationModel())->getFiltered($this->request->getGet());
        return $this->response->setJSON($apps);
    }

    // ── Update application status ────────────────────────
    public function updateStatus(int $appId)
    {
        $user   = session()->get('user');
        $appM   = new ApplicationModel();
        $app    = $appM->find($appId);

        if (!$app) {
            return $this->response->setJSON(['ok' => false, 'msg' => 'Application not found.']);
        }

        $status = $this->request->getPost('status');
        $notes  = $this->request->getPost('notes') ?? '';

        $appM->update($appId, [
            'status'         => $status,
            'reviewer_notes' => $notes,
            'reviewed_by'    => $user['id'],
            'interview_date' => $this->request->getPost('interview_date') ?: null,
            'offer_date'     => $this->request->getPost('offer_date') ?: null,
        ]);

        (new StatusHistoryModel())->insert([
            'application_id' => $appId,
            'status'         => $status,
            'notes'          => $notes,
            'changed_by'     => $user['id'],
        ]);

        if ($status === 'Hired') {
            (new EmployeeModel())->addFromApplication($app, $user);
        }

        (new AuditModel())->log(
            $user['id'],
            $user['first'] . ' ' . $user['last'],
            'hr',
            'STATUS_UPDATED',
            "App {$app['app_code']} → \"{$status}\".",
            $this->request->getIPAddress()
        );

        return $this->response->setJSON(['ok' => true]);
    }

    // ── Job management ───────────────────────────────────
    public function jobs()
    {
        $user = session()->get('user');
        $jobs = (new JobModel())->orderBy('created_at', 'DESC')->findAll();
        return $this->response->setJSON($jobs);
    }

    public function createJob()
    {
        $user  = session()->get('user');
        $jobM  = new JobModel();

        $imagePath = $this->_handleJobImage();

        $last    = $jobM->orderBy('id', 'DESC')->first();
        $nextNum = $last ? ($last['id'] + 1) : 1;
        $code    = 'JOB-' . str_pad($nextNum, 3, '0', STR_PAD_LEFT);

        $jobM->insert([
            'job_code'        => $code,
            'title'           => $this->request->getPost('title'),
            'department'      => $this->request->getPost('department'),
            'employment_type' => $this->request->getPost('employment_type'),
            'arrangement'     => $this->request->getPost('arrangement'),
            'description'     => $this->request->getPost('description') ?? '',
            'requirements'    => $this->request->getPost('requirements') ?? '',
            'salary_range'    => $this->request->getPost('salary_range') ?? '',
            'image_path'      => $imagePath,
            'is_active'       => 1,
            'posted_by'       => $user['id'],
        ]);

        (new AuditModel())->log(
            $user['id'], $user['first'] . ' ' . $user['last'], 'hr',
            'JOB_CREATED', "Job {$code} posted.", $this->request->getIPAddress()
        );

        return $this->response->setJSON(['ok' => true, 'code' => $code]);
    }

    public function updateJob(int $id)
    {
        $user = session()->get('user');
        $jobM = new JobModel();

        $data = [
            'title'           => $this->request->getPost('title'),
            'department'      => $this->request->getPost('department'),
            'employment_type' => $this->request->getPost('employment_type'),
            'arrangement'     => $this->request->getPost('arrangement'),
            'description'     => $this->request->getPost('description') ?? '',
            'requirements'    => $this->request->getPost('requirements') ?? '',
            'salary_range'    => $this->request->getPost('salary_range') ?? '',
        ];

        $imagePath = $this->_handleJobImage();
        if ($imagePath) $data['image_path'] = $imagePath;

        $jobM->update($id, $data);

        (new AuditModel())->log(
            $user['id'], $user['first'] . ' ' . $user['last'], 'hr',
            'JOB_UPDATED', "Job ID {$id} updated.", $this->request->getIPAddress()
        );

        return $this->response->setJSON(['ok' => true]);
    }

    public function toggleJob(int $id)
    {
        $user = session()->get('user');
        $jobM = new JobModel();
        $job  = $jobM->find($id);
        if (!$job) return $this->response->setJSON(['ok' => false]);

        $newState = $job['is_active'] ? 0 : 1;
        $jobM->update($id, ['is_active' => $newState]);

        (new AuditModel())->log(
            $user['id'], $user['first'] . ' ' . $user['last'], 'hr',
            'JOB_TOGGLED', "Job ID {$id} " . ($newState ? 'activated' : 'deactivated') . ".",
            $this->request->getIPAddress()
        );

        return $this->response->setJSON(['ok' => true, 'is_active' => $newState]);
    }

    public function deleteJob(int $id)
    {
        $user = session()->get('user');
        (new JobModel())->delete($id);

        (new AuditModel())->log(
            $user['id'], $user['first'] . ' ' . $user['last'], 'hr',
            'JOB_DELETED', "Job ID {$id} deleted.", $this->request->getIPAddress()
        );

        return $this->response->setJSON(['ok' => true]);
    }

    // ── Private: handle job image upload ─────────────────
    private function _handleJobImage(): string
    {
        $img = $this->request->getFile('image');
        if ($img && $img->isValid() && !$img->hasMoved()) {
            $allowed = ['jpg','jpeg','png','webp','gif'];
            if (!in_array(strtolower($img->getExtension()), $allowed)) return '';
            if ($img->getSizeByUnit('mb') > 3) return '';
            $newName = $img->getRandomName();
            $img->move(WRITEPATH . 'uploads/job-images', $newName);
            return 'job-images/' . $newName;
        }
        return '';
    }
}