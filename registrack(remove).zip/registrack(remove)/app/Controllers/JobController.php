<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;

use App\Models\JobModel;
use App\Models\AuditModel;

class JobController extends BaseController
{
    // ── List active jobs for applicants ──────────────────
    public function listActive()
    {
        $user = session()->get('user');
        $jobs = (new JobModel())->where('is_active', 1)->orderBy('created_at', 'DESC')->findAll();
        return view('applicant/dashboard', ['user' => $user, 'jobs' => $jobs]);
    }

    // ── Job detail page ──────────────────────────────────
    public function detail(int $id)
    {
        $user = session()->get('user');
        $job  = (new JobModel())->find($id);
        if (!$job || !$job['is_active']) {
            return redirect()->to('/applicant/jobs')->with('error', 'Job not found or no longer active.');
        }
        return view('applicant/job_detail', ['user' => $user, 'job' => $job]);
    }

    // ── Serve job image securely from writable/uploads ───
    // FIX: The job image_url was pointing to 'api/job-image/...' but no such route
    // existed, causing broken images everywhere. This method serves the file from
    // WRITEPATH and is registered at GET api/job-image/(:any) in Routes.php.
    public function serveJobImage(string $path)
    {
        // Sanitise path — strip any directory traversal attempts
        $path     = ltrim(str_replace('..', '', $path), '/');
        $fullPath = WRITEPATH . 'uploads/' . $path;

        if (!file_exists($fullPath)) {
            return $this->response->setStatusCode(404);
        }

        $ext  = strtolower(pathinfo($fullPath, PATHINFO_EXTENSION));
        $mime = [
            'jpg'  => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'png'  => 'image/png',
            'webp' => 'image/webp',
            'gif'  => 'image/gif',
        ][$ext] ?? 'application/octet-stream';

        return $this->response
            ->setHeader('Content-Type', $mime)
            ->setHeader('Cache-Control', 'public, max-age=86400')
            ->setBody(file_get_contents($fullPath));
    }

    // ── API: Return jobs as JSON (used by dashboard.js fetch()) ──
    public function apiList()
    {
        $user   = session()->get('user');
        $jobM   = new JobModel();
        $params = $this->request->getGet();

        // Admins and HR see all; applicants see only active
        if ($user['role'] === 'applicant') {
            $jobM->where('is_active', 1);
        }

        $search = $params['search'] ?? '';
        $dept   = $params['dept']   ?? '';
        $type   = $params['type']   ?? '';
        $arr    = $params['arrangement'] ?? '';
        $active = $params['active'] ?? ''; // ✅ FIX: Accept active status filter from frontend

        // FIX: Expanded allowed sort fields and mapped frontend sort keys correctly.
        // 'sortBy' from the filter bar is field name, 'sortDir' is 'asc'/'desc'.
        $allowedSorts = ['title', 'department', 'created_at', 'applicant_count'];
        $sortRaw = $params['sortBy'] ?? $params['sort'] ?? 'created_at';
        if ($sortRaw === 'posted_at') $sortRaw = 'created_at'; // legacy alias
        $sort = in_array($sortRaw, $allowedSorts) ? $sortRaw : 'created_at';
        $dir  = strtolower($params['sortDir'] ?? $params['dir'] ?? 'desc') === 'asc' ? 'ASC' : 'DESC';

        if ($search) {
            $jobM->groupStart()
                ->like('title', $search)
                ->orLike('department', $search)
                ->orLike('job_code', $search)
                ->groupEnd();
        }
        if ($dept) $jobM->where('department', $dept);
        if ($type) $jobM->where('employment_type', $type);
        if ($arr)  $jobM->where('arrangement', $arr);
        if ($active !== '') $jobM->where('is_active', $active); // ✅ FIX: Filter by active status

        // applicant_count needs a subquery — use raw orderBy only for that case
        if ($sort === 'applicant_count') {
            $jobs = $jobM->select('*, (SELECT COUNT(*) FROM applications a WHERE a.job_id = jobs.id) AS applicant_count')
                         ->orderBy('applicant_count', $dir)
                         ->findAll();
        } else {
            $jobs = $jobM->orderBy($sort, $dir)->findAll();
        }

        // FIX: image_url now correctly points to the served-image route.
        foreach ($jobs as &$job) {
            $job['image_url'] = $job['image_path']
                ? base_url('api/job-image/' . $job['image_path'])
                : null;
        }

        return $this->response->setJSON($jobs);
    }
}