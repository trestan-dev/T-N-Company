<?php
// app/Controllers/AuthController.php
// Replaces auth.js — login/register/logout now run on the server.
namespace App\Controllers;

use App\Models\UserModel;
use App\Models\AuditModel;

class AuthController extends BaseController
{
    // ── Show login page ──────────────────────────────────
    public function loginPage()
    {
        if (session()->get('user')) return $this->redirectByRole();
        return view('auth/login');
    }

    // ── Handle POST /login ───────────────────────────────
    public function login()
    {
        $email    = $this->request->getPost('email');
        $password = $this->request->getPost('password');

        $userModel = new UserModel();
        $user = $userModel->where('email', $email)->first();

        // password_verify() checks against the stored bcrypt hash
        if (!$user || !password_verify($password, $user['password'])) {
            return redirect()->back()->with('error', 'Invalid email or password.');
        }
        if (!$user['is_active']) {
            return redirect()->back()->with('error', 'Account deactivated. Contact the administrator.');
        }

        // Store only safe, minimal data in server-side session — never the password
        session()->set('user', [
            'id'    => $user['id'],
            'role'  => $user['role'],
            'first' => $user['first_name'],
            'last'  => $user['last_name'],
            'email' => $user['email'],
        ]);

        (new AuditModel())->log(
            $user['id'],
            $user['first_name'] . ' ' . $user['last_name'],
            $user['role'],
            'LOGIN',
            'User logged in.',
            $this->request->getIPAddress()
        );

        return $this->redirectByRole();
    }

    // ── Show signup page ─────────────────────────────────
    public function signupPage()
    {
        if (session()->get('user')) return $this->redirectByRole();
        return view('auth/signup');
    }

    // ── Handle POST /signup ──────────────────────────────
    public function register()
    {
        $userModel = new UserModel();
        $email     = $this->request->getPost('email');

        if ($userModel->where('email', $email)->countAllResults() > 0) {
            return redirect()->back()->with('error', 'This email is already registered.');
        }

        $first = $this->request->getPost('first');
        $last  = $this->request->getPost('last');

        $id = $userModel->insert([
            'first_name' => $first,
            'last_name'  => $last,
            'email'      => $email,
            'password'   => password_hash($this->request->getPost('password'), PASSWORD_BCRYPT),
            'phone'      => $this->request->getPost('phone') ?? '',
            'role'       => 'applicant',
        ]);

        (new AuditModel())->log(
            $id,
            $first . ' ' . $last,
            'applicant',
            'REGISTER',
            'New applicant account created.',
            $this->request->getIPAddress()
        );

        return redirect()->to('/login')->with('success', 'Account created! Please sign in.');
    }

    // ── Logout ───────────────────────────────────────────
    public function logout()
    {
        $user = session()->get('user');
        if ($user) {
            (new AuditModel())->log(
                $user['id'],
                $user['first'] . ' ' . $user['last'],
                $user['role'],
                'LOGOUT',
                'User logged out.',
                $this->request->getIPAddress()
            );
        }
        session()->destroy();
        return redirect()->to('/login');
    }

    // ── Helper: redirect based on role ───────────────────
    private function redirectByRole()
    {
        $role = session()->get('user')['role'] ?? '';
        $map  = [
            'admin'     => '/admin/dashboard',
            'hr'        => '/hr/dashboard',
            'applicant' => '/applicant/dashboard',
        ];
        return redirect()->to($map[$role] ?? '/login');
    }
}
