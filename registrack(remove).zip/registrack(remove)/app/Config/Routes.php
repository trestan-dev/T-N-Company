<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// app/Config/Routes.php

$routes->get('/', 'HomeController::index');

// ── Auth (public, no filter) ──────────────────────────
$routes->get('login',   'AuthController::loginPage');
$routes->post('login',  'AuthController::login');
$routes->get('signup',  'AuthController::signupPage');
$routes->post('signup', 'AuthController::register');
$routes->get('logout',  'AuthController::logout');

// ── Applicant (protected — role: applicant) ───────────
$routes->group('applicant', ['filter' => 'auth:applicant'], function($routes) {
    $routes->get('dashboard',           'DashboardController::applicant');
    $routes->get('jobs',                'JobController::listActive');
    $routes->get('jobs/(:num)',         'JobController::detail/$1');
    $routes->post('apply/(:num)',       'ApplicationController::apply/$1');
    $routes->get('applications',        'ApplicationController::myApplications');
    $routes->get('applications/(:num)', 'ApplicationController::detail/$1');
    $routes->post('offer/respond',      'ApplicationController::respondToOffer');
});

// ── HR (protected — role: hr) ─────────────────────────
$routes->group('hr', ['filter' => 'auth:hr'], function($routes) {
    $routes->get('dashboard',                   'HRController::dashboard');
    $routes->get('applications',                'HRController::applications');
    $routes->post('applications/(:num)/status', 'HRController::updateStatus/$1');
    $routes->get('jobs',                        'HRController::jobs');
    $routes->post('jobs/create',                'HRController::createJob');
    $routes->post('jobs/(:num)/update',         'HRController::updateJob/$1');
    $routes->post('jobs/(:num)/toggle',         'HRController::toggleJob/$1');
    $routes->post('jobs/(:num)/delete',         'HRController::deleteJob/$1');
});

// ── Admin (protected — role: admin) ──────────────────
$routes->group('admin', ['filter' => 'auth:admin'], function($routes) {
    $routes->get('dashboard',                     'AdminController::dashboard');
    $routes->get('applications',                  'AdminController::applications');
    $routes->get('jobs',                          'AdminController::jobs');
    $routes->post('jobs/create',                  'AdminController::createJob');
    $routes->post('jobs/(:num)/update',           'AdminController::updateJob/$1');
    $routes->post('jobs/(:num)/toggle',           'AdminController::toggleJob/$1');
    $routes->post('jobs/(:num)/delete',           'AdminController::deleteJob/$1');
    $routes->post('applications/(:num)/status',   'AdminController::updateStatus/$1');
    $routes->get('audit',                         'AdminController::audit');
    $routes->get('staff',                         'AdminController::hrStaff');
    $routes->post('staff/create',                 'AdminController::createHR');
    $routes->post('staff/(:num)/deactivate',      'AdminController::deactivateHR/$1');
    $routes->get('applicants',                    'AdminController::applicants');
    $routes->post('applicants/(:num)/deactivate', 'AdminController::deactivateUser/$1');
    $routes->get('employees',                     'AdminController::employees');
    $routes->post('employees/(:num)/deactivate',  'AdminController::deactivateEmployee/$1');
    $routes->get('export/csv',                    'AdminController::exportCSV');
});

// ── API endpoints (called by dashboard fetch()) ────────
$routes->group('api', ['filter' => 'auth'], function($routes) {
    $routes->get('jobs',                'JobController::apiList');
    $routes->get('applications/stats',  'ApplicationController::apiStats');
    $routes->get('applications',        'ApplicationController::apiList');
    $routes->get('employees',           'AdminController::apiEmployees');
    // FIX: Audit now has a dedicated controller method that supports search + sort
    $routes->get('audit',              'AdminController::apiAudit');
    // FIX: Chart endpoints were missing — caused blank charts on admin dashboard
    $routes->get('charts/by-department', 'AdminController::apiChartByDept');
    $routes->get('charts/volume',        'AdminController::apiChartVolume');
    $routes->get('staff',              'AdminController::apiStaff');
    $routes->get('applicants',         'AdminController::apiApplicants');
    $routes->get('resumes/(:segment)', 'ApplicationController::serveResume/$1');

    // ✅ FIX: job-image route now correctly handles subdirectory paths with proper placeholder
    $routes->get('job-image/(:any)',   'JobController::serveJobImage/$1');

    // FIX: HR/admin job toggle and delete were firing through api/* group
    // but the routes only existed under hr/* and admin/*. When the dashboard JS
    // calls base_url('hr/jobs/') + id + '/toggle' those ARE correctly under hr/.
    // No change needed here — leaving comment for clarity.
});