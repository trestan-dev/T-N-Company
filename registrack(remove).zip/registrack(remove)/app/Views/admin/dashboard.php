<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Admin Dashboard — T&N Company Careers</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600;700;800&family=DM+Serif+Display:ital@0;1&display=swap" rel="stylesheet" />
  <link href="<?= base_url('assets/css/style.css') ?>" rel="stylesheet" />
</head>
<body>

  <?php
  $userJson = json_encode([
      'id'    => $user['id'],
      'role'  => $user['role'],
      'first' => $user['first'],
      'last'  => $user['last'],
      'email' => $user['email'],
  ]);
  ?>

  <div id="topbarMount"></div>

  <div class="rt-page-wrap">
    <div class="container">

      <div class="rt-page-header">
        <div>
          <h1 class="rt-page-title">System Overview</h1>
          <p class="rt-page-sub">Full administrative control — analytics, jobs, applications, audit, and HR management.</p>
        </div>
        <div class="d-flex gap-2 flex-wrap">
          <a href="<?= base_url('admin/export/csv') ?>" class="rt-btn rt-btn-outline rt-btn-sm">
            <i class="fas fa-download me-1"></i>Export CSV
          </a>
          <button class="rt-btn rt-btn-primary rt-btn-sm" onclick="openNewJobModal()" data-bs-toggle="modal" data-bs-target="#postJobModal">
            <i class="fas fa-plus me-1"></i>Post a Job
          </button>
        </div>
      </div>

      <div class="rt-tabs" id="adminTabs">
        <button class="rt-tab active" onclick="switchTab('overview',this)"><i class="fas fa-chart-pie me-2"></i>Overview</button>
        <button class="rt-tab" onclick="switchTab('applications',this)"><i class="fas fa-file-lines me-2"></i>Applications</button>
        <button class="rt-tab" onclick="switchTab('jobs',this)"><i class="fas fa-briefcase me-2"></i>Jobs</button>
        <button class="rt-tab" onclick="switchTab('employees',this)"><i class="fas fa-id-badge me-2"></i>Employees</button>
        <button class="rt-tab" onclick="switchTab('audit',this)"><i class="fas fa-scroll me-2"></i>Audit Log</button>
        <button class="rt-tab" onclick="switchTab('staff',this)"><i class="fas fa-users-gear me-2"></i>HR Staff</button>
        <button class="rt-tab" onclick="switchTab('users',this)"><i class="fas fa-user-tie me-2"></i>Applicants</button>
      </div>

      <!-- Overview -->
      <div id="tab-overview">
        <div class="row g-3 mb-4" id="adminStats"></div>
        <div class="row g-4">
          <div class="col-md-5">
            <div class="rt-card h-100">
              <div class="rt-card-header"><div class="rt-card-header-left"><div class="rt-section-num"><i class="fas fa-chart-pie"></i></div><h2 class="rt-card-title">Status Breakdown</h2></div></div>
              <div class="rt-card-body d-flex align-items-center justify-content-center" style="min-height:260px;">
                <div style="max-width:260px;width:100%;"><canvas id="statusChart"></canvas></div>
              </div>
            </div>
          </div>
          <div class="col-md-7">
            <div class="rt-card h-100">
              <div class="rt-card-header"><div class="rt-card-header-left"><div class="rt-section-num"><i class="fas fa-chart-bar"></i></div><h2 class="rt-card-title">Applications by Department</h2></div></div>
              <div class="rt-card-body" style="min-height:260px;"><canvas id="deptChart"></canvas></div>
            </div>
          </div>
          <div class="col-12">
            <div class="rt-card">
              <div class="rt-card-header"><div class="rt-card-header-left"><div class="rt-section-num"><i class="fas fa-chart-line"></i></div><h2 class="rt-card-title">Application Volume Over Time</h2></div></div>
              <div class="rt-card-body"><canvas id="timelineChart" style="max-height:220px;"></canvas></div>
            </div>
          </div>
        </div>
      </div>

      <!-- Applications -->
      <div id="tab-applications" style="display:none;">
        <div class="rt-card">
          <div class="rt-card-header"><div class="rt-card-header-left"><div class="rt-section-num"><i class="fas fa-file-lines"></i></div><h2 class="rt-card-title">All Applications</h2></div>
            <span class="rt-muted" id="adminAppCount"></span>
          </div>
          <div id="adminAppFilterMount"></div>
          <div class="rt-table-wrap">
            <table class="rt-table">
              <thead><tr><th>Code</th><th>Applicant</th><th>Position</th><th>Dept</th><th>Score</th><th>Status</th><th>Submitted</th><th>Actions</th></tr></thead>
              <tbody id="adminAppTbody"><tr><td colspan="8" class="text-center py-4" style="color:var(--mid);">Loading…</td></tr></tbody>
            </table>
          </div>
        </div>
      </div>

      <!-- Jobs -->
      <div id="tab-jobs" style="display:none;">
        <div class="rt-card">
          <div class="rt-card-header"><div class="rt-card-header-left"><div class="rt-section-num"><i class="fas fa-briefcase"></i></div><h2 class="rt-card-title">Job Postings</h2></div>
            <div class="d-flex gap-2 align-items-center"><span class="rt-muted" id="adminJobCount"></span><div id="adminJobViewToggleMount"></div></div>
          </div>
          <div id="adminJobFilterMount"></div>
          <input type="hidden" id="admjobs_viewmode" value="list" />
          <div id="adminJobsContainer"></div>
        </div>
      </div>

      <!-- Employees -->
      <div id="tab-employees" style="display:none;">
        <div class="rt-card">
          <div class="rt-card-header"><div class="rt-card-header-left"><div class="rt-section-num"><i class="fas fa-id-badge"></i></div><h2 class="rt-card-title">Company Employees</h2></div>
            <span class="rt-muted" id="empCount"></span>
          </div>
          <div id="empFilterMount"></div>
          <div class="rt-table-wrap">
            <table class="rt-table">
              <thead><tr><th>Employee</th><th>Position</th><th>Department</th><th>Type</th><th>Arrangement</th><th>Hired By</th><th>Hire Date</th><th>Source</th><th>Status</th><th>Actions</th></tr></thead>
              <tbody id="empTbody"><tr><td colspan="10" class="text-center py-4" style="color:var(--mid);">Loading…</td></tr></tbody>
            </table>
          </div>
        </div>
      </div>

      <!-- Audit Log -->
      <div id="tab-audit" style="display:none;">
        <div class="rt-card">
          <div class="rt-card-header"><div class="rt-card-header-left"><div class="rt-section-num"><i class="fas fa-scroll"></i></div><h2 class="rt-card-title">Audit Log</h2></div>
            <span class="rt-muted" id="auditCount"></span>
          </div>
          <div id="auditFilterMount"></div>
          <div class="rt-card-body" id="auditList" style="max-height:600px;overflow-y:auto;padding:0;"></div>
        </div>
      </div>

      <!-- HR Staff -->
      <div id="tab-staff" style="display:none;">
        <div class="d-flex justify-content-between align-items-center mb-3">
          <h5 style="font-family:var(--font-head);margin:0;">HR Accounts</h5>
          <button class="rt-btn rt-btn-primary rt-btn-sm" data-bs-toggle="modal" data-bs-target="#addHrModal">
            <i class="fas fa-user-plus me-1"></i>Add HR Staff
          </button>
        </div>
        <div class="rt-card">
          <div id="hrFilterMount"></div>
          <div class="rt-table-wrap">
            <table class="rt-table">
              <thead><tr><th>Name</th><th>Email</th><th>Created</th><th>Status</th><th>Actions</th></tr></thead>
              <tbody id="hrStaffTbody"><tr><td colspan="5" class="text-center py-4" style="color:var(--mid);">Loading…</td></tr></tbody>
            </table>
          </div>
        </div>
      </div>

      <!-- Applicants -->
      <div id="tab-users" style="display:none;">
        <div class="rt-card">
          <div class="rt-card-header"><div class="rt-card-header-left"><div class="rt-section-num"><i class="fas fa-user-tie"></i></div><h2 class="rt-card-title">Registered Applicants</h2></div>
            <span class="rt-muted" id="usersCount"></span>
          </div>
          <div id="usersFilterMount"></div>
          <div class="rt-table-wrap">
            <table class="rt-table">
              <thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Registered</th><th>Status</th><th>Actions</th></tr></thead>
              <tbody id="usersTbody"><tr><td colspan="6" class="text-center py-4" style="color:var(--mid);">Loading…</td></tr></tbody>
            </table>
          </div>
        </div>
      </div>

    </div>
  </div>

  <!-- Add HR Modal -->
  <div class="modal fade" id="addHrModal" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title"><i class="fas fa-user-plus me-2"></i>Add HR Staff Account</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <div id="hrModalAlert" class="rt-alert"></div>
          <form id="addHrForm" novalidate>
            <?= csrf_field() ?>
            <div class="row g-3">
              <div class="col-6">
                <div class="rt-field-group"><label class="rt-label" for="hr_first">First Name <span class="rt-required">*</span></label>
                  <input id="hr_first" name="first" type="text" class="rt-input" placeholder="Maria" data-required="true" data-type="name" data-label="First name" data-min="2" /><span class="rt-field-error"></span></div>
              </div>
              <div class="col-6">
                <div class="rt-field-group"><label class="rt-label" for="hr_last">Last Name <span class="rt-required">*</span></label>
                  <input id="hr_last" name="last" type="text" class="rt-input" placeholder="Reyes" data-required="true" data-type="name" data-label="Last name" data-min="2" /><span class="rt-field-error"></span></div>
              </div>
              <div class="col-12">
                <div class="rt-field-group"><label class="rt-label" for="hr_email">Email <span class="rt-required">*</span></label>
                  <input id="hr_email" name="email" type="email" class="rt-input" placeholder="hr.staff@tncompany.ph" data-required="true" data-type="email" data-label="Email" /><span class="rt-field-error"></span></div>
              </div>
              <div class="col-12">
                <div class="rt-field-group"><label class="rt-label" for="hr_pw">Temporary Password <span class="rt-required">*</span></label>
                  <div class="rt-input-wrap">
                    <input id="hr_pw" name="password" type="password" class="rt-input" placeholder="Min. 8 characters" data-required="true" data-type="password" data-label="Password" />
                    <button type="button" class="rt-pw-toggle" onclick="togglePwAdmin('hr_pw',this)"><i class="fas fa-eye"></i></button>
                  </div><span class="rt-field-error"></span></div>
              </div>
            </div>
          </form>
        </div>
        <div class="modal-footer">
          <button class="rt-btn rt-btn-outline" data-bs-dismiss="modal">Cancel</button>
          <button class="rt-btn rt-btn-primary" onclick="submitAddHR()"><i class="fas fa-user-plus me-1"></i>Create Account</button>
        </div>
      </div>
    </div>
  </div>

  <!-- Review Modal (same as HR) -->
  <div class="modal fade" id="reviewModal" tabindex="-1">
    <div class="modal-dialog modal-xl">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title"><i class="fas fa-clipboard-list me-2"></i>Review Application — <span id="reviewCode"></span></h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <div id="reviewAlert" class="rt-alert"></div>
          <div class="row g-4">
            <div class="col-md-7">
              <div class="rt-card mb-3"><div class="rt-card-header"><div class="rt-card-header-left"><i class="fas fa-user me-2" style="color:var(--accent);"></i><h6 class="rt-card-title mb-0">Applicant</h6></div></div><div class="rt-card-body"><div class="rt-detail-grid" id="reviewApplicantInfo"></div></div></div>
              <div class="rt-card mb-3"><div class="rt-card-header"><div class="rt-card-header-left"><i class="fas fa-briefcase me-2" style="color:var(--green);"></i><h6 class="rt-card-title mb-0">Application Details</h6></div></div><div class="rt-card-body"><div class="rt-detail-grid" id="reviewAppDetails"></div></div></div>
              <div class="rt-card mb-3" id="coverLetterCard" style="display:none;"><div class="rt-card-header"><div class="rt-card-header-left"><i class="fas fa-file-lines me-2" style="color:var(--purple);"></i><h6 class="rt-card-title mb-0">Cover Letter</h6></div></div><div class="rt-card-body"><p id="coverLetterText" style="font-size:.88rem;line-height:1.7;white-space:pre-wrap;margin:0;"></p></div></div>
              <div class="rt-card"><div class="rt-card-header"><div class="rt-card-header-left"><i class="fas fa-clock-rotate-left me-2" style="color:var(--mid);"></i><h6 class="rt-card-title mb-0">Status History</h6></div></div><div class="rt-card-body" id="statusHistoryBody" style="max-height:200px;overflow-y:auto;padding:12px 16px;"></div></div>
            </div>
            <div class="col-md-5">
              <div class="rt-card mb-3"><div class="rt-card-header"><div class="rt-card-header-left"><i class="fas fa-chart-bar me-2" style="color:var(--yellow);"></i><h6 class="rt-card-title mb-0">Resume Score</h6></div></div><div class="rt-card-body text-center" id="scoreDisplay"></div></div>
              <div class="rt-card"><div class="rt-card-header"><div class="rt-card-header-left"><i class="fas fa-pen-to-square me-2" style="color:var(--red);"></i><h6 class="rt-card-title mb-0">Update Stage</h6></div></div>
                <div class="rt-card-body">
                  <div class="rt-field-group"><label class="rt-label" for="newStatus">Move to Stage <span class="rt-required">*</span></label>
                    <select id="newStatus" class="rt-input rt-select" onchange="onStatusChange()">
                      <option value="">Choose next stage…</option>
                      <option value="Under Review">🔍 Under Review</option>
                      <option value="Phone Screen">📞 Phone Screen</option>
                      <option value="Interview Scheduled">📅 Interview Scheduled</option>
                      <option value="Final Interview">👥 Final Interview</option>
                      <option value="Job Offer">📧 Job Offer</option>
                      <option value="Offer Accepted">🤝 Offer Accepted</option>
                      <option value="Hired">✅ Hired</option>
                      <option value="Rejected">❌ Rejected</option>
                      <option value="Withdrawn">🚫 Withdrawn</option>
                    </select></div>
                  <div class="rt-status-extra-fields" id="interviewDateWrap"><div class="rt-field-group mb-2"><label class="rt-label" for="interviewDate"><i class="fas fa-calendar me-1"></i>Interview Date</label><input type="date" id="interviewDate" class="rt-input" /></div></div>
                  <div class="rt-status-extra-fields" id="offerDateWrap"><div class="rt-field-group mb-2"><label class="rt-label" for="offerDate"><i class="fas fa-calendar me-1"></i>Offer Date</label><input type="date" id="offerDate" class="rt-input" /></div></div>
                  <div class="rt-field-group"><label class="rt-label" for="hrNotes">Notes <span class="rt-optional">(optional)</span></label><textarea id="hrNotes" class="rt-input rt-textarea" placeholder="Observations, feedback, notes…"></textarea></div>
                  <button class="rt-btn rt-btn-primary w-100" onclick="submitDecision()"><i class="fas fa-check me-2"></i>Save Decision</button>
                </div></div>
            </div>
          </div>
        </div>
        <div class="modal-footer"><button class="rt-btn rt-btn-outline" data-bs-dismiss="modal">Close</button></div>
      </div>
    </div>
  </div>

  <!-- Post Job Modal -->
  <div class="modal fade" id="postJobModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="postJobModalTitle"><i class="fas fa-briefcase me-2"></i>Post a New Job Opening</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <div id="jobPostAlert" class="rt-alert"></div>
          <input type="hidden" id="editingJobId" value="" />
          <form id="postJobForm" enctype="multipart/form-data" novalidate>
            <?= csrf_field() ?>
            <div class="row g-3">
              <div class="col-12"><div class="rt-field-group"><label class="rt-label" for="jobTitle">Job Title <span class="rt-required">*</span></label><input id="jobTitle" name="title" type="text" class="rt-input" placeholder="e.g. Senior Software Engineer" data-required="true" data-label="Job title" data-min="3" /><span class="rt-field-error"></span></div></div>
              <div class="col-md-4"><div class="rt-field-group"><label class="rt-label" for="jobDept">Department <span class="rt-required">*</span></label><select id="jobDept" name="department" class="rt-input rt-select" data-required="true" data-label="Department"><option value="">Select…</option><option>IT Department</option><option>Human Resources</option><option>Finance</option><option>Operations</option><option>Marketing</option><option>Legal</option><option>Administration</option></select><span class="rt-field-error"></span></div></div>
              <div class="col-md-4"><div class="rt-field-group"><label class="rt-label" for="jobType">Employment Type <span class="rt-required">*</span></label><select id="jobType" name="employment_type" class="rt-input rt-select" data-required="true" data-label="Employment type"><option value="">Select…</option><option>Full-Time</option><option>Part-Time</option><option>Contract</option><option>Internship</option></select><span class="rt-field-error"></span></div></div>
              <div class="col-md-4"><div class="rt-field-group"><label class="rt-label" for="jobArr">Arrangement <span class="rt-required">*</span></label><select id="jobArr" name="arrangement" class="rt-input rt-select" data-required="true" data-label="Arrangement"><option value="">Select…</option><option>On-site</option><option>Remote</option><option>Hybrid</option></select><span class="rt-field-error"></span></div></div>
              <div class="col-md-6"><div class="rt-field-group"><label class="rt-label" for="jobSalary">Salary Range <span class="rt-optional">(optional)</span></label><input id="jobSalary" name="salary_range" type="text" class="rt-input" placeholder="e.g. ₱25,000 – ₱35,000" /></div></div>
              <div class="col-12"><div class="rt-field-group"><label class="rt-label" for="jobDesc">Job Description <span class="rt-required">*</span></label><textarea id="jobDesc" name="description" class="rt-input rt-textarea" style="min-height:120px;" placeholder="Describe the role, responsibilities, and qualifications…" data-required="true" data-label="Description" data-min="20"></textarea><span class="rt-field-error"></span></div></div>
              <div class="col-12"><div class="rt-field-group"><label class="rt-label" for="jobReqs">Requirements <span class="rt-optional">(optional)</span></label><textarea id="jobReqs" name="requirements" class="rt-input rt-textarea" style="min-height:80px;" placeholder="List required skills, experience, education…"></textarea></div></div>
              <div class="col-12"><div class="rt-field-group mb-0"><label class="rt-label">Cover Image <span class="rt-optional">(optional)</span></label><div class="rt-upload-zone" id="jobImgZone" onclick="document.getElementById('jobImgFile').click()" style="padding:16px;"><div class="rt-upload-icon" style="font-size:1.5rem;"><i class="fas fa-image"></i></div><div class="rt-upload-label">Click to upload a job cover image</div><div class="rt-upload-hint">JPG, PNG — max 3 MB</div></div><input type="file" id="jobImgFile" name="image" accept="image/jpeg,image/png,image/webp" style="display:none;" /><div id="jobImgPreview" class="mt-2"></div></div></div>
            </div>
          </form>
        </div>
        <div class="modal-footer">
          <button class="rt-btn rt-btn-outline" data-bs-dismiss="modal">Cancel</button>
          <button type="button" class="rt-btn rt-btn-primary" onclick="submitPostJob()" id="postJobSubmitBtn"><i class="fas fa-paper-plane me-1"></i>Publish Job</button>
        </div>
      </div>
    </div>
  </div>

  <!-- PDF Viewer Modal -->
  <div class="modal fade" id="pdfModal" tabindex="-1">
    <div class="modal-dialog modal-xl" style="max-width:900px;">
      <div class="modal-content" style="height:90vh;">
        <div class="modal-header">
          <h5 class="modal-title"><i class="fas fa-file-pdf me-2" style="color:var(--red);"></i><span id="pdfModalTitle">Resume Preview</span></h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body p-0" style="flex:1;overflow:hidden;"><div id="pdfViewerBody" style="width:100%;height:100%;"></div></div>
      </div>
    </div>
  </div>

  <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
  <script src="<?= base_url('assets/js/validation.js') ?>"></script>
  <script>
    const BASE_URL = "<?= base_url('/') ?>";
  </script>
  <script src="<?= base_url('assets/js/dashboard.js') ?>"></script>
  <script>
    // USER from PHP session — replaces Auth.requireRole('admin')
    const USER = <?= $userJson ?>;
    document.getElementById('topbarMount').innerHTML = initTopbar(USER, 'admin');

    let currentAppId = null, currentApp = null;
    const ALL_TABS   = ['overview','applications','jobs','employees','audit','staff','users'];

    /* ── Tabs ── */
    function switchTab(name, el) {
      document.querySelectorAll('.rt-tab').forEach(t => t.classList.remove('active'));
      el.classList.add('active');
      ALL_TABS.forEach(t => { document.getElementById('tab-' + t).style.display = t === name ? 'block' : 'none'; });
      if (name === 'applications') { initAdminAppFilterBar(); loadAdminApps(); }
      if (name === 'jobs')         { initAdminJobFilterBar(); loadAdminJobs(); }
      if (name === 'employees')    { loadEmployees(); }
      if (name === 'audit')        { loadAudit(); }
      if (name === 'staff')        { loadHRStaff(); }
      if (name === 'users')        { loadApplicants(); }
    }

    /* ── Overview Stats + Charts ── */
    let statusChart, deptChart, timelineChart;
    const CC = { blue:'#2563eb', green:'#16a34a', yellow:'#d97706', red:'#dc2626', purple:'#7c3aed', teal:'#0891b2', orange:'#ea580c', pink:'#db2777' };

    async function renderAdminStats() {
      const [statsRes, jobsRes, empRes, usersRes, deptRes, volumeRes] = await Promise.all([
        fetch('<?= base_url('api/applications/stats') ?>'),
        fetch('<?= base_url('api/jobs') ?>'),
        fetch('<?= base_url('api/employees') ?>'),
        fetch('<?= base_url('api/applicants') ?>'),
        fetch('<?= base_url('api/charts/by-department') ?>'),
        fetch('<?= base_url('api/charts/volume') ?>'),
      ]);
      const stats      = await statsRes.json();
      const jobs       = await jobsRes.json();
      const emps       = await empRes.json();
      const users      = await usersRes.json();
      const deptData   = await deptRes.json();
      const volumeData = await volumeRes.json();

      document.getElementById('adminStats').innerHTML = `
        <div class="col-6 col-md-3"><div class="rt-stat-card rt-stat-card--blue"><div class="rt-stat-icon rt-stat-icon--blue"><i class="fas fa-file-lines"></i></div><div class="rt-stat-num">${stats.total}</div><div class="rt-stat-label">Total Applications</div></div></div>
        <div class="col-6 col-md-3"><div class="rt-stat-card rt-stat-card--green"><div class="rt-stat-icon rt-stat-icon--green"><i class="fas fa-user-check"></i></div><div class="rt-stat-num">${stats.hired}</div><div class="rt-stat-label">Hired</div></div></div>
        <div class="col-6 col-md-3"><div class="rt-stat-card rt-stat-card--yellow"><div class="rt-stat-icon rt-stat-icon--yellow"><i class="fas fa-briefcase"></i></div><div class="rt-stat-num">${jobs.filter(j=>j.is_active).length}</div><div class="rt-stat-label">Active Job Listings</div></div></div>
        <div class="col-6 col-md-3"><div class="rt-stat-card rt-stat-card--purple"><div class="rt-stat-icon rt-stat-icon--purple"><i class="fas fa-user-tie"></i></div><div class="rt-stat-num">${users.length}</div><div class="rt-stat-label">Registered Applicants</div></div></div>`;

      // Charts using API data
      initCharts(stats, deptData, volumeData);
    }

    function initCharts(stats, deptData, volumeData) {
      if (statusChart) statusChart.destroy();
      if (deptChart)   deptChart.destroy();
      if (timelineChart) timelineChart.destroy();

      statusChart = new Chart(document.getElementById('statusChart'), {
        type: 'doughnut',
        data: {
          labels: ['Submitted','In Process','Hired','Rejected'],
          datasets: [{ data: [stats.submitted, stats.in_process, stats.hired, stats.rejected],
            backgroundColor: [CC.blue, CC.yellow, CC.green, CC.red], borderWidth: 2, borderColor: '#fff' }]
        },
        options: { plugins: { legend: { position:'bottom', labels: { font: { family:'Sora', size:12 }, padding:14 } } }, cutout:'65%' }
      });

      deptChart = new Chart(document.getElementById('deptChart'), {
        type: 'bar',
        data: {
          labels: deptData.map(r => r.department || 'Unknown'),
          datasets: [{
            label: 'Applications',
            data: deptData.map(r => r.total),
            backgroundColor: deptData.map((_, idx) => [CC.blue, CC.green, CC.yellow, CC.red, CC.purple, CC.teal, CC.orange, CC.pink][idx % 8]),
            borderRadius: 8,
            barThickness: 26,
          }]
        },
        options: {
          plugins: { legend: { display:false } },
          scales: {
            x: { ticks: { font: { family:'Sora', size:12 } } },
            y: { beginAtZero:true, ticks: { precision:0, font: { family:'Sora', size:12 } } }
          },
          maintainAspectRatio: false,
        }
      });

      timelineChart = new Chart(document.getElementById('timelineChart'), {
        type: 'line',
        data: {
          labels: volumeData.map(r => r.date),
          datasets: [{
            label: 'Applications',
            data: volumeData.map(r => r.total),
            borderColor: CC.blue,
            backgroundColor: 'rgba(37,99,235,0.2)',
            fill: true,
            tension: 0.35,
            pointRadius: 3,
            pointBackgroundColor: CC.blue,
            borderWidth: 2,
          }]
        },
        options: {
          plugins: { legend: { display:false } },
          scales: {
            x: { grid: { display:false }, ticks: { font: { family:'Sora', size:12 } } },
            y: { beginAtZero:true, ticks: { precision:0, font: { family:'Sora', size:12 } } }
          },
          maintainAspectRatio: false,
        }
      });
    }

    /* ── Applications ── */
    function initAdminAppFilterBar() {
      document.getElementById('adminAppFilterMount').innerHTML = buildFilterBar('admapp', {
        searchPlaceholder: 'Search applicant, code, position…',
        filters: [
          { id: 'admapp_status', placeholder: 'All Statuses', width: '170px', options: APP_STATUSES.map(s => ({ value: s, label: s })) },
          { id: 'admapp_dept',   placeholder: 'All Departments', width: '155px', options: ['IT Department','Human Resources','Finance','Operations','Marketing','Legal','Administration'] },
        ],
        sorts: [
          { value: 'submitted_at|desc', label: 'Newest first' },
          { value: 'submitted_at|asc',  label: 'Oldest first' },
          { value: 'resume_score|desc', label: 'Highest score' },
          { value: 'status|asc',        label: 'A → Z (status)' },
        ],
        onChangeFn: 'loadAdminApps',
      });
    }

    async function loadAdminApps() {
      const { search, sortBy, sortDir, filters } = getFilterBarValues('admapp');
      const params = new URLSearchParams({
        search: search || '', sort: sortBy || 'submitted_at', dir: sortDir || 'desc',
        status: filters['admapp_status'] || '', dept: filters['admapp_dept'] || '',
      });
      const res  = await fetch(`<?= base_url('api/applications') ?>?${params}`);
      const apps = await res.json();

      document.getElementById('adminAppCount').textContent = apps.length + ' result(s)';
      const tbody = document.getElementById('adminAppTbody');
      if (!apps.length) { tbody.innerHTML = '<tr><td colspan="8" class="text-center py-4" style="color:var(--mid);">No applications match your filters.</td></tr>'; return; }
      tbody.innerHTML = apps.map(a => `<tr>
        <td><code style="font-size:.82rem;">${a.app_code}</code></td>
        <td><div class="d-flex align-items-center gap-2">
          <div class="rt-avatar rt-avatar--sm">${((a.first_name||'?')[0]+(a.last_name||'?')[0]).toUpperCase()}</div>
          <div><div style="font-weight:600;font-size:.85rem;">${a.first_name} ${a.last_name}</div>
          <div style="font-size:.74rem;color:var(--mid);">${a.email}</div></div></div></td>
        <td style="max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${a.position}</td>
        <td style="max-width:130px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${a.department}</td>
        <td>${scoreBarHTML(a.resume_score)}</td>
        <td>${statusBadgeHTML(a.status)}</td>
        <td style="white-space:nowrap;">${a.submitted_at}</td>
        <td><button class="rt-btn rt-btn-outline rt-btn-sm" onclick="openReview(${JSON.stringify(a).replace(/"/g,'&quot;')})"><i class="fas fa-clipboard-list me-1"></i>Review</button></td>
      </tr>`).join('');
    }

    /* ── Review (same logic as HR) ── */
    function openReview(app) {
      currentApp = app; currentAppId = app.id;
      document.getElementById('reviewCode').textContent = app.app_code;
      document.getElementById('reviewApplicantInfo').innerHTML = `
        <div class="rt-detail-item"><label>Full Name</label><span>${app.first_name} ${app.last_name}</span></div>
        <div class="rt-detail-item"><label>Email</label><span>${app.email}</span></div>
        <div class="rt-detail-item"><label>Resume</label>
          <span><i class="fas fa-file-pdf" style="color:var(--red);margin-right:4px;"></i>${app.resume_name || '—'}</span>
          ${app.resume_name ? `<button class="rt-btn rt-btn-outline rt-btn-sm ms-2" onclick="openPdfViewer('${app.resume_name}','${app.app_code}')"><i class="fas fa-eye me-1"></i>View</button>` : ''}
        </div>
        <div class="rt-detail-item"><label>Submitted</label><span>${app.submitted_at}</span></div>`;
      document.getElementById('reviewAppDetails').innerHTML = `
        <div class="rt-detail-item"><label>Position</label><span>${app.position}</span></div>
        <div class="rt-detail-item"><label>Department</label><span>${app.department}</span></div>
        <div class="rt-detail-item"><label>Type</label><span>${app.employment_type}</span></div>
        <div class="rt-detail-item"><label>Arrangement</label><span>${app.arrangement}</span></div>
        <div class="rt-detail-item"><label>Status</label><span>${statusBadgeHTML(app.status)}</span></div>`;
      const sc = app.resume_score || 0;
      const scC = sc >= 80 ? 'var(--green)' : sc >= 65 ? 'var(--accent)' : 'var(--yellow)';
      document.getElementById('scoreDisplay').innerHTML = `<div style="font-family:var(--font-head);font-size:3rem;color:${scC};line-height:1;">${sc}</div><div style="font-size:.8rem;color:var(--mid);margin-top:4px;">/ 100</div><div style="margin-top:12px;">${scoreBarHTML(sc)}</div>`;
      if (app.cover_letter) { document.getElementById('coverLetterCard').style.display=''; document.getElementById('coverLetterText').textContent=app.cover_letter; }
      else document.getElementById('coverLetterCard').style.display='none';
      document.getElementById('statusHistoryBody').innerHTML = '<div style="color:var(--mid);font-size:.82rem;">History logged after status updates.</div>';
      document.getElementById('newStatus').value=''; document.getElementById('hrNotes').value='';
      document.getElementById('interviewDate').value=app.interview_date||''; document.getElementById('offerDate').value=app.offer_date||'';
      document.getElementById('interviewDateWrap').classList.remove('show'); document.getElementById('offerDateWrap').classList.remove('show');
      Validate.hideAlert('reviewAlert');
      new bootstrap.Modal(document.getElementById('reviewModal')).show();
    }

    function onStatusChange() {
      const s = document.getElementById('newStatus').value;
      document.getElementById('interviewDateWrap').classList.toggle('show', s==='Interview Scheduled'||s==='Final Interview');
      document.getElementById('offerDateWrap').classList.toggle('show', s==='Job Offer'||s==='Hired');
    }

    async function submitDecision() {
      const status = document.getElementById('newStatus').value;
      if (!status) { Validate.showAlert('reviewAlert','Please select a stage.','error'); return; }
      const form = new FormData();
      form.append('status', status);
      form.append('notes', document.getElementById('hrNotes').value.trim());
      form.append('interview_date', document.getElementById('interviewDate').value);
      form.append('offer_date', document.getElementById('offerDate').value);
      form.append('<?= csrf_token() ?>', '<?= csrf_hash() ?>');

      const res  = await fetch(`<?= base_url('admin/applications/') ?>${currentAppId}/status`, { method:'POST', body:form });
      const data = await res.json();
      if (!data.ok) { Validate.showAlert('reviewAlert', data.msg||'Error.', 'error'); return; }
      Validate.toast('Status updated to "' + status + '"', 'success');
      bootstrap.Modal.getInstance(document.getElementById('reviewModal')).hide();
      loadAdminApps();
    }

    /* ── Jobs ── */
    function initAdminJobFilterBar() {
      document.getElementById('adminJobViewToggleMount').innerHTML = buildViewToggle('admjobs', 'loadAdminJobs');
      document.getElementById('adminJobFilterMount').innerHTML = buildFilterBar('admjob', {
        searchPlaceholder: 'Search title, department…',
        filters: [
          { id: 'admjob_dept', placeholder: 'All Departments', width: '155px', options: ['IT Department','Human Resources','Finance','Operations','Marketing','Legal','Administration'] },
          { id: 'admjob_type', placeholder: 'All Types', width: '130px', options: ['Full-Time','Part-Time','Contract','Internship'] },
        ],
        sorts: [{ value:'created_at|desc',label:'Newest first'},{value:'created_at|asc',label:'Oldest first'},{value:'title|asc',label:'A → Z'}],
        onChangeFn: 'loadAdminJobs',
      });
    }

    async function loadAdminJobs() {
      const { search, sortBy, sortDir, filters } = getFilterBarValues('admjob');
      const params = new URLSearchParams({ search:search||'', sort:sortBy||'created_at', dir:sortDir||'desc', dept:filters['admjob_dept']||'', type:filters['admjob_type']||'' });
      const res  = await fetch(`<?= base_url('api/jobs') ?>?${params}`);
      const jobs = await res.json();
      document.getElementById('adminJobCount').textContent = jobs.length + ' posting(s)';
      const mode = document.getElementById('admjobs_viewmode').value;
      document.getElementById('adminJobsContainer').innerHTML = jobs.length
        ? (mode === 'list'
          ? `<div class="rt-table-wrap"><table class="rt-table"><thead><tr><th>Code</th><th>Title</th><th>Dept</th><th>Type</th><th>Status</th><th>Actions</th></tr></thead><tbody>` +
            jobs.map(j => `<tr><td><code style="font-size:.82rem;">${j.job_code}</code></td><td style="font-weight:600;">${j.title}</td><td>${j.department}</td><td>${j.employment_type}</td>
              <td>${j.is_active ? '<span class="rt-badge rt-badge-active">Active</span>' : '<span class="rt-badge rt-badge-inactive">Inactive</span>'}</td>
              <td>${adminJobActions(j)}</td></tr>`).join('') + '</tbody></table></div>'
          : '<div class="p-3"><div class="row g-3">' + jobs.map(j => `<div class="col-md-6 col-lg-4"><div class="rt-job-card ${!j.is_active?'rt-job-card--inactive':''}">
              ${j.image_url
                ? `<div class="rt-job-card-img"><img src="${j.image_url}" alt="${j.title}" style="width:100%;height:140px;object-fit:cover;"/></div>`
                : `<div class="rt-job-card-img rt-job-card-img--placeholder"><i class="fas fa-briefcase"></i></div>`}
              <div class="rt-job-card-body">
              <div class="d-flex justify-content-between gap-2 mb-2"><div><div class="rt-job-card-code">${j.job_code}</div><h3 class="rt-job-card-title">${j.title}</h3></div>${j.is_active?'<span class="rt-badge rt-badge-active">Active</span>':'<span class="rt-badge rt-badge-inactive">Inactive</span>'}</div>
              <div class="rt-job-card-meta"><span><i class="fas fa-building me-1"></i>${j.department}</span><span><i class="fas fa-clock me-1"></i>${j.employment_type}</span></div>
              <div class="rt-job-card-footer mt-3">${adminJobActions(j)}</div>
            </div></div></div>`).join('') + '</div></div>')
        : '<div class="rt-empty-state p-4"><i class="fas fa-briefcase"></i><p>No job postings.</p></div>';
    }

    function adminJobActions(j) {
      return `<button class="rt-btn rt-btn-outline rt-btn-sm me-1" onclick="openEditJob(${JSON.stringify(j).replace(/"/g,'&quot;')})"><i class="fas fa-pen me-1"></i>Edit</button>
        <button class="rt-btn rt-btn-sm me-1 ${j.is_active?'rt-btn-outline':'rt-btn-primary'}" onclick="toggleAdminJob(${j.id})"><i class="fas fa-${j.is_active?'eye-slash':'eye'} me-1"></i>${j.is_active?'Deactivate':'Activate'}</button>
        <button class="rt-btn rt-btn-danger rt-btn-sm" onclick="deleteAdminJob(${j.id})"><i class="fas fa-trash me-1"></i>Delete</button>`;
    }

    function openNewJobModal() {
      document.getElementById('editingJobId').value = '';
      document.getElementById('postJobModalTitle').innerHTML = '<i class="fas fa-briefcase me-2"></i>Post a New Job Opening';
      document.getElementById('postJobSubmitBtn').innerHTML = '<i class="fas fa-paper-plane me-1"></i>Publish Job';
      document.getElementById('jobImgPreview').innerHTML = '';
      document.getElementById('postJobForm').reset();
      Validate.hideAlert('jobPostAlert');
      Validate.clearAll($('#postJobForm'));
    }

    function openEditJob(job) {
      document.getElementById('editingJobId').value=job.id;
      document.getElementById('jobTitle').value=job.title;
      document.getElementById('jobDept').value=job.department;
      document.getElementById('jobType').value=job.employment_type;
      document.getElementById('jobArr').value=job.arrangement;
      document.getElementById('jobSalary').value=job.salary_range||'';
      document.getElementById('jobDesc').value=job.description||'';
      document.getElementById('jobReqs').value=job.requirements||'';
      document.getElementById('postJobModalTitle').innerHTML='<i class="fas fa-pen me-2"></i>Edit Job Posting';
      document.getElementById('postJobSubmitBtn').innerHTML='<i class="fas fa-save me-1"></i>Save Changes';
      if (job.image_url) {
        document.getElementById('jobImgPreview').innerHTML = `<img src="${job.image_url}" style="max-height:120px;border-radius:var(--r-sm);margin-top:4px;" />`;
      } else {
        document.getElementById('jobImgPreview').innerHTML = '';
      }
      new bootstrap.Modal(document.getElementById('postJobModal')).show();
    }

    async function submitPostJob() {
      if (!Validate.validateForm($('#postJobForm'))) return;
      const editId = document.getElementById('editingJobId').value;
      const url    = editId ? `<?= base_url('admin/jobs/') ?>${editId}/update` : `<?= base_url('admin/jobs/create') ?>`;
      const form   = new FormData(document.getElementById('postJobForm'));
      form.append('<?= csrf_token() ?>', '<?= csrf_hash() ?>');
      const res  = await fetch(url, { method:'POST', body:form });
      const data = await res.json();
      if (!data.ok) { Validate.showAlert('jobPostAlert', data.msg||'Error.','error'); return; }
      Validate.toast(editId?'Job updated!':'Job posted!','success');
      bootstrap.Modal.getInstance(document.getElementById('postJobModal')).hide();
      document.getElementById('postJobForm').reset();
      document.getElementById('editingJobId').value='';
      document.getElementById('postJobModalTitle').innerHTML='<i class="fas fa-briefcase me-2"></i>Post a New Job Opening';
      document.getElementById('postJobSubmitBtn').innerHTML='<i class="fas fa-paper-plane me-1"></i>Publish Job';
      loadAdminJobs();
    }

    async function toggleAdminJob(id) {
      const form = new FormData(); form.append('<?= csrf_token() ?>','<?= csrf_hash() ?>');
      await fetch(`<?= base_url('admin/jobs/') ?>${id}/toggle`,{method:'POST',body:form}); loadAdminJobs();
    }
    async function deleteAdminJob(id) {
      if (!confirm('Delete this job posting?')) return;
      const form = new FormData(); form.append('<?= csrf_token() ?>','<?= csrf_hash() ?>');
      await fetch(`<?= base_url('admin/jobs/') ?>${id}/delete`,{method:'POST',body:form});
      Validate.toast('Job deleted.','success'); loadAdminJobs();
    }

    /* ── Employees ── */
    async function loadEmployees() {
      const res  = await fetch('<?= base_url('api/employees') ?>');
      const emps = await res.json();
      document.getElementById('empCount').textContent = emps.length + ' employee(s)';
      const tbody = document.getElementById('empTbody');
      if (!emps.length) { tbody.innerHTML='<tr><td colspan="10" class="text-center py-4" style="color:var(--mid);">No employees yet.</td></tr>'; return; }
      tbody.innerHTML = emps.map(e => `<tr>
        <td><div class="d-flex align-items-center gap-2"><div class="rt-avatar rt-avatar--sm">${((e.first_name||'?')[0]+(e.last_name||'?')[0]).toUpperCase()}</div>
          <div><div style="font-weight:600;font-size:.85rem;">${e.first_name} ${e.last_name}</div><div style="font-size:.74rem;color:var(--mid);">${e.email}</div></div></div></td>
        <td style="max-width:150px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${e.position}</td>
        <td>${e.department}</td>
        <td><span class="rt-badge rt-badge-for-review">${e.employment_type}</span></td>
        <td>${e.arrangement}</td>
        <td style="max-width:120px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${e.hired_by_first||''} ${e.hired_by_last||''}</td>
        <td style="white-space:nowrap;">${e.hired_date}</td>
        <td><span class="rt-badge ${e.type==='staff'?'rt-badge-for-review':'rt-badge-approved'}">${e.type==='staff'?'HR Staff':'Hired'}</span></td>
        <td>${e.is_active?'<span class="rt-badge rt-badge-active">Active</span>':'<span class="rt-badge rt-badge-inactive">Inactive</span>'}</td>
        <td>${e.is_active&&e.type!=='staff'?`<button class="rt-btn rt-btn-danger rt-btn-sm" onclick="deactivateEmployee(${e.id})"><i class="fas fa-user-minus me-1"></i>Resign</button>`:'<span class="rt-muted">—</span>'}</td>
      </tr>`).join('');
    }

    async function deactivateEmployee(id) {
      if (!confirm('Mark this employee as inactive?')) return;
      const form = new FormData(); form.append('<?= csrf_token() ?>','<?= csrf_hash() ?>');
      await fetch(`<?= base_url('admin/employees/') ?>${id}/deactivate`,{method:'POST',body:form});
      Validate.toast('Employee marked inactive.','success'); loadEmployees();
    }

    /* ── Audit Log ── */
    async function loadAudit() {
      const res = await fetch('<?= base_url('api/audit') ?>');
      const log = await res.json();
      document.getElementById('auditCount').textContent = log.length + ' entries';
      document.getElementById('auditList').innerHTML = log.length
        ? log.map(e => `<div class="rt-audit-row" style="padding:10px 16px;border-bottom:1px solid var(--border);display:flex;gap:12px;align-items:flex-start;">
            <div class="rt-avatar rt-avatar--sm" style="flex-shrink:0;background:${e.role==='admin'?'var(--purple)':e.role==='hr'?'var(--green)':'var(--accent)'};">${(e.user_name||'?').split(' ').map(n=>n[0]).join('').substring(0,2).toUpperCase()}</div>
            <div style="flex:1;min-width:0;">
              <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-bottom:2px;">
                <strong style="font-size:.85rem;">${e.user_name||'System'}</strong>
                <span class="rt-badge" style="font-size:.65rem;background:var(--chalk);color:var(--mid);border:1px solid var(--border);">${e.role||'—'}</span>
                <code style="font-size:.73rem;background:var(--chalk);padding:1px 6px;border-radius:4px;border:1px solid var(--border);">${e.action}</code>
              </div>
              <div style="font-size:.82rem;color:var(--mid);">${e.description||''}</div>
              <div style="font-size:.74rem;color:var(--mid);margin-top:2px;">${e.created_at} ${e.ip_address?'· '+e.ip_address:''}</div>
            </div>
          </div>`).join('')
        : '<div class="text-center py-5" style="color:var(--mid);">No audit entries yet.</div>';
    }

    /* ── HR Staff ── */
    async function loadHRStaff() {
      const res   = await fetch('<?= base_url('api/staff') ?>');
      const staff = await res.json();
      const tbody = document.getElementById('hrStaffTbody');
      if (!staff.length) { tbody.innerHTML='<tr><td colspan="5" class="text-center py-4" style="color:var(--mid);">No HR accounts yet.</td></tr>'; return; }
      tbody.innerHTML = staff.map(u => `<tr>
        <td><div class="d-flex align-items-center gap-2"><div class="rt-avatar rt-avatar--sm">${((u.first_name||'?')[0]+(u.last_name||'?')[0]).toUpperCase()}</div>
          <strong>${u.first_name} ${u.last_name}</strong></div></td>
        <td>${u.email}</td>
        <td>${u.created_at ? u.created_at.split('T')[0] : '—'}</td>
        <td>${u.is_active?'<span class="rt-badge rt-badge-active">Active</span>':'<span class="rt-badge rt-badge-inactive">Inactive</span>'}</td>
        <td>${u.is_active?`<button class="rt-btn rt-btn-danger rt-btn-sm" onclick="deactivateHR(${u.id})"><i class="fas fa-ban me-1"></i>Deactivate</button>`:'<span class="rt-muted">—</span>'}</td>
      </tr>`).join('');
    }

    async function submitAddHR() {
      if (!Validate.validateForm($('#addHrForm'))) return;
      const form = new FormData(document.getElementById('addHrForm'));
      form.append('<?= csrf_token() ?>', '<?= csrf_hash() ?>');
      const res  = await fetch('<?= base_url('admin/staff/create') ?>', { method:'POST', body:form });
      const data = await res.json();
      if (!data.ok) { Validate.showAlert('hrModalAlert', data.msg||'Error.','error'); return; }
      Validate.toast('HR account created!','success');
      bootstrap.Modal.getInstance(document.getElementById('addHrModal')).hide();
      document.getElementById('addHrForm').reset();
      loadHRStaff();
    }

    async function deactivateHR(id) {
      if (!confirm('Deactivate this HR account?')) return;
      const form = new FormData(); form.append('<?= csrf_token() ?>','<?= csrf_hash() ?>');
      await fetch(`<?= base_url('admin/staff/') ?>${id}/deactivate`,{method:'POST',body:form});
      Validate.toast('Account deactivated.','success'); loadHRStaff();
    }

    /* ── Applicants ── */
    async function loadApplicants() {
      const res   = await fetch('<?= base_url('api/applicants') ?>');
      const users = await res.json();
      document.getElementById('usersCount').textContent = users.length + ' applicant(s)';
      const tbody = document.getElementById('usersTbody');
      if (!users.length) { tbody.innerHTML='<tr><td colspan="6" class="text-center py-4" style="color:var(--mid);">No applicants yet.</td></tr>'; return; }
      tbody.innerHTML = users.map(u => `<tr>
        <td><div class="d-flex align-items-center gap-2"><div class="rt-avatar rt-avatar--sm">${((u.first_name||'?')[0]+(u.last_name||'?')[0]).toUpperCase()}</div><strong>${u.first_name} ${u.last_name}</strong></div></td>
        <td>${u.email}</td>
        <td>${u.phone||'—'}</td>
        <td>${u.created_at?u.created_at.split('T')[0]:'—'}</td>
        <td>${u.is_active?'<span class="rt-badge rt-badge-active">Active</span>':'<span class="rt-badge rt-badge-inactive">Inactive</span>'}</td>
        <td>${u.is_active?`<button class="rt-btn rt-btn-danger rt-btn-sm" onclick="deactivateUser(${u.id})"><i class="fas fa-ban me-1"></i>Deactivate</button>`:'<span class="rt-muted">—</span>'}</td>
      </tr>`).join('');
    }

    async function deactivateUser(id) {
      if (!confirm('Deactivate this applicant account?')) return;
      const form = new FormData(); form.append('<?= csrf_token() ?>','<?= csrf_hash() ?>');
      await fetch(`<?= base_url('admin/applicants/') ?>${id}/deactivate`,{method:'POST',body:form});
      Validate.toast('Account deactivated.','success'); loadApplicants();
    }

    /* ── PDF Viewer ── */
    function openPdfViewer(filename, appCode) {
      document.getElementById('pdfModalTitle').textContent = filename;
      document.getElementById('pdfViewerBody').innerHTML =
        `<iframe src="<?= base_url('api/resumes/') ?>${appCode}" style="width:100%;height:100%;border:none;"></iframe>`;
      new bootstrap.Modal(document.getElementById('pdfModal')).show();
    }

    function togglePwAdmin(id, btn) {
      const inp = document.getElementById(id), ico = btn.querySelector('i');
      inp.type = inp.type==='password' ? 'text' : 'password';
      ico.classList.toggle('fa-eye'); ico.classList.toggle('fa-eye-slash');
    }

    document.getElementById('jobImgFile').addEventListener('change', function() {
      const f = this.files[0];
      if (!f) { document.getElementById('jobImgPreview').innerHTML=''; return; }
      const r = new FileReader();
      r.onload = e => { document.getElementById('jobImgPreview').innerHTML=`<img src="${e.target.result}" style="max-height:120px;border-radius:var(--r-sm);margin-top:4px;" />`; };
      r.readAsDataURL(f);
    });

    Validate.bindLive($('#postJobForm'));
    Validate.bindLive($('#addHrForm'));

    document.getElementById('postJobModal').addEventListener('hidden.bs.modal', function () {
      document.getElementById('postJobForm').reset();
      document.getElementById('editingJobId').value = '';
      document.getElementById('postJobModalTitle').innerHTML = '<i class="fas fa-briefcase me-2"></i>Post a New Job Opening';
      document.getElementById('postJobSubmitBtn').innerHTML  = '<i class="fas fa-paper-plane me-1"></i>Publish Job';
      document.getElementById('jobImgPreview').innerHTML = '';
      Validate.hideAlert('jobPostAlert');
      Validate.clearAll($('#postJobForm'));
    });

    /* ── Init ── */
    renderAdminStats();
  </script>
</body>
</html>
