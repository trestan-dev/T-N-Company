<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>T&N Company — Careers Portal</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600;700;800&family=DM+Serif+Display:ital@0;1&display=swap" rel="stylesheet" />
  <link href="<?= base_url('assets/css/style.css') ?>" rel="stylesheet" />
</head>
<body>

  <!-- NAV -->
  <nav class="rt-nav">
    <div class="container d-flex align-items-center justify-content-between">
      <div class="d-flex align-items-center gap-2">
        <div class="rt-brand"><span class="rt-brand-accent">T&amp;N</span> Company</div>
        <span class="rt-nav-divider">|</span>
        <span class="rt-nav-sub">Careers</span>
      </div>
      <div class="d-flex gap-2">
        <a href="<?= base_url('login') ?>" class="rt-btn rt-btn-ghost">Log In</a>
        <a href="<?= base_url('signup') ?>" class="rt-btn rt-btn-primary">Apply Now</a>
      </div>
    </div>
  </nav>

  <!-- HERO -->
  <section class="rt-hero">
    <div class="rt-hero-bg-grid"></div>
    <div class="container">
      <div class="row align-items-center g-5">
        <div class="col-lg-6">
          <div class="rt-hero-eyebrow">
            <span class="rt-badge-pill"><i class="fas fa-bolt me-1"></i> Now Hiring at T&amp;N Company</span>
          </div>
          <h1 class="rt-hero-title">Build Your Career <em>With Us.</em></h1>
          <p class="rt-hero-subtitle">T&N Company is a growing technology firm built on innovation, collaboration, and excellence. Our fully paperless hiring portal makes applying fast, transparent, and stress-free.</p>
          <div class="d-flex flex-wrap gap-3 mt-4">
            <a href="<?= base_url('signup') ?>" class="rt-btn rt-btn-primary rt-btn-lg">
              <i class="fas fa-file-pen me-2"></i>Start Your Application
            </a>
            <a href="<?= base_url('login') ?>" class="rt-btn rt-btn-outline rt-btn-lg">
              <i class="fas fa-arrow-right-to-bracket me-2"></i>Sign In
            </a>
          </div>
          <div class="rt-hero-stats mt-5">
            <div class="rt-hero-stat">
              <span class="rt-hero-stat-num">50+</span>
              <span class="rt-hero-stat-label">Open Positions</span>
            </div>
            <div class="rt-hero-stat-div"></div>
            <div class="rt-hero-stat">
              <span class="rt-hero-stat-num">100%</span>
              <span class="rt-hero-stat-label">Paperless Process</span>
            </div>
            <div class="rt-hero-stat-div"></div>
            <div class="rt-hero-stat">
              <span class="rt-hero-stat-num">48h</span>
              <span class="rt-hero-stat-label">Avg. Response Time</span>
            </div>
          </div>
        </div>
        <div class="col-lg-6 d-none d-lg-block">
          <div class="rt-hero-visual">
            <div class="rt-float-card rt-float-card--top">
              <div class="rt-float-icon rt-float-icon--green"><i class="fas fa-circle-check"></i></div>
              <div>
                <div class="rt-float-label">Application Approved</div>
                <div class="rt-float-sub">Juan dela Cruz · 2 min ago</div>
              </div>
            </div>
            <div class="rt-dashboard-mock">
              <div class="rt-mock-bar">
                <span class="rt-mock-dot red"></span>
                <span class="rt-mock-dot yellow"></span>
                <span class="rt-mock-dot green"></span>
                <span class="rt-mock-title">HR Dashboard — T&amp;N Company</span>
              </div>
              <div class="rt-mock-body">
                <div class="rt-mock-stat-row">
                  <div class="rt-mock-stat rt-mock-stat--blue"><div class="rt-mock-num">48</div><div class="rt-mock-lbl">Total</div></div>
                  <div class="rt-mock-stat rt-mock-stat--yellow"><div class="rt-mock-num">12</div><div class="rt-mock-lbl">Pending</div></div>
                  <div class="rt-mock-stat rt-mock-stat--green"><div class="rt-mock-num">29</div><div class="rt-mock-lbl">Approved</div></div>
                  <div class="rt-mock-stat rt-mock-stat--red"><div class="rt-mock-num">7</div><div class="rt-mock-lbl">Rejected</div></div>
                </div>
                <div class="rt-mock-list">
                  <div class="rt-mock-row"><span class="rt-mock-code">APP-001</span><span class="rt-mock-name">Maria Santos</span><span class="rt-badge-pending">Pending</span></div>
                  <div class="rt-mock-row"><span class="rt-mock-code">APP-002</span><span class="rt-mock-name">Jose Reyes</span><span class="rt-badge-approved">Approved</span></div>
                  <div class="rt-mock-row"><span class="rt-mock-code">APP-003</span><span class="rt-mock-name">Ana Lim</span><span class="rt-badge-review">For Review</span></div>
                </div>
              </div>
            </div>
            <div class="rt-float-card rt-float-card--bottom">
              <div class="rt-float-icon rt-float-icon--blue"><i class="fas fa-shield-halved"></i></div>
              <div>
                <div class="rt-float-label">Secure Document Upload</div>
                <div class="rt-float-sub">resume.pdf · Verified</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- ABOUT COMPANY -->
  <section class="rt-about">
    <div class="container">
      <div class="row align-items-center g-5">
        <div class="col-lg-6">
          <p class="rt-section-tag">About T&amp;N Company</p>
          <h2 class="rt-section-title">Technology built for tomorrow</h2>
          <p class="rt-about-text">T&N Company is a Philippine-based technology firm specializing in software development, digital infrastructure, and IT consulting. We partner with businesses to design, build, and scale digital products that matter.</p>
          <p class="rt-about-text mt-3">We believe our people are our greatest asset. That's why we invest in talent, foster an inclusive culture, and build systems that make great work possible — starting with how we hire.</p>
          <div class="d-flex flex-wrap gap-3 mt-4">
            <div class="rt-about-pill"><i class="fas fa-code me-2"></i>Software Development</div>
            <div class="rt-about-pill"><i class="fas fa-server me-2"></i>IT Infrastructure</div>
            <div class="rt-about-pill"><i class="fas fa-chart-line me-2"></i>Digital Consulting</div>
            <div class="rt-about-pill"><i class="fas fa-cloud me-2"></i>Cloud Solutions</div>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="row g-3">
            <div class="col-6"><div class="rt-about-card rt-about-card--blue"><i class="fas fa-users rt-about-card-icon"></i><div class="rt-about-card-num">200+</div><div class="rt-about-card-label">Team Members</div></div></div>
            <div class="col-6"><div class="rt-about-card rt-about-card--green"><i class="fas fa-briefcase rt-about-card-icon"></i><div class="rt-about-card-num">8+</div><div class="rt-about-card-label">Years in Business</div></div></div>
            <div class="col-6"><div class="rt-about-card rt-about-card--amber"><i class="fas fa-handshake rt-about-card-icon"></i><div class="rt-about-card-num">150+</div><div class="rt-about-card-label">Projects Delivered</div></div></div>
            <div class="col-6"><div class="rt-about-card rt-about-card--purple"><i class="fas fa-star rt-about-card-icon"></i><div class="rt-about-card-num">4.9★</div><div class="rt-about-card-label">Employer Rating</div></div></div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- FEATURES -->
  <section class="rt-features">
    <div class="container">
      <div class="rt-section-header text-center mb-5">
        <p class="rt-section-tag">How Our Hiring Works</p>
        <h2 class="rt-section-title">Every role, fully covered</h2>
      </div>
      <div class="row g-4">
        <div class="col-md-4">
          <div class="rt-feature-card">
            <div class="rt-feature-icon rt-feature-icon--blue"><i class="fas fa-user-tie"></i></div>
            <h3>Applicants</h3>
            <p>Browse open positions posted by our HR team. Apply with your resume and cover letter — track your application status in real-time from your personal dashboard.</p>
            <a href="<?= base_url('signup') ?>" class="rt-feature-link">Create Account <i class="fas fa-arrow-right ms-1"></i></a>
          </div>
        </div>
        <div class="col-md-4">
          <div class="rt-feature-card">
            <div class="rt-feature-icon rt-feature-icon--green"><i class="fas fa-users-gear"></i></div>
            <h3>HR Staff</h3>
            <p>Post job openings with full details and optional images. Review applications, update statuses, and leave internal notes — all in one streamlined dashboard.</p>
            <a href="<?= base_url('login') ?>" class="rt-feature-link">HR Login <i class="fas fa-arrow-right ms-1"></i></a>
          </div>
        </div>
        <div class="col-md-4">
          <div class="rt-feature-card">
            <div class="rt-feature-icon rt-feature-icon--amber"><i class="fas fa-chart-line"></i></div>
            <h3>Admin</h3>
            <p>Full oversight with analytics, audit logs, and HR account management. Monitor job postings and application flow across every department from one place.</p>
            <a href="<?= base_url('login') ?>" class="rt-feature-link">Admin Login <i class="fas fa-arrow-right ms-1"></i></a>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- PROCESS -->
  <section class="rt-process">
    <div class="container">
      <div class="rt-section-header text-center mb-5">
        <p class="rt-section-tag">How It Works</p>
        <h2 class="rt-section-title">Three steps to your new role</h2>
      </div>
      <div class="row g-4 justify-content-center">
        <div class="col-md-3 text-center">
          <div class="rt-step"><span class="rt-step-num">01</span></div>
          <h4 class="mt-3 mb-2">Create Account</h4>
          <p class="rt-step-desc">Sign up as an applicant and complete your profile with your personal and contact details.</p>
        </div>
        <div class="col-md-1 d-none d-md-flex align-items-center justify-content-center">
          <i class="fas fa-chevron-right rt-step-arrow"></i>
        </div>
        <div class="col-md-3 text-center">
          <div class="rt-step"><span class="rt-step-num">02</span></div>
          <h4 class="mt-3 mb-2">Browse &amp; Apply</h4>
          <p class="rt-step-desc">View jobs posted by T&N HR. Select the role you want and submit your resume and cover letter.</p>
        </div>
        <div class="col-md-1 d-none d-md-flex align-items-center justify-content-center">
          <i class="fas fa-chevron-right rt-step-arrow"></i>
        </div>
        <div class="col-md-3 text-center">
          <div class="rt-step"><span class="rt-step-num">03</span></div>
          <h4 class="mt-3 mb-2">Track &amp; Hear Back</h4>
          <p class="rt-step-desc">Monitor your application in real-time. Get notified the moment our HR team makes a decision.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- CTA -->
  <section class="rt-cta">
    <div class="container text-center">
      <h2 class="rt-cta-title">Ready to join T&amp;N Company?</h2>
      <p class="rt-cta-sub">Browse our open positions and submit your application — fully paperless, fully online.</p>
      <a href="<?= base_url('signup') ?>" class="rt-btn rt-btn-primary rt-btn-lg mt-3">
        <i class="fas fa-rocket me-2"></i>Apply Now
      </a>
    </div>
  </section>

  <!-- FOOTER -->
  <footer class="rt-footer">
    <div class="container">
      <div class="rt-footer-inner">
        <div class="rt-footer-brand">
          <div class="rt-brand"><span class="rt-brand-accent">T&amp;N</span> Company</div>
          <p class="rt-footer-tagline">Technology built for tomorrow.</p>
        </div>
        <div class="rt-footer-links">
          <a href="<?= base_url('login') ?>" class="rt-footer-link">Login</a>
          <a href="<?= base_url('signup') ?>" class="rt-footer-link">Register</a>
        </div>
      </div>
      <div class="rt-footer-bottom">
        <p class="rt-footer-copy">© 2025 T&amp;N Company · Careers Portal powered by RegisTrack · Famini &amp; Pacalioga · BSIT–2C</p>
      </div>
    </div>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
