<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<?php $pageTitle = 'Sign In — T&N Company Careers'; ?>

<nav class="rt-nav">
  <div class="container d-flex align-items-center justify-content-between">
    <a href="<?= base_url('/') ?>" class="d-flex align-items-center gap-2 text-decoration-none">
      <div class="rt-brand"><span class="rt-brand-accent">T&amp;N</span> Company</div>
      <span class="rt-nav-divider">|</span>
      <span class="rt-nav-sub">Careers</span>
    </a>
    <a href="<?= base_url('signup') ?>" class="rt-btn rt-btn-outline rt-btn-sm">Create Account</a>
  </div>
</nav>

<div class="rt-auth-wrap">
  <div class="rt-auth-card">

    <div class="rt-auth-header">
      <div class="mb-3">
        <div style="width:52px;height:52px;background:#eff6ff;border-radius:14px;display:flex;align-items:center;justify-content:center;margin:0 auto;">
          <i class="fas fa-right-to-bracket" style="font-size:1.3rem;color:var(--accent);"></i>
        </div>
      </div>
      <h1>Welcome back</h1>
      <p>Sign in to your T&amp;N Company Careers account</p>
    </div>

    <?php if (session()->getFlashdata('error')): ?>
      <div class="rt-alert rt-alert-error show">
        <i class="fas fa-exclamation-circle me-2"></i><?= esc(session()->getFlashdata('error')) ?>
      </div>
    <?php endif; ?>

    <?php if (session()->getFlashdata('success')): ?>
      <div class="rt-alert rt-alert-success show">
        <i class="fas fa-check-circle me-2"></i><?= esc(session()->getFlashdata('success')) ?>
      </div>
    <?php endif; ?>

    <?php /* CSRF field is REQUIRED for every POST form in CI4 */ ?>
    <form id="loginForm" method="POST" action="<?= base_url('login') ?>" novalidate>
      <?= csrf_field() ?>

      <div class="rt-field-group">
        <label class="rt-label" for="email">Email Address <span class="rt-required">*</span></label>
        <div class="rt-input-wrap">
          <i class="fas fa-envelope rt-input-icon"></i>
          <input id="email" name="email" type="email" class="rt-input"
            placeholder="you@example.com" value="<?= esc(old('email')) ?>"
            data-required="true" data-type="email" data-label="Email" />
        </div>
        <span class="rt-field-error"></span>
      </div>

      <div class="rt-field-group">
        <label class="rt-label" for="password">Password <span class="rt-required">*</span></label>
        <div class="rt-input-wrap">
          <i class="fas fa-lock rt-input-icon"></i>
          <input id="password" name="password" type="password" class="rt-input"
            placeholder="Your password"
            data-required="true" data-label="Password" />
          <button type="button" class="rt-pw-toggle" onclick="togglePw('password', this)">
            <i class="fas fa-eye"></i>
          </button>
        </div>
        <span class="rt-field-error"></span>
      </div>

      <button type="submit" class="rt-btn rt-btn-primary w-100 mt-2" id="loginBtn">
        <i class="fas fa-right-to-bracket me-2"></i>Sign In
      </button>

      <div class="rt-divider mt-3"><span>or</span></div>

      <p class="text-center" style="font-size:.83rem;color:var(--mid);">
        Don't have an account? <a href="<?= base_url('signup') ?>">Apply now →</a>
      </p>
    </form>

  </div>
</div>

<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script src="<?= base_url('assets/js/validation.js') ?>"></script>
<script>
  Validate.bindLive($('#loginForm'));

  // Client-side pre-validation before form submits to server
  $('#loginForm').on('submit', function(e) {
    if (!Validate.validateForm($(this))) {
      e.preventDefault();
    }
  });

  function togglePw(id, btn) {
    const inp = document.getElementById(id);
    const ico = btn.querySelector('i');
    inp.type = inp.type === 'password' ? 'text' : 'password';
    ico.classList.toggle('fa-eye');
    ico.classList.toggle('fa-eye-slash');
  }
</script>
<?= $this->endSection() ?>
