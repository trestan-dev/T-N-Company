<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<?php $pageTitle = 'Create Account — T&N Company Careers'; ?>

<nav class="rt-nav">
  <div class="container d-flex align-items-center justify-content-between">
    <a href="<?= base_url('/') ?>" class="d-flex align-items-center gap-2 text-decoration-none">
      <div class="rt-brand"><span class="rt-brand-accent">T&amp;N</span> Company</div>
      <span class="rt-nav-divider">|</span>
      <span class="rt-nav-sub">Careers</span>
    </a>
    <a href="<?= base_url('login') ?>" class="rt-btn rt-btn-ghost rt-btn-sm">
      Already have an account? Sign In
    </a>
  </div>
</nav>

<div class="rt-auth-wrap" style="padding: 40px 16px;">
  <div class="rt-auth-card rt-auth-card--wide">

    <div class="rt-auth-header">
      <div class="mb-3">
        <div style="width:52px;height:52px;background:#f0fdf4;border-radius:14px;display:flex;align-items:center;justify-content:center;margin:0 auto;">
          <i class="fas fa-user-plus" style="font-size:1.3rem;color:var(--green);"></i>
        </div>
      </div>
      <h1>Create your account</h1>
      <p>Join T&amp;N Company's talent pool — it only takes a minute</p>
    </div>

    <?php if (session()->getFlashdata('error')): ?>
      <div class="rt-alert rt-alert-error show">
        <i class="fas fa-exclamation-circle me-2"></i><?= esc(session()->getFlashdata('error')) ?>
      </div>
    <?php endif; ?>

    <?php if (session()->getFlashdata('success')): ?>
      <div class="rt-alert rt-alert-success show">
        <i class="fas fa-check-circle me-2"></i><?= esc(session()->getFlashdata('success')) ?>
      </div>
    <?php endif; ?>

    <?php /* CSRF field is REQUIRED — CI4 rejects POST without it (403) */ ?>
    <form id="signupForm" method="POST" action="<?= base_url('signup') ?>" novalidate>
      <?= csrf_field() ?>

      <div class="row g-3">

        <div class="col-md-6">
          <div class="rt-field-group mb-0">
            <label class="rt-label" for="first">First Name <span class="rt-required">*</span></label>
            <input id="first" name="first" type="text" class="rt-input"
              placeholder="Juan" value="<?= esc(old('first')) ?>"
              data-required="true" data-type="name" data-label="First name" data-min="2" data-max="50" />
            <span class="rt-field-error"></span>
          </div>
        </div>

        <div class="col-md-6">
          <div class="rt-field-group mb-0">
            <label class="rt-label" for="last">Last Name <span class="rt-required">*</span></label>
            <input id="last" name="last" type="text" class="rt-input"
              placeholder="dela Cruz" value="<?= esc(old('last')) ?>"
              data-required="true" data-type="name" data-label="Last name" data-min="2" data-max="50" />
            <span class="rt-field-error"></span>
          </div>
        </div>

        <div class="col-md-6">
          <div class="rt-field-group mb-0">
            <label class="rt-label" for="regEmail">Email Address <span class="rt-required">*</span></label>
            <div class="rt-input-wrap">
              <i class="fas fa-envelope rt-input-icon"></i>
              <input id="regEmail" name="email" type="email" class="rt-input"
                placeholder="juan@example.com" value="<?= esc(old('email')) ?>"
                data-required="true" data-type="email" data-label="Email" />
            </div>
            <span class="rt-field-error"></span>
          </div>
        </div>

        <div class="col-md-6">
          <div class="rt-field-group mb-0">
            <label class="rt-label" for="phone">Phone Number <span class="rt-optional">(optional)</span></label>
            <div class="rt-input-wrap">
              <i class="fas fa-phone rt-input-icon"></i>
              <input id="phone" name="phone" type="text" class="rt-input"
                placeholder="+63 9XX XXX XXXX" value="<?= esc(old('phone')) ?>"
                data-type="phone" data-label="Phone" />
            </div>
            <span class="rt-field-error"></span>
          </div>
        </div>

        <div class="col-md-6">
          <div class="rt-field-group mb-0">
            <label class="rt-label" for="regPw">Password <span class="rt-required">*</span></label>
            <div class="rt-input-wrap">
              <i class="fas fa-lock rt-input-icon"></i>
              <input id="regPw" name="password" type="password" class="rt-input"
                placeholder="Min. 8 characters"
                data-required="true" data-type="password" data-label="Password" />
              <button type="button" class="rt-pw-toggle" onclick="togglePw('regPw', this)">
                <i class="fas fa-eye"></i>
              </button>
            </div>
            <div class="rt-pw-strength" id="pwStrength" style="display:none;">
              <div class="rt-pw-bar"><div class="rt-pw-fill" id="pwBar"></div></div>
              <span class="rt-pw-label" id="pwLabel"></span>
            </div>
            <span class="rt-field-error"></span>
          </div>
        </div>

        <div class="col-md-6">
          <div class="rt-field-group mb-0">
            <label class="rt-label" for="regPwConfirm">Confirm Password <span class="rt-required">*</span></label>
            <div class="rt-input-wrap">
              <i class="fas fa-lock rt-input-icon"></i>
              <input id="regPwConfirm" name="password_confirm" type="password" class="rt-input"
                placeholder="Repeat your password"
                data-required="true" data-label="Confirm password" data-match="#regPw" />
              <button type="button" class="rt-pw-toggle" onclick="togglePw('regPwConfirm', this)">
                <i class="fas fa-eye"></i>
              </button>
            </div>
            <span class="rt-field-error"></span>
          </div>
        </div>

      </div>

      <div class="mt-4 p-3" style="background:var(--chalk);border-radius:var(--r-sm);border:1px solid var(--border);font-size:.8rem;color:var(--mid);">
        <i class="fas fa-shield-halved me-2" style="color:var(--accent);"></i>
        Your information is stored securely in our database. After registering, you can browse open positions and submit your application.
      </div>

      <button type="submit" class="rt-btn rt-btn-primary w-100 mt-3" id="signupBtn">
        <i class="fas fa-user-plus me-2"></i>Create Account
      </button>

      <p class="text-center mt-3" style="font-size:.82rem;color:var(--mid);">
        Already have an account? <a href="<?= base_url('login') ?>">Sign in →</a>
      </p>
    </form>

  </div>
</div>

<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script src="<?= base_url('assets/js/validation.js') ?>"></script>
<script>
  Validate.bindLive($('#signupForm'));
  Validate.initPasswordStrength('regPw', 'pwBar', 'pwLabel');

  // Client-side pre-validation — actual validation also happens server-side
  $('#signupForm').on('submit', function(e) {
    if (!Validate.validateForm($(this))) {
      e.preventDefault();
    }
  });

  function togglePw(id, btn) {
    const inp = document.getElementById(id);
    const ico = btn.querySelector('i');
    inp.type = inp.type === 'password' ? 'text' : 'password';
    ico.classList.toggle('fa-eye');
    ico.classList.toggle('fa-eye-slash');
  }
</script>
<?= $this->endSection() ?>
