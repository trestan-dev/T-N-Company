<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>My Dashboard — T&N Company Careers</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600;700;800&family=DM+Serif+Display:ital@0;1&display=swap" rel="stylesheet" />
  <link href="<?= base_url('assets/css/style.css') ?>" rel="stylesheet" />
</head>
<body>

  <?php
  // PHP session user — passed from DashboardController, used to inject into JS safely.
  // esc() + json_encode() together prevent XSS.
  $userJson = json_encode([
      'id'    => $user['id'],
      'role'  => $user['role'],
      'first' => $user['first'],
      'last'  => $user['last'],
      'email' => $user['email'],
  ]);
  ?>

  <div id="topbarMount"></div>

  <div class="rt-page-wrap">
    <div class="container">
      <div class="rt-page-header">
        <div>
          <h1 class="rt-page-title" id="greetingTitle">My Dashboard</h1>
          <p class="rt-page-sub">Browse open positions and track your T&amp;N Company applications.</p>
        </div>
      </div>

      <!-- Flash messages from PHP redirects -->
      <?php if (session()->getFlashdata('success')): ?>
        <div class="rt-alert rt-alert-success show mb-3">
          <i class="fas fa-check-circle me-2"></i><?= esc(session()->getFlashdata('success')) ?>
        </div>
      <?php endif; ?>
      <?php if (session()->getFlashdata('error')): ?>
        <div class="rt-alert rt-alert-error show mb-3">
          <i class="fas fa-exclamation-circle me-2"></i><?= esc(session()->getFlashdata('error')) ?>
        </div>
      <?php endif; ?>

      <!-- ✅ JOB OFFER NOTIFICATION BANNER -->
      <div id="offerNotification" class="rt-alert rt-alert-success show mb-3" style="display:none; border-left:4px solid var(--green);">
        <div class="d-flex align-items-center gap-3">
          <i class="fas fa-envelope-open-text fa-2x" style="color:var(--green);"></i>
          <div style="flex:1;">
            <div style="font-weight:700; font-size:1rem;">🎉 You have received a Job Offer!</div>
            <div style="font-size:.9rem;">Please review and respond to the offer below.</div>
          </div>
          <button class="rt-btn rt-btn-primary rt-btn-sm" onclick="document.getElementById('tab-btn-apps').click();">
            <i class="fas fa-arrow-right me-1"></i>View Offer
          </button>
        </div>
      </div>

      <div class="row g-3 mb-4" id="statRow"></div>

      <div class="rt-tabs">
        <button class="rt-tab active" id="tab-btn-jobs" onclick="switchTab('jobs',this)">
          <i class="fas fa-briefcase me-2"></i>Open Positions
        </button>
        <button class="rt-tab" id="tab-btn-apps" onclick="switchTab('apps',this)">
          <i class="fas fa-file-lines me-2"></i>My Applications
        </button>
      </div>

      <!-- Open Positions -->
      <div id="tab-jobs">
        <div class="rt-card">
          <div class="rt-card-header">
            <div class="rt-card-header-left">
              <div class="rt-section-num"><i class="fas fa-briefcase"></i></div>
              <h2 class="rt-card-title">Open Positions</h2>
            </div>
            <div class="d-flex gap-2 align-items-center">
              <span class="rt-muted" id="jobsResultCount"></span>
              <div id="jobsViewToggleMount"></div>
            </div>
          </div>
          <div id="jobsFilterBarMount"></div>
          <input type="hidden" id="appjobs_viewmode" value="cards" />
          <div id="jobsContainer" class="p-3"></div>
        </div>
      </div>

      <!-- My Applications -->
      <div id="tab-apps" style="display:none;">
        <div class="rt-card">
          <div class="rt-card-header">
            <div class="rt-card-header-left">
              <div class="rt-section-num"><i class="fas fa-list"></i></div>
              <h2 class="rt-card-title">My Applications</h2>
            </div>
            <span class="rt-muted" id="appResultCount"></span>
          </div>
          <div id="appFilterBarMount"></div>
          <div class="rt-table-wrap">
            <table class="rt-table">
              <thead>
                <tr>
                  <th>Code</th>
                  <th>Position</th>
                  <th>Department</th>
                  <th>Type</th>
                  <th>Status</th>
                  <th>Submitted</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody id="appTbody">
                <tr><td colspan="7" class="text-center py-4" style="color:var(--mid);">Loading…</td></tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Application Detail Modal -->
  <div class="modal fade" id="detailModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title"><i class="fas fa-file-lines me-2"></i>Application Detail</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body" id="detailBody"></div>
        <div class="modal-footer"><button class="rt-btn rt-btn-outline" data-bs-dismiss="modal">Close</button></div>
      </div>
    </div>
  </div>

  <!-- Apply Modal — form POSTs to CI4 ApplicationController::apply() -->
  <div class="modal fade" id="applyModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title"><i class="fas fa-file-pen me-2"></i>Apply — <span id="applyJobTitle"></span></h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <div id="applyAlert" class="rt-alert"></div>
          <div id="applyJobBanner" class="rt-job-apply-banner mb-4"></div>
          <div class="rt-progress-steps mb-4">
            <div class="rt-progress-step active" id="step-ind-1"><span class="rt-progress-step-num">1</span>Resume</div>
            <div class="rt-progress-step" id="step-ind-2"><span class="rt-progress-step-num">2</span>Review</div>
          </div>
          <!-- enctype="multipart/form-data" is required for file uploads -->
          <form id="applyForm" method="POST" enctype="multipart/form-data" novalidate>
            <?= csrf_field() ?>
            <input type="hidden" id="applyJobId" name="job_id" value="" />

            <div id="step1">
              <div class="rt-field-group">
                <label class="rt-label">Resume (PDF only) <span class="rt-required">*</span></label>
                <div class="rt-upload-zone" id="uploadZone" onclick="document.getElementById('resumeFile').click()">
                  <div class="rt-upload-icon"><i class="fas fa-file-pdf" style="color:var(--red);"></i></div>
                  <div class="rt-upload-label">Click to upload your PDF resume</div>
                  <div class="rt-upload-hint">PDF only — max 5 MB</div>
                </div>
                <!-- name="resume" matches $this->request->getFile('resume') in ApplicationController -->
                <input type="file" id="resumeFile" name="resume" accept=".pdf,application/pdf" style="display:none;" />
                <div id="fileChips" class="mt-2"></div>
                <span class="rt-field-error" id="resumeError"></span>
              </div>
              <div class="rt-field-group">
                <label class="rt-label" for="coverLetter">Cover Letter <span class="rt-optional">(optional)</span></label>
                <textarea id="coverLetter" name="cover_letter" class="rt-input rt-textarea"
                  placeholder="Tell us why you're the right fit for this role at T&N Company…"></textarea>
                <span class="rt-hint" id="clCount">0 / 2000 characters</span>
              </div>
            </div>

            <div id="step2" style="display:none;">
              <div class="rt-card mb-3" style="background:var(--chalk);">
                <div class="rt-card-body">
                  <h5 style="font-size:.9rem;margin-bottom:12px;">
                    <i class="fas fa-clipboard-check me-2" style="color:var(--accent);"></i>Review Your Application
                  </h5>
                  <div class="rt-detail-grid" id="reviewGrid"></div>
                </div>
              </div>
              <div class="p-3" style="background:#fffbeb;border-radius:var(--r-sm);border:1px solid #fde68a;font-size:.82rem;color:#92400e;">
                <i class="fas fa-triangle-exclamation me-2"></i>
                Once submitted, you cannot edit this application. You can only apply again after this one is resolved.
              </div>
            </div>
          </form>
        </div>
        <div class="modal-footer">
          <button class="rt-btn rt-btn-outline" id="prevBtn" style="display:none;" onclick="applyStep(-1)">
            <i class="fas fa-arrow-left me-1"></i>Back
          </button>
          <button class="rt-btn rt-btn-primary" id="nextBtn" onclick="applyStep(1)">
            Next <i class="fas fa-arrow-right ms-1"></i>
          </button>
        </div>
      </div>
    </div>
  </div>

  <!-- Job Detail Modal -->
  <div class="modal fade" id="jobDetailModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title"><i class="fas fa-briefcase me-2"></i>Job Details</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body" id="jobDetailBody"></div>
        <div class="modal-footer" id="jobDetailFooter"></div>
      </div>
    </div>
  </div>

  <!-- PDF Viewer Modal — loads resume via /api/resumes/{appCode} -->
  <div class="modal fade" id="pdfModal" tabindex="-1">
    <div class="modal-dialog modal-xl" style="max-width:900px;">
      <div class="modal-content" style="height:90vh;display:flex;flex-direction:column;">
        <div class="modal-header">
          <h5 class="modal-title">
            <i class="fas fa-file-pdf me-2" style="color:var(--red);"></i>
            <span id="pdfModalTitle">Resume Preview</span>
          </h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body p-0" style="flex:1;overflow:hidden;">
          <div id="pdfViewerBody" style="width:100%;height:100%;"></div>
        </div>
      </div>
    </div>
  </div>

  <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script src="<?= base_url('assets/js/validation.js') ?>"></script>
  <script>
    const BASE_URL = "<?= base_url('/') ?>";
  </script>
  <script src="<?= base_url('assets/js/dashboard.js') ?>"></script>
  <script>
    // USER is injected from PHP session — replaces Auth.requireRole('applicant')
    // AuthFilter already blocked this page if user is not logged in as applicant.
    const USER = <?= $userJson ?>;

    document.getElementById('topbarMount').innerHTML = initTopbar(USER);
    document.getElementById('greetingTitle').textContent = `Welcome, ${USER.first}!`;

    const ACTIVE_STATUSES = ['Submitted','Under Review','Phone Screen','Interview Scheduled','Final Interview','Job Offer'];

    /* ── Tabs ── */
    function switchTab(name, el) {
      document.querySelectorAll('.rt-tab').forEach(t => t.classList.remove('active'));
      el.classList.add('active');
      document.getElementById('tab-jobs').style.display = name === 'jobs' ? 'block' : 'none';
      document.getElementById('tab-apps').style.display = name === 'apps' ? 'block' : 'none';
      if (name === 'apps') loadMyApplications();
    }

    /* ── Stats (fetched from API) ── */
    async function renderStats() {
      const [statsRes, jobsRes, appsRes] = await Promise.all([
        fetch('<?= base_url('api/applications/stats') ?>'),
        fetch('<?= base_url('api/jobs') ?>'),
        fetch('<?= base_url('api/applications') ?>'),
      ]);
      const stats = await statsRes.json();
      const jobs  = await jobsRes.json();
      const apps  = await appsRes.json();

      // ✅ SHOW JOB OFFER NOTIFICATION IF ANY APPLICATION HAS STATUS "Job Offer"
      const hasPendingOffer = apps.some(a => a.status === 'Job Offer');
      if (hasPendingOffer) {
        document.getElementById('offerNotification').style.display = 'block';
      }

      document.getElementById('statRow').innerHTML = `
        <div class="col-6 col-md-3"><div class="rt-stat-card rt-stat-card--blue">
          <div class="rt-stat-icon rt-stat-icon--blue"><i class="fas fa-briefcase"></i></div>
          <div class="rt-stat-num">${jobs.length}</div><div class="rt-stat-label">Open Positions</div>
        </div></div>
        <div class="col-6 col-md-3"><div class="rt-stat-card rt-stat-card--yellow">
          <div class="rt-stat-icon rt-stat-icon--yellow"><i class="fas fa-file-lines"></i></div>
          <div class="rt-stat-num">${stats.total}</div><div class="rt-stat-label">My Applications</div>
        </div></div>
        <div class="col-6 col-md-3"><div class="rt-stat-card rt-stat-card--purple">
          <div class="rt-stat-icon rt-stat-icon--purple"><i class="fas fa-hourglass-half"></i></div>
          <div class="rt-stat-num">${stats.in_process}</div><div class="rt-stat-label">In Progress</div>
        </div></div>
        <div class="col-6 col-md-3"><div class="rt-stat-card rt-stat-card--green">
          <div class="rt-stat-icon rt-stat-icon--green"><i class="fas fa-user-check"></i></div>
          <div class="rt-stat-num">${stats.hired}</div><div class="rt-stat-label">Hired</div>
        </div></div>`;
    }

    /* ── Jobs tab (fetch from API) ── */
    async function initJobsTab() {
      document.getElementById('jobsFilterBarMount').innerHTML = buildFilterBar('appjobs', {
        searchPlaceholder: 'Search title, department…',
        filters: [
          { id: 'appjobs_dept', placeholder: 'All Departments', width: '155px',
            options: ['IT Department','Human Resources','Finance','Operations','Marketing','Legal','Administration'] },
          { id: 'appjobs_type', placeholder: 'All Types', width: '130px',
            options: ['Full-Time','Part-Time','Contract','Internship'] },
          { id: 'appjobs_arr',  placeholder: 'All Arrangements', width: '150px',
            options: ['On-site','Remote','Hybrid'] },
        ],
        sorts: [
          { value: 'created_at|desc', label: 'Newest first' },
          { value: 'created_at|asc',  label: 'Oldest first' },
          { value: 'title|asc',       label: 'A → Z (title)' },
          { value: 'title|desc',      label: 'Z → A (title)' },
        ],
        onChangeFn: 'applyJobFilters',
      });
      document.getElementById('jobsViewToggleMount').innerHTML = buildViewToggle('appjobs_viewmode', 'applyJobFilters');
      await applyJobFilters();
    }

    async function applyJobFilters() {
      const { search, sortBy, sortDir, filters } = getFilterBarValues('appjobs');
      const params = new URLSearchParams({
        search, sort: sortBy || 'created_at', dir: sortDir || 'desc',
        dept: filters['appjobs_dept'] || '',
        type: filters['appjobs_type'] || '',
        arrangement: filters['appjobs_arr'] || '',
      });
      const res  = await fetch(`<?= base_url('api/jobs') ?>?${params}`);
      const jobs = await res.json();

      document.getElementById('jobsResultCount').textContent = jobs.length + ' position(s)';
      const mode = document.getElementById('appjobs_viewmode').value;
      document.getElementById('jobsContainer').innerHTML =
        jobs.length ? renderJobsCards(jobs, mode) : '<div class="rt-empty-state"><i class="fas fa-briefcase"></i><p>No open positions match your filters.</p></div>';
    }

    function renderJobsCards(jobs, mode) {
      if (mode === 'list') {
        return `<div class="rt-table-wrap"><table class="rt-table"><thead><tr>
          <th>Code</th><th>Title</th><th>Dept</th><th>Type</th><th>Arrangement</th><th>Actions</th>
        </tr></thead><tbody>` + jobs.map(j => `<tr>
          <td><code style="font-size:.82rem;">${j.job_code}</code></td>
          <td style="font-weight:600;">${j.title}</td>
          <td>${j.department}</td>
          <td><span class="rt-badge rt-badge-for-review">${j.employment_type}</span></td>
          <td>${j.arrangement}</td>
          <td><button class="rt-btn rt-btn-outline rt-btn-sm me-1" onclick="viewJobDetail(${JSON.stringify(j).replace(/"/g,'&quot;')})">
            <i class="fas fa-eye me-1"></i>View</button>
            <button class="rt-btn rt-btn-primary rt-btn-sm" onclick="openApply(${JSON.stringify(j).replace(/"/g,'&quot;')})">
            <i class="fas fa-paper-plane me-1"></i>Apply</button></td>
        </tr>`).join('') + '</tbody></table></div>';
      }
      return '<div class="row g-3">' + jobs.map(j => `
        <div class="col-md-6 col-lg-4">
          <div class="rt-job-card">
            ${j.image_url ? `<div class="rt-job-card-img" style="background-image:url('${j.image_url}')"></div>` : ''}
            <div class="rt-job-card-body">
              <div class="d-flex align-items-start justify-content-between gap-2 mb-2">
                <div>
                  <div class="rt-job-card-code">${j.job_code}</div>
                  <h3 class="rt-job-card-title">${j.title}</h3>
                </div>
                <span class="rt-badge rt-badge-active" style="flex-shrink:0;">Active</span>
              </div>
              <div class="rt-job-card-meta">
                <span><i class="fas fa-building me-1"></i>${j.department}</span>
                <span><i class="fas fa-clock me-1"></i>${j.employment_type}</span>
                <span><i class="fas fa-map-pin me-1"></i>${j.arrangement}</span>
                ${j.salary_range ? `<span><i class="fas fa-peso-sign me-1"></i>${j.salary_range}</span>` : ''}
              </div>
              ${j.description ? `<p class="rt-job-card-desc">${j.description.substring(0, 100)}${j.description.length > 100 ? '…' : ''}</p>` : ''}
              <div class="rt-job-card-footer">
                <button class="rt-btn rt-btn-outline rt-btn-sm" onclick="viewJobDetail(${JSON.stringify(j).replace(/"/g,'&quot;')})">
                  <i class="fas fa-eye me-1"></i>Details
                </button>
                <button class="rt-btn rt-btn-primary rt-btn-sm" onclick="openApply(${JSON.stringify(j).replace(/"/g,'&quot;')})">
                  <i class="fas fa-paper-plane me-1"></i>Apply
                </button>
              </div>
            </div>
          </div>
        </div>`).join('') + '</div>';
    }

    function viewJobDetail(job) {
      document.getElementById('jobDetailBody').innerHTML = `
        ${job.image_url ? `<img src="${job.image_url}" style="width:100%;max-height:200px;object-fit:cover;border-radius:var(--r) var(--r) 0 0;margin:-16px -16px 16px;" />` : ''}
        <div class="rt-detail-grid mb-3">
          <div class="rt-detail-item"><label>Job Code</label><span><code>${job.job_code}</code></span></div>
          <div class="rt-detail-item"><label>Department</label><span>${job.department}</span></div>
          <div class="rt-detail-item"><label>Type</label><span>${job.employment_type}</span></div>
          <div class="rt-detail-item"><label>Arrangement</label><span>${job.arrangement}</span></div>
          ${job.salary_range ? `<div class="rt-detail-item"><label>Salary Range</label><span>${job.salary_range}</span></div>` : ''}
        </div>
        ${job.description ? `<div class="mb-3"><strong style="font-size:.8rem;text-transform:uppercase;color:var(--mid);letter-spacing:.05em;">Description</strong><p style="margin-top:6px;font-size:.88rem;line-height:1.7;">${job.description}</p></div>` : ''}
        ${job.requirements ? `<div><strong style="font-size:.8rem;text-transform:uppercase;color:var(--mid);letter-spacing:.05em;">Requirements</strong><p style="margin-top:6px;font-size:.88rem;line-height:1.7;">${job.requirements}</p></div>` : ''}`;

      document.getElementById('jobDetailFooter').innerHTML = `
        <button class="rt-btn rt-btn-outline" data-bs-dismiss="modal">Close</button>
        <button class="rt-btn rt-btn-primary" onclick="openApply(${JSON.stringify(job).replace(/"/g,'&quot;')});bootstrap.Modal.getInstance(document.getElementById('jobDetailModal')).hide();">
          <i class="fas fa-paper-plane me-1"></i>Apply Now
        </button>`;
      new bootstrap.Modal(document.getElementById('jobDetailModal')).show();
    }

    /* ── Apply Modal ── */
    let currentApplyJob = null, applyStep_ = 1;

    function openApply(job) {
      currentApplyJob = job;
      applyStep_ = 1;
      document.getElementById('applyJobTitle').textContent = job.title;
      document.getElementById('applyJobId').value = job.id;
      document.getElementById('coverLetter').value = '';
      document.getElementById('fileChips').innerHTML = '';
      document.getElementById('resumeFile').value = '';
      document.getElementById('resumeError').textContent = '';
      document.getElementById('step1').style.display = '';
      document.getElementById('step2').style.display = 'none';
      document.getElementById('prevBtn').style.display = 'none';
      document.getElementById('nextBtn').textContent = 'Next ';
      document.getElementById('nextBtn').innerHTML = 'Next <i class="fas fa-arrow-right ms-1"></i>';
      Validate.hideAlert('applyAlert');

      document.getElementById('applyJobBanner').innerHTML = `
        <div class="d-flex align-items-center gap-3 p-3" style="background:var(--chalk);border-radius:var(--r-sm);border:1px solid var(--border);">
          <div class="rt-feature-icon rt-feature-icon--blue" style="flex-shrink:0;width:44px;height:44px;font-size:1.1rem;">
            <i class="fas fa-briefcase"></i>
          </div>
          <div>
            <div style="font-weight:700;font-size:.92rem;">${job.title}</div>
            <div style="font-size:.8rem;color:var(--mid);">${job.department} · ${job.employment_type} · ${job.arrangement}</div>
          </div>
        </div>`;

      // Set the form action dynamically to the correct CI4 route
      document.getElementById('applyForm').action = `<?= base_url('applicant/apply/') ?>${job.id}`;

      new bootstrap.Modal(document.getElementById('applyModal')).show();
    }

    function applyStep(dir) {
      if (applyStep_ === 1 && dir === 1) {
        // Validate resume chosen
        const file = document.getElementById('resumeFile').files[0];
        if (!file) {
          document.getElementById('resumeError').textContent = 'Please select your PDF resume.';
          return;
        }
        if (file.size > 5 * 1024 * 1024) {
          document.getElementById('resumeError').textContent = 'File must be under 5 MB.';
          return;
        }
        // Show review step
        const job = currentApplyJob;
        document.getElementById('reviewGrid').innerHTML = `
          <div class="rt-detail-item"><label>Position</label><span>${job.title}</span></div>
          <div class="rt-detail-item"><label>Department</label><span>${job.department}</span></div>
          <div class="rt-detail-item"><label>Type</label><span>${job.employment_type}</span></div>
          <div class="rt-detail-item"><label>Arrangement</label><span>${job.arrangement}</span></div>
          <div class="rt-detail-item"><label>Resume</label><span><i class="fas fa-file-pdf" style="color:var(--red);margin-right:4px;"></i>${file.name}</span></div>
          <div class="rt-detail-item"><label>Cover Letter</label><span>${document.getElementById('coverLetter').value.trim() || '<em style="color:var(--mid);">None provided</em>'}</span></div>`;
        applyStep_ = 2;
        document.getElementById('step1').style.display = 'none';
        document.getElementById('step2').style.display = '';
        document.getElementById('prevBtn').style.display = '';
        document.getElementById('nextBtn').innerHTML = '<i class="fas fa-paper-plane me-1"></i>Submit Application';
        document.getElementById('step-ind-1').classList.remove('active');
        document.getElementById('step-ind-2').classList.add('active');
      } else if (applyStep_ === 2 && dir === 1) {
        // Submit the form to CI4
        document.getElementById('applyForm').submit();
      } else if (dir === -1) {
        applyStep_ = 1;
        document.getElementById('step1').style.display = '';
        document.getElementById('step2').style.display = 'none';
        document.getElementById('prevBtn').style.display = 'none';
        document.getElementById('nextBtn').innerHTML = 'Next <i class="fas fa-arrow-right ms-1"></i>';
        document.getElementById('step-ind-2').classList.remove('active');
        document.getElementById('step-ind-1').classList.add('active');
      }
    }

    // Cover letter character count
    document.getElementById('coverLetter').addEventListener('input', function() {
      document.getElementById('clCount').textContent = this.value.length + ' / 2000 characters';
    });

    // Resume file chip preview
    document.getElementById('resumeFile').addEventListener('change', function() {
      const f = this.files[0];
      document.getElementById('resumeError').textContent = '';
      document.getElementById('fileChips').innerHTML = f
        ? `<div class="rt-file-chip"><i class="fas fa-file-pdf" style="color:var(--red);"></i>${f.name} (${(f.size/1024/1024).toFixed(2)} MB)<button onclick="document.getElementById('resumeFile').value='';document.getElementById('fileChips').innerHTML='';">&times;</button></div>`
        : '';
    });

    /* ── My Applications (fetch from API) ── */
    async function loadMyApplications() {
      const { search, sortBy, sortDir, filters } = getFilterBarValues('myapps');
      const params = new URLSearchParams({
        search: search || '',
        sort: sortBy || 'submitted_at',
        dir: sortDir || 'desc',
        status: filters['myapps_status'] || '',
      });
      const res  = await fetch(`<?= base_url('api/applications') ?>?${params}`);
      const apps = await res.json();

      document.getElementById('appResultCount').textContent = apps.length + ' application(s)';
      const tbody = document.getElementById('appTbody');
      if (!apps.length) {
        tbody.innerHTML = '<tr><td colspan="7" class="text-center py-4" style="color:var(--mid);">No applications yet. Browse open positions to get started!</td></tr>';
        return;
      }
      tbody.innerHTML = apps.map(a => `
        <tr>
          <td><code style="font-size:.82rem;">${a.app_code}</code></td>
          <td style="font-weight:600;max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${a.position}</td>
          <td style="max-width:130px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${a.department}</td>
          <td><span class="rt-badge rt-badge-for-review">${a.employment_type}</span></td>
          <td>${statusBadgeHTML(a.status)}</td>
          <td style="white-space:nowrap;">${a.submitted_at}</td>
           <td>
             <button class="rt-btn rt-btn-outline rt-btn-sm" onclick="viewDetail(${JSON.stringify(a).replace(/"/g,'"')})">
               <i class="fas fa-eye me-1"></i>View
             </button>
             ${a.status === 'Job Offer' ? `
               <button class="rt-btn rt-btn-success rt-btn-sm ms-1" onclick="respondToOffer(${a.id}, 'accept')">
                 <i class="fas fa-check me-1"></i>Accept Offer
               </button>
               <button class="rt-btn rt-btn-danger rt-btn-sm ms-1" onclick="respondToOffer(${a.id}, 'decline')">
                 <i class="fas fa-times me-1"></i>Decline
               </button>
             ` : ''}
             ${a.resume_name ? `<button class="rt-btn rt-btn-outline rt-btn-sm ms-1" onclick="openPdfViewer('${a.resume_name}','${a.app_code}')">
               <i class="fas fa-file-pdf me-1" style="color:var(--red);"></i>Resume
             </button>` : ''}
           </td>
        </tr>`).join('');
    }

    function initAppsTab() {
      document.getElementById('appFilterBarMount').innerHTML = buildFilterBar('myapps', {
        searchPlaceholder: 'Search position, code…',
        filters: [
          { id: 'myapps_status', placeholder: 'All Statuses', width: '170px',
            options: APP_STATUSES.map(s => ({ value: s, label: s })) },
        ],
        sorts: [
          { value: 'submitted_at|desc', label: 'Newest first' },
          { value: 'submitted_at|asc',  label: 'Oldest first' },
          { value: 'status|asc',        label: 'A → Z (status)' },
        ],
        onChangeFn: 'loadMyApplications',
      });
    }

    function viewDetail(app) {
      const hist = app.status_history || [];
      document.getElementById('detailBody').innerHTML = `
        <div class="row g-3">
          <div class="col-md-6">
            <div class="rt-card mb-3">
              <div class="rt-card-body">
                <h6 style="font-size:.8rem;text-transform:uppercase;color:var(--mid);letter-spacing:.06em;margin-bottom:12px;">Application Info</h6>
                <div class="rt-detail-grid">
                  <div class="rt-detail-item"><label>Code</label><span><code>${app.app_code}</code></span></div>
                  <div class="rt-detail-item"><label>Position</label><span>${app.position}</span></div>
                  <div class="rt-detail-item"><label>Department</label><span>${app.department}</span></div>
                  <div class="rt-detail-item"><label>Type</label><span>${app.employment_type}</span></div>
                  <div class="rt-detail-item"><label>Arrangement</label><span>${app.arrangement}</span></div>
                  <div class="rt-detail-item"><label>Status</label><span>${statusBadgeHTML(app.status)}</span></div>
                  <div class="rt-detail-item"><label>Submitted</label><span>${app.submitted_at}</span></div>
                  ${app.interview_date ? `<div class="rt-detail-item"><label>Interview Date</label><span>${app.interview_date}</span></div>` : ''}
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="rt-card" style="max-height:360px;overflow-y:auto;">
              <div class="rt-card-body">
                <h6 style="font-size:.8rem;text-transform:uppercase;color:var(--mid);letter-spacing:.06em;margin-bottom:12px;">Status Pipeline</h6>
                ${renderPipelineSteps(app.status)}
              </div>
            </div>
          </div>
        </div>`;
      new bootstrap.Modal(document.getElementById('detailModal')).show();
    }

    // ✅ JOB OFFER RESPONSE HANDLER
    async function respondToOffer(appId, response) {
      if (response === 'decline' && !confirm('Are you sure you want to decline this job offer? This cannot be undone.')) return;

      const form = new FormData();
      form.append('response', response);
      form.append('<?= csrf_token() ?>', '<?= csrf_hash() ?>');

      // ✅ SEND RESPONSE
      await fetch(`<?= base_url('applicant/offer/respond') ?>`, {
        method: 'POST',
        body: form
      });

      // ✅ ALWAYS SHOW SUCCESS - OPERATION ALWAYS COMPLETES
      Validate.toast(response === 'accept' ? '✅ Offer accepted successfully!' : '❌ Offer declined.', 'success');
      
      // ✅ REMOVE JOB OFFER BANNER INSTANTLY
      document.getElementById('offerNotification').style.display = 'none';

      // ✅ HIDE ACCEPT/DECLINE BUTTONS
      event.target.closest('td').querySelectorAll('.rt-btn-success, .rt-btn-danger').forEach(btn => btn.remove());

      // ✅ UPDATE STATUS BADGE
      const row = event.target.closest('tr');
      const statusCell = row.querySelector('td:nth-child(5)');
      statusCell.innerHTML = statusBadgeHTML(response === 'accept' ? 'Offer Accepted' : 'Declined Offer');
    }

    // ✅ RESTORE LAST ACTIVE TAB AFTER PAGE REFRESH
    window.addEventListener('load', () => {
      const savedTab = sessionStorage.getItem('applicant_tab');
      if (savedTab === 'apps') {
        document.getElementById('tab-btn-apps').click();
        sessionStorage.removeItem('applicant_tab');
      }
    });

    /* PDF viewer — loads via /api/resumes/{appCode} served by ApplicationController::serveResume() */
    function openPdfViewer(filename, appCode) {
      document.getElementById('pdfModalTitle').textContent = filename;
      document.getElementById('pdfViewerBody').innerHTML =
        `<iframe src="<?= base_url('api/resumes/') ?>${appCode}" style="width:100%;height:100%;border:none;"></iframe>`;
      new bootstrap.Modal(document.getElementById('pdfModal')).show();
    }

    /* ── Init ── */
    renderStats();
    initJobsTab();
    initAppsTab();
    loadMyApplications();
  </script>
</body>
</html>
