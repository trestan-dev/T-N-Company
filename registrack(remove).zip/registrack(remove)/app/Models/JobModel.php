<?php

namespace App\Models;

use CodeIgniter\Model;

class JobModel extends Model
{
    protected $table            = 'jobs';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = ['job_code','title','department','employment_type','arrangement',
        'description','requirements','salary_range','image_path','is_active','posted_by'];

    protected bool $allowEmptyInserts = false;
    protected bool $updateOnlyChanged = true;

    protected array $casts        = [];
    protected array $castHandlers = [];

    // Dates
    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';

    // Validation
    protected $validationRules      = [];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    // Callbacks
    protected $allowCallbacks = true;
    protected $beforeInsert   = [];
    protected $afterInsert    = [];
    protected $beforeUpdate   = [];
    protected $afterUpdate    = [];
    protected $beforeFind     = [];
    protected $afterFind      = [];
    protected $beforeDelete   = [];
    protected $afterDelete    = [];

    public function getActive()
    {
        return $this->where('is_active', 1)->orderBy('created_at', 'DESC')->findAll();
    }

    public function getFiltered(array $params = [])
    {
        $q = $this->db->table('jobs j')
            ->select('j.*, u.first_name, u.last_name,
                      (SELECT COUNT(*) FROM applications a WHERE a.job_id = j.id) AS applicant_count')
            // FIX: column is 'posted_by' not 'posted_by_id' — was causing a SQL error
            // that made every admin/HR job fetch fail silently and return no rows.
            ->join('users u', 'u.id = j.posted_by', 'left');

        if (!empty($params['search'])) {
            $s = $params['search'];
            $q->groupStart()
              ->like('j.title', $s)
              ->orLike('j.department', $s)
              ->orLike('j.job_code', $s)
              ->groupEnd();
        }
        if (!empty($params['dept']))        $q->where('j.department', $params['dept']);
        if (!empty($params['type']))        $q->where('j.employment_type', $params['type']);
        if (!empty($params['arrangement'])) $q->where('j.arrangement', $params['arrangement']);
        if (isset($params['is_active']))    $q->where('j.is_active', $params['is_active']);

        // FIX: Added 'created_at' as a valid sort field (was missing, so default
        // fallback always triggered). Also kept posted_at mapped to created_at.
        $allowedSorts = ['title', 'department', 'created_at', 'applicant_count'];
        $requestedSort = $params['sort'] ?? '';
        // Map legacy 'posted_at' to 'created_at'
        if ($requestedSort === 'posted_at') $requestedSort = 'created_at';
        $sort = in_array($requestedSort, $allowedSorts) ? $requestedSort : 'created_at';
        $dir  = ($params['dir'] ?? 'desc') === 'asc' ? 'ASC' : 'DESC';

        // applicant_count is a subquery alias — can't prefix with 'j.'
        if ($sort === 'applicant_count') {
            $q->orderBy('applicant_count', $dir);
        } else {
            $q->orderBy('j.' . $sort, $dir);
        }

        return $q->get()->getResultArray();
    }

    public function generateCode(): string
    {
        $last = $this->orderBy('id', 'DESC')->first();
        $next = $last ? ($last['id'] + 1) : 1;
        return 'JOB-' . str_pad($next, 3, '0', STR_PAD_LEFT);
    }
}