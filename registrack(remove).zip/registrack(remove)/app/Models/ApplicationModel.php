<?php

namespace App\Models;

use CodeIgniter\Model;

class ApplicationModel extends Model
{
    protected $table            = 'applications';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = ['app_code','applicant_id','job_id','position','department',
        'employment_type','arrangement','cover_letter',
        'resume_name','resume_path','resume_score',
        'status','interview_date','offer_date',
        'reviewed_by','reviewer_notes','submitted_at'];

    protected bool $allowEmptyInserts = false;
    protected bool $updateOnlyChanged = true;

    protected array $casts        = [];
    protected array $castHandlers = [];

    // Dates
    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';

    // Validation
    protected $validationRules      = [];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    // Callbacks
    protected $allowCallbacks = true;
    protected $beforeInsert   = [];
    protected $afterInsert    = [];
    protected $beforeUpdate   = [];
    protected $afterUpdate    = [];
    protected $beforeFind     = [];
    protected $afterFind      = [];
    protected $beforeDelete   = [];
    protected $afterDelete    = [];

    /**
     * Check whether an applicant has already applied to a specific job.
     */
    public function hasApplied(int $userId, int $jobId): bool
    {
        return $this->where('applicant_id', $userId)
                    ->where('job_id', $jobId)
                    ->countAllResults() > 0;
    }

    /**
     * Check whether an applicant already has a non-terminal active application.
     */
    public function hasActiveApplication(int $userId): bool
    {
        $terminal = ['Hired', 'Rejected', 'Withdrawn', 'Declined Offer'];
        return $this->where('applicant_id', $userId)
                    ->whereNotIn('status', $terminal)
                    ->countAllResults() > 0;
    }

    /**
     * Generate next application code: APP-001, APP-002, …
     */
    public function generateCode(): string
    {
        $last = $this->orderBy('id', 'DESC')->first();
        $next = $last ? ($last['id'] + 1) : 1;
        return 'APP-' . str_pad($next, 3, '0', STR_PAD_LEFT);
    }

    /**
     * Aggregate stats — pass applicant_id to scope to one user, null for all.
     */
    public function getStats(?int $applicantId = null): array
    {
        // FIX: Must reset builder state between calls to avoid query contamination.
        // Clone a fresh query each time.
        $builder = $this->db->table('applications');
        if ($applicantId) {
            $builder->where('applicant_id', $applicantId);
        }
        $all    = $builder->get()->getResultArray();
        $counts = array_count_values(array_column($all, 'status'));

        return [
            'total'      => count($all),
            'submitted'  => $counts['Submitted']  ?? 0,
            // FIX: Was counting 'Offer Extended' which is not a real status in this system.
            // The correct status is 'Job Offer' (matches APP_STATUSES in dashboard.js).
            'in_process' => ($counts['Under Review']       ?? 0)
                          + ($counts['Phone Screen']        ?? 0)
                          + ($counts['Interview Scheduled'] ?? 0)
                          + ($counts['Final Interview']     ?? 0)
                          + ($counts['Job Offer']           ?? 0),
            'hired'      => $counts['Hired']    ?? 0,
            'rejected'   => $counts['Rejected'] ?? 0,
        ];
    }

    /**
     * Filtered + joined query used by all dashboard tables.
     */
    public function getFiltered(array $params = []): array
    {
        $q = $this->db->table('applications a')
            ->select('a.*, u.first_name, u.last_name, u.email, u.phone, j.job_code')
            ->join('users u', 'u.id = a.applicant_id', 'left')
            ->join('jobs j',  'j.id = a.job_id',       'left');

        if (!empty($params['applicant_id'])) $q->where('a.applicant_id', $params['applicant_id']);
        if (!empty($params['status']))       $q->where('a.status',       $params['status']);
        if (!empty($params['dept']))         $q->where('a.department',   $params['dept']);

        if (!empty($params['search'])) {
            $s = $params['search'];
            $q->groupStart()
              ->like('u.first_name', $s)->orLike('u.last_name', $s)
              ->orLike('u.email', $s)->orLike('a.app_code', $s)->orLike('a.position', $s)
              ->groupEnd();
        }

        // FIX: Added 'status' and 'position' as valid sort fields.
        // Previously 'status' was not in the allowed list, so sorting by status
        // silently fell through to 'submitted_at' and appeared broken.
        $allowedSorts = ['submitted_at', 'status', 'resume_score', 'position', 'department'];
        $sort = in_array($params['sort'] ?? '', $allowedSorts) ? $params['sort'] : 'submitted_at';
        $dir  = ($params['dir'] ?? 'desc') === 'asc' ? 'ASC' : 'DESC';
        $q->orderBy('a.' . $sort, $dir);

        return $q->get()->getResultArray();
    }
}