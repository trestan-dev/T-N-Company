<?php

namespace App\Models;

use CodeIgniter\Model;

class EmployeeModel extends Model
{
    protected $table            = 'employees';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = ['application_id','user_id','position','department',
        'employment_type','arrangement','hired_by','hired_date','type','is_active'];

    protected bool $allowEmptyInserts = false;
    protected bool $updateOnlyChanged = true;

    protected array $casts = [];
    protected array $castHandlers = [];

    // Dates
    protected $useTimestamps = false;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';

    // Validation
    protected $validationRules      = [];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    // Callbacks
    protected $allowCallbacks = true;
    protected $beforeInsert   = [];
    protected $afterInsert    = [];
    protected $beforeUpdate   = [];
    protected $afterUpdate    = [];
    protected $beforeFind     = [];
    protected $afterFind      = [];
    protected $beforeDelete   = [];
    protected $afterDelete    = [];


/**
     * Auto-called when an application status reaches "Hired".
     * Creates a row in the employees table from the application data.
     *
     * @param array $app  Row from the applications table
     * @param array $hrUser  The HR/admin user who made the status change
     */
    public function addFromApplication(array $app, array $hrUser): void
    {
        // Avoid duplicate employee rows for the same application
        if ($this->where('application_id', $app['id'])->countAllResults() > 0) return;

        $this->insert([
            'application_id'  => $app['id'],
            'user_id'         => $app['applicant_id'],
            'position'        => $app['position'],
            'department'      => $app['department'],
            'employment_type' => $app['employment_type'],
            'arrangement'     => $app['arrangement'],
            'hired_by'        => $hrUser['id'],
            'hired_date'      => date('Y-m-d'),
            'type'            => 'hired',
            'is_active'       => 1,
        ]);
    }

    /**
     * Returns employees joined with user names + email for display tables.
     */
    public function getWithNames(): array
    {
        return $this->db->table('employees e')
            ->select('e.*, u.first_name, u.last_name, u.email,
                      h.first_name AS hired_by_first, h.last_name AS hired_by_last')
            ->join('users u', 'u.id = e.user_id', 'left')
            ->join('users h', 'h.id = e.hired_by', 'left')
            ->orderBy('e.hired_date', 'DESC')
            ->get()->getResultArray();
    }
}

