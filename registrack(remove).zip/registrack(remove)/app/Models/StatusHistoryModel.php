<?php

namespace App\Models;

use CodeIgniter\Model;

class StatusHistoryModel extends Model
{
    // FIX: Table was 'statushistories' but the actual DB table is 'status_history'
    // The DatabaseException "#1146 Table 'registrack_db.statushistories' doesn't exist"
    // was caused by this mismatch. Rename to match your SQL schema.
    protected $table            = 'application_status_history';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = ['application_id','status','notes','changed_by'];

    protected bool $allowEmptyInserts = false;
    protected bool $updateOnlyChanged = true;

    protected array $casts        = [];
    protected array $castHandlers = [];

    // FIX: useTimestamps = true so 'changed_at' (createdField) is auto-written on insert.
    // Without this the changed_at column stays NULL and timeline queries fail.
    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'changed_at';   // matches the SQL column name
    protected $updatedField  = '';             // no updated_at on this table
    protected $deletedField  = 'deleted_at';

    // Validation
    protected $validationRules      = [];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    // Callbacks
    protected $allowCallbacks = true;
    protected $beforeInsert   = [];
    protected $afterInsert    = [];
    protected $beforeUpdate   = [];
    protected $afterUpdate    = [];
    protected $beforeFind     = [];
    protected $afterFind      = [];
    protected $beforeDelete   = [];
    protected $afterDelete    = [];
}