<?php
// app/Database/Seeds/DefaultUsers.php
// Run once:  php spark db:seed DefaultUsers
namespace App\Database\Seeds;
use CodeIgniter\Database\Seeder;

class DefaultUsers extends Seeder
{
    public function run()
    {
        // Clear any placeholder rows first
        $this->db->table('users')->emptyTable();

        $users = [
            [
                'first_name' => 'System',
                'last_name'  => 'Admin',
                'email'      => 'admin@tncompany.ph',
                'password'   => 'Admin@1234',
                'role'       => 'admin',
                'is_active'  => 1,
            ],
            [
                'first_name' => 'TAN',
                'last_name'  => 'Admin',
                'email'      => 'tan@tncompany.ph',
                'password'   => 'tan@1234',
                'role'       => 'admin',
                'is_active'  => 1,
            ],
            [
                'first_name' => 'Maria',
                'last_name'  => 'Reyes',
                'email'      => 'hr@tncompany.ph',
                'password'   => 'Hr@1234',
                'role'       => 'hr',
                'is_active'  => 1,
            ],
            [
                'first_name' => 'Juan',
                'last_name'  => 'dela Cruz',
                'email'      => 'juan@email.com',
                'password'   => 'Pass@1234',
                'role'       => 'applicant',
                'is_active'  => 1,
            ],
        ];

        foreach ($users as $u) {
            // password_hash() creates a bcrypt hash — plain text is NEVER stored
            $u['password'] = password_hash($u['password'], PASSWORD_BCRYPT);
            $this->db->table('users')->insert($u);
        }

        echo "Default users seeded successfully.\n";
        echo "  Admin:     admin@tncompany.ph / Admin@1234\n";
        echo "  Admin:     tan@tncompany.ph   / tan@1234\n";
        echo "  HR:        hr@tncompany.ph    / Hr@1234\n";
        echo "  Applicant: juan@email.com     / Pass@1234\n";
    }
}
